import express from 'express';
import https from 'https';
import zlib from 'zlib';
import path from 'path';
import { createServer as createViteServer } from 'vite';

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json());

// In-memory cache
interface ContractCache {
  data: any;
  timestamp: number;
}
let contractsCache: ContractCache | null = null;
const archiveCache = new Map<string, { candles: any[]; timestamp: number }>();
const rangeCache = new Map<string, { candles: any[]; timestamp: number }>();

function fetchJson(url: string, timeoutMs = 12000): Promise<{ status: number; data: any }> {
  return new Promise((resolve, reject) => {
    const req = https.get(url, { headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' } }, (res) => {
      let body = '';
      res.on('data', chunk => { body += chunk; });
      res.on('end', () => {
        try {
          const parsed = JSON.parse(body);
          resolve({ status: res.statusCode || 200, data: parsed });
        } catch {
          resolve({ status: res.statusCode || 500, data: body });
        }
      });
    });
    req.setTimeout(timeoutMs, () => {
      req.destroy(new Error(`Timeout after ${timeoutMs}ms on ${url}`));
    });
    req.on('error', reject);
  });
}

function fetchMonthArchive(contract: string, yearMonth: string, timeoutMs = 15000): Promise<{ status: string; candles: any[] }> {
  const cacheKey = `${contract}_${yearMonth}`;
  const cached = archiveCache.get(cacheKey);
  if (cached) {
    return Promise.resolve({ status: 'OK', candles: cached.candles });
  }

  const url = `https://download.gatedata.org/futures_usdt/candlesticks_5m/${yearMonth}/${contract}-${yearMonth}.csv.gz`;

  return new Promise((resolve) => {
    const req = https.get(url, (res) => {
      if (res.statusCode === 404) {
        return resolve({ status: 'NOT_LISTED_YET', candles: [] });
      }
      if (res.statusCode !== 200) {
        return resolve({ status: 'HTTP_' + res.statusCode, candles: [] });
      }

      const gunzip = zlib.createGunzip();
      let text = '';
      res.pipe(gunzip);

      gunzip.on('data', chunk => { text += chunk.toString(); });
      gunzip.on('end', () => {
        const lines = text.trim().split('\n');
        const candles: any[] = [];
        for (let i = 0; i < lines.length; i++) {
          const line = lines[i];
          if (!line) continue;
          const parts = line.split(',');
          if (parts.length >= 6) {
            const t = Number(parts[0]);
            const v = Number(parts[1]);
            const c = Number(parts[2]);
            const h = Number(parts[3]);
            const l = Number(parts[4]);
            const o = Number(parts[5]);
            if (t > 0 && c > 0) {
              candles.push({ t, o, h, l, c, v, sum: v * c });
            }
          }
        }
        candles.sort((a, b) => a.t - b.t);

        if (archiveCache.size > 300) {
          const firstKey = archiveCache.keys().next().value;
          if (firstKey) archiveCache.delete(firstKey);
        }
        archiveCache.set(cacheKey, { candles, timestamp: Date.now() });

        resolve({ status: 'OK', candles });
      });

      gunzip.on('error', () => resolve({ status: 'ERROR', candles: [] }));
    });

    req.setTimeout(timeoutMs, () => {
      req.destroy(new Error(`Archive timeout after ${timeoutMs}ms`));
      resolve({ status: 'TIMEOUT', candles: [] });
    });

    req.on('error', () => resolve({ status: 'NETWORK_ERROR', candles: [] }));
  });
}

// 1. Contracts Proxy
app.get('/api/gate/contracts', async (req, res) => {
  const now = Date.now();
  if (contractsCache && (now - contractsCache.timestamp < 10 * 60 * 1000)) {
    return res.json({ success: true, ...contractsCache.data, cached: true });
  }

  try {
    const url = 'https://api.gateio.ws/api/v4/futures/usdt/contracts';
    const { status, data } = await fetchJson(url);

    if (status !== 200 || !Array.isArray(data)) {
      return res.status(status).json({ success: false, error: 'Gate contracts API error', data });
    }

    const NON_CRYPTO = new Set(['stocks', 'indices', 'commodities', 'forex', 'metals']);
    let stocks = 0;
    let indices = 0;
    let otherNonCrypto = 0;
    let preMarket = 0;
    let delisted = 0;
    let nonUsdt = 0;

    const eligible = data.filter((c: any) => {
      if (!c.name || typeof c.name !== 'string') return false;
      if (!c.name.endsWith('_USDT')) {
        nonUsdt++;
        return false;
      }
      if (/_\d{6,8}$/.test(c.name)) return false;
      if (c.is_pre_market) {
        preMarket++;
        return false;
      }
      if (c.in_delisting || (c.status && c.status !== 'trading')) {
        delisted++;
        return false;
      }
      const cType = (c.contract_type || '').toLowerCase();
      if (cType === 'stocks') {
        stocks++;
        return false;
      }
      if (cType === 'indices') {
        indices++;
        return false;
      }
      if (NON_CRYPTO.has(cType)) {
        otherNonCrypto++;
        return false;
      }
      return true;
    }).map((c: any) => ({
      name: c.name,
      type: c.type || 'direct',
      status: c.status,
      in_delisting: Boolean(c.in_delisting),
      order_price_round: c.order_price_round,
      mark_price: c.mark_price,
      last_price: c.last_price
    }));

    const responsePayload = {
      totalApi: data.length,
      filteredCount: data.length - eligible.length,
      contracts: eligible,
      breakdown: { stocks, indices, otherNonCrypto, preMarket, delisted, nonUsdt }
    };

    contractsCache = { data: responsePayload, timestamp: now };
    return res.json({ success: true, ...responsePayload });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// 2. Archive Month Proxy
app.get('/api/gate/archive-month', async (req, res) => {
  const contract = String(req.query.contract || '').trim();
  const yearMonth = String(req.query.yearMonth || '').trim();

  if (!contract || !yearMonth || !/^\d{6}$/.test(yearMonth)) {
    return res.status(400).json({ success: false, error: 'contract and yearMonth (YYYYMM) required' });
  }

  const result = await fetchMonthArchive(contract, yearMonth);
  if (result.status === 'NOT_LISTED_YET') {
    return res.json({
      success: true,
      contract,
      yearMonth,
      status: 'NOT_LISTED_YET',
      candles: [],
      message: `${contract} bu ayda (${yearMonth}) henüz Gate üzerinde listelenmemişti.`
    });
  }

  if (result.status === 'OK') {
    return res.json({
      success: true,
      contract,
      yearMonth,
      status: 'OK',
      count: result.candles.length,
      candles: result.candles
    });
  }

  return res.status(500).json({ success: false, contract, yearMonth, status: result.status, candles: [] });
});

// 3. Online Candlesticks Proxy (Recent REST)
app.get('/api/gate/candlesticks', async (req, res) => {
  const contract = String(req.query.contract || '').trim();
  const limit = req.query.limit ? String(req.query.limit) : '';
  const from = req.query.from ? String(req.query.from) : '';
  const to = req.query.to ? String(req.query.to) : '';

  if (!contract) {
    return res.status(400).json({ success: false, error: 'contract required' });
  }

  const params = new URLSearchParams();
  params.set('contract', contract);
  params.set('interval', '5m');

  if (from && to) {
    params.set('from', from);
    params.set('to', to);
  } else if (to && limit) {
    params.set('to', to);
    params.set('limit', limit);
  } else if (limit) {
    params.set('limit', limit);
  } else {
    params.set('limit', '100');
  }

  const url = `https://api.gateio.ws/api/v4/futures/usdt/candlesticks?${params.toString()}`;

  try {
    const { status, data } = await fetchJson(url);

    if (status === 200 && Array.isArray(data)) {
      const candles = data.map((item: any) => ({
        t: Number(item.t),
        o: Number(item.o),
        h: Number(item.h),
        l: Number(item.l),
        c: Number(item.c),
        v: Number(item.v),
        sum: Number(item.sum || item.v * item.c || 0)
      })).filter(c => c.t > 0 && c.c > 0);

      candles.sort((a: any, b: any) => a.t - b.t);
      return res.json({ success: true, contract, count: candles.length, candles });
    }

    return res.status(status).json({ success: false, contract, status, error: data });
  } catch (err: any) {
    return res.status(500).json({ success: false, contract, error: err.message });
  }
});

// Shared full range fetcher: merges archive months + recent REST candles
async function fetchFullRange(contract: string, fromSec: number, toSec: number): Promise<{
  status: string;
  candles: any[];
  wasNeverListed: boolean;
}> {
  const cacheKey = `${contract}_${fromSec}_${toSec}`;
  const cached = rangeCache.get(cacheKey);
  if (cached && (Date.now() - cached.timestamp < 10 * 60 * 1000)) {
    return { status: cached.candles.length > 0 ? 'OK' : 'INSUFFICIENT_DATA', candles: cached.candles, wasNeverListed: false };
  }

  const startDate = new Date(fromSec * 1000);
  const endDate = new Date(toSec * 1000);

  const yearMonths: string[] = [];
  const cur = new Date(startDate.getFullYear(), startDate.getMonth(), 1);
  const endMonth = new Date(endDate.getFullYear(), endDate.getMonth(), 1);

  while (cur <= endMonth) {
    const y = cur.getFullYear();
    const m = String(cur.getMonth() + 1).padStart(2, '0');
    yearMonths.push(`${y}${m}`);
    cur.setMonth(cur.getMonth() + 1);
  }

  const candleMap = new Map<number, any>();
  let wasNeverListed = true;

  // Fetch archive months
  const currentYearMonth = `${new Date().getFullYear()}${String(new Date().getMonth() + 1).padStart(2, '0')}`;

  for (const ym of yearMonths) {
    if (ym === currentYearMonth) {
      // Skip current ongoing month from archive (fetched via live REST below)
      continue;
    }
    const arch = await fetchMonthArchive(contract, ym);
    if (arch.status === 'OK' && arch.candles.length > 0) {
      wasNeverListed = false;
      for (const c of arch.candles) {
        if (c.t >= fromSec && c.t <= toSec) {
          candleMap.set(c.t, c);
        }
      }
    }
  }

  // If requested range includes recent days (last 30 days):
  const nowSec = Math.floor(Date.now() / 1000);
  if (toSec >= nowSec - 30 * 86400) {
    const restUrl = `https://api.gateio.ws/api/v4/futures/usdt/candlesticks?contract=${contract}&interval=5m&limit=2000`;
    const { status, data } = await fetchJson(restUrl);
    if (status === 200 && Array.isArray(data)) {
      wasNeverListed = false;
      for (const item of data) {
        const t = Number(item.t);
        const c = Number(item.c);
        if (t >= fromSec && t <= toSec && c > 0) {
          candleMap.set(t, {
            t,
            o: Number(item.o),
            h: Number(item.h),
            l: Number(item.l),
            c,
            v: Number(item.v),
            sum: Number(item.sum || Number(item.v) * c)
          });
        }
      }
    }
  }

  const sortedCandles = Array.from(candleMap.values()).sort((a, b) => a.t - b.t);

  if (rangeCache.size > 100) {
    const firstKey = rangeCache.keys().next().value;
    if (firstKey) rangeCache.delete(firstKey);
  }
  rangeCache.set(cacheKey, { candles: sortedCandles, timestamp: Date.now() });

  return {
    status: sortedCandles.length > 0 ? 'OK' : (wasNeverListed ? 'NOT_LISTED_YET' : 'INSUFFICIENT_DATA'),
    candles: sortedCandles,
    wasNeverListed
  };
}

// 4. Unified Full Range Candles Endpoint
app.get('/api/gate/range', async (req, res) => {
  const contract = String(req.query.contract || '').trim();
  const fromSec = Number(req.query.from);
  const toSec = Number(req.query.to);

  if (!contract || !Number.isFinite(fromSec) || !Number.isFinite(toSec) || fromSec >= toSec) {
    return res.status(400).json({ success: false, error: 'Valid contract, from, and to timestamps required' });
  }

  try {
    const result = await fetchFullRange(contract, fromSec, toSec);
    return res.json({
      success: true,
      contract,
      status: result.status,
      count: result.candles.length,
      candles: result.candles
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, contract, error: err.message });
  }
});

// 5. Pre-flight 3-Coin Verification across requested range
app.get('/api/gate/test3', async (req, res) => {
  const fromSec = req.query.from ? Number(req.query.from) : Math.floor(new Date('2026-01-01').getTime() / 1000);
  const toSec = req.query.to ? Number(req.query.to) : Math.floor(Date.now() / 1000);

  const testCoins = ['BTC_USDT', 'ETH_USDT', 'SOL_USDT'];
  const results: any[] = [];

  for (const coin of testCoins) {
    try {
      const { candles, status } = await fetchFullRange(coin, fromSec, toSec);

      results.push({
        coin,
        status: candles.length > 0 ? 'SUCCESS' : status,
        downloadedCandles: candles.length,
        processedCandles: Math.max(0, candles.length - 35),
        evaluatedCandidates: Math.max(0, candles.length - 35),
        firstCandleDate: candles[0] ? new Date(candles[0].t * 1000).toISOString() : undefined,
        lastCandleDate: candles[candles.length - 1] ? new Date(candles[candles.length - 1].t * 1000).toISOString() : undefined,
        latestPrice: candles[candles.length - 1]?.c,
        dataError: false
      });
    } catch (err: any) {
      results.push({
        coin,
        status: 'ERROR',
        downloadedCandles: 0,
        processedCandles: 0,
        evaluatedCandidates: 0,
        dataError: true,
        error: err.message
      });
    }
  }

  res.json({ success: results.every(r => r.status === 'SUCCESS'), timestamp: Date.now(), results });
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`TRADINGLY PUMP server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
