import { Activity, ArrowUpRight, CheckCircle2, Clock, Filter, Play, Target, Trash2, TrendingUp, XCircle } from 'lucide-react';
import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { TradeRecord, TradeStatus } from '../types';

export const ForwardTestTab: React.FC = () => {
  const { t, trades, clearAllTrades, setActiveTab } = useApp();
  const [filterStatus, setFilterStatus] = useState<string>('ALL');

  const filteredTrades = trades.filter(tr => {
    if (filterStatus === 'ALL') return true;
    return tr.status === filterStatus;
  });

  const totalTrades = trades.length;
  const tpHitCount = trades.filter(t => t.status === 'TP_HIT').length;
  const expiredCount = trades.filter(t => t.status === 'EXPIRED_24H').length;
  const activeCount = trades.filter(t => t.status === 'ACTIVE').length;
  const completedCount = tpHitCount + expiredCount;

  // RULE: Win rate strictly calculated only on completed trades
  const winRate = completedCount > 0
    ? Math.round((tpHitCount / completedCount) * 1000) / 10
    : 0;

  return (
    <div className="space-y-6">
      {/* Top Banner / Description */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-6 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <Play className="w-5 h-5 text-emerald-400" />
              <h2 className="text-xl font-black text-slate-100 tracking-wide">
                {t.forwardTestTitle}
              </h2>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-500/30 font-semibold">
                Kağıt İşlemler (Paper Trading)
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1 max-w-2xl">
              {t.forwardTestDesc}
            </p>
          </div>

          {trades.length > 0 && (
            <button
              onClick={clearAllTrades}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 text-xs transition-colors self-start md:self-auto"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Geçmişi Temizle</span>
            </button>
          )}
        </div>

        {/* Metrics Overview */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mt-5">
          <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-[11px] text-slate-400 block">Toplam İşlem</span>
            <span className="text-xl font-black text-slate-100 font-mono">
              {totalTrades}
            </span>
          </div>

          <div className="p-3.5 rounded-xl bg-emerald-950/30 border border-emerald-500/30">
            <span className="text-[11px] text-emerald-400 block font-semibold">{t.tpHit}</span>
            <div className="flex items-center space-x-1">
              <span className="text-xl font-black text-emerald-300 font-mono">
                {tpHitCount}
              </span>
              <span className="text-[11px] text-emerald-400 font-bold px-1 rounded bg-emerald-500/20">
                +%20
              </span>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-[11px] text-slate-400 block">{t.expired24h}</span>
            <span className="text-xl font-bold text-slate-300 font-mono">
              {expiredCount}
            </span>
          </div>

          <div className="p-3.5 rounded-xl bg-cyan-950/30 border border-cyan-800/40">
            <span className="text-[11px] text-cyan-400 block font-semibold">{t.activeTrades}</span>
            <span className="text-xl font-bold text-cyan-300 font-mono">
              {activeCount}
            </span>
          </div>

          <div className="p-3.5 rounded-xl bg-gradient-to-br from-emerald-950/50 to-slate-950/80 border border-emerald-500/40 col-span-2 sm:col-span-1">
            <span className="text-[11px] text-emerald-400 block font-bold">{t.winRate}</span>
            <div className="flex items-center space-x-1 mt-0.5">
              <span className="text-2xl font-black text-emerald-300 font-mono">
                %{winRate}
              </span>
              <span className="text-[10px] text-slate-400">
                ({completedCount} tamamlanan)
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Trades Table Section */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl overflow-hidden">
        {/* Table Filters */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center space-x-1.5 text-xs">
            <Filter className="w-3.5 h-3.5 text-slate-400 mr-1" />
            <button
              onClick={() => setFilterStatus('ALL')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                filterStatus === 'ALL'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              Tümü ({trades.length})
            </button>
            <button
              onClick={() => setFilterStatus('ACTIVE')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                filterStatus === 'ACTIVE'
                  ? 'bg-cyan-600 text-white'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              Aktif ({activeCount})
            </button>
            <button
              onClick={() => setFilterStatus('TP_HIT')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                filterStatus === 'TP_HIT'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              TP Vuruldu ({tpHitCount})
            </button>
            <button
              onClick={() => setFilterStatus('EXPIRED_24H')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                filterStatus === 'EXPIRED_24H'
                  ? 'bg-slate-700 text-white'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              24 Saat Sonu ({expiredCount})
            </button>
          </div>
        </div>

        {/* Trade List Table */}
        {filteredTrades.length === 0 ? (
          <div className="py-16 text-center px-4">
            <div className="w-12 h-12 rounded-full bg-slate-800/80 border border-slate-700 flex items-center justify-center mx-auto mb-3 text-slate-400">
              <Play className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-semibold text-slate-300">{t.noTradesYet}</h4>
            <p className="text-xs text-slate-500 max-w-md mx-auto mt-1">
              Canlı tarama çalışırken bulunan tüm sinyaller otomatik olarak buraya eklenir ve 24 saat boyunca Gate.io fiyatlarıyla takip edilir.
            </p>
            <button
              onClick={() => setActiveTab('scanner')}
              className="mt-4 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-md shadow-emerald-600/20"
            >
              Canlı Taramaya Git
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800/80 bg-slate-950/40 text-slate-400">
                  <th className="py-3 px-4 font-semibold">{t.tableCoin}</th>
                  <th className="py-3 px-4 font-semibold">{t.status}</th>
                  <th className="py-3 px-4 font-semibold">{t.tableEntryPrice}</th>
                  <th className="py-3 px-4 font-semibold">{t.tableTargetPrice}</th>
                  <th className="py-3 px-4 font-semibold">{t.highestPrice}</th>
                  <th className="py-3 px-4 font-semibold">{t.currentGain}</th>
                  <th className="py-3 px-4 font-semibold">{t.remainingTime}</th>
                  <th className="py-3 px-4 font-semibold">{t.tableTime}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/50">
                {filteredTrades.map(tr => {
                  const elapsedMinutes = tr.durationMinutes || Math.floor((Date.now() - tr.signalTime) / 60000);
                  const remainingMinutes = Math.max(0, 1440 - elapsedMinutes);
                  const remainingHours = Math.floor(remainingMinutes / 60);
                  const remMins = remainingMinutes % 60;

                  return (
                    <tr key={tr.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-3.5 px-4">
                        <div className="flex items-center space-x-2">
                          <span className="font-bold text-slate-100 text-sm">{tr.contract}</span>
                          <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                            LONG
                          </span>
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        {tr.status === 'TP_HIT' ? (
                          <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                            <span>{t.statusTpHit}</span>
                          </span>
                        ) : tr.status === 'EXPIRED_24H' ? (
                          <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-slate-800 text-slate-400 border border-slate-700">
                            <XCircle className="w-3 h-3 text-slate-400" />
                            <span>{t.statusExpired}</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-cyan-950 text-cyan-300 border border-cyan-700/60 animate-pulse">
                            <Activity className="w-3 h-3 text-cyan-400" />
                            <span>{t.statusActive}</span>
                          </span>
                        )}
                      </td>

                      <td className="py-3.5 px-4 font-mono font-medium text-slate-200">
                        ${tr.entryPrice.toLocaleString()}
                      </td>

                      <td className="py-3.5 px-4 font-mono text-emerald-400 font-semibold">
                        ${tr.targetPrice.toLocaleString()}
                      </td>

                      <td className="py-3.5 px-4 font-mono">
                        <div className="flex items-center space-x-1 text-slate-200">
                          <span>${tr.highestPrice.toLocaleString()}</span>
                          <span className="text-[10px] text-emerald-400 font-semibold">
                            (+{tr.highestGainPct}%)
                          </span>
                        </div>
                      </td>

                      <td className="py-3.5 px-4 font-mono">
                        <span
                          className={`font-bold ${
                            tr.currentOrExitGainPct >= 20
                              ? 'text-emerald-400'
                              : tr.currentOrExitGainPct > 0
                              ? 'text-teal-400'
                              : tr.currentOrExitGainPct < 0
                              ? 'text-rose-400'
                              : 'text-slate-400'
                          }`}
                        >
                          {tr.currentOrExitGainPct >= 0 ? `+${tr.currentOrExitGainPct}%` : `${tr.currentOrExitGainPct}%`}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-slate-300 font-mono">
                        {tr.status === 'ACTIVE' ? (
                          <div className="flex items-center space-x-1 text-amber-300">
                            <Clock className="w-3 h-3 text-amber-400" />
                            <span>{remainingHours}s {remMins}dk</span>
                          </div>
                        ) : (
                          <span className="text-slate-500">
                            {tr.durationMinutes} dk ({Math.round(tr.durationMinutes / 60)}s)
                          </span>
                        )}
                      </td>

                      <td className="py-3.5 px-4 text-slate-400">
                        {new Date(tr.signalTime).toLocaleDateString([], {
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
