import { Activity, AlertTriangle, ArrowUpRight, CheckCircle2, ChevronRight, Eye, Pause, Play, RefreshCw, RotateCcw, Search, ShieldCheck, Smartphone, Square, Zap } from 'lucide-react';
import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { PumpSignal } from '../types';

export const ScannerTab: React.FC = () => {
  const {
    t,
    scanStats,
    startLiveScan,
    pauseLiveScan,
    resumeLiveScan,
    stopLiveScan,
    toggleLoop,
    signals,
    androidStatus,
    setSelectedSignalForModal,
    clearAllSignals
  } = useApp();

  const [searchTerm, setSearchTerm] = useState('');

  const filteredSignals = signals.filter(s =>
    s.contract.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const progressPercent = scanStats.totalCoins > 0
    ? Math.min(100, Math.round((scanStats.scannedCoins / scanStats.totalCoins) * 100))
    : 0;

  return (
    <div className="space-y-6">
      {/* Top Banner / Controls */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-6 shadow-xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
              <h2 className="text-xl font-black text-slate-100 tracking-wide">
                {t.tabScanner}
              </h2>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-500/30 font-semibold">
                Gate USDT Vadeli
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              5 dakikalık mumlar, 61 göstergeli PUMP modeli. Eşik: 0.81 | TP: +%20 | Süre: 24 saat
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Auto Loop Toggle */}
            <button
              onClick={toggleLoop}
              className={`flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-semibold border transition-all ${
                scanStats.loopEnabled
                  ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                  : 'bg-slate-800/60 border-slate-700/60 text-slate-400 hover:text-slate-300'
              }`}
            >
              <RotateCcw className={`w-3.5 h-3.5 ${scanStats.loopEnabled ? 'text-emerald-400' : ''}`} />
              <span>{t.autoLoop}</span>
              {scanStats.loopEnabled && scanStats.nextScanCountdown > 0 && (
                <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono text-[10px]">
                  {scanStats.nextScanCountdown}s
                </span>
              )}
            </button>

            {/* Pause / Resume Button */}
            {scanStats.isScanning && (
              <button
                onClick={scanStats.isPaused ? resumeLiveScan : pauseLiveScan}
                className="flex items-center space-x-1.5 px-3.5 py-2.5 rounded-xl bg-amber-600/80 hover:bg-amber-600 text-white text-xs font-bold border border-amber-500/40 transition-all cursor-pointer shadow-md"
              >
                {scanStats.isPaused ? (
                  <>
                    <Play className="w-3.5 h-3.5 fill-white" />
                    <span>Sürdür</span>
                  </>
                ) : (
                  <>
                    <Pause className="w-3.5 h-3.5" />
                    <span>Duraklat</span>
                  </>
                )}
              </button>
            )}

            {/* Start / Stop Button */}
            {scanStats.isScanning ? (
              <button
                onClick={stopLiveScan}
                className="flex items-center space-x-2 px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-lg shadow-rose-600/30 transition-all cursor-pointer"
              >
                <Square className="w-4 h-4 fill-white" />
                <span>{t.stopScan}</span>
              </button>
            ) : (
              <button
                onClick={startLiveScan}
                className="flex items-center space-x-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-lg shadow-emerald-600/30 transition-all cursor-pointer"
              >
                <Play className="w-4 h-4 fill-white" />
                <span>{t.startScan}</span>
              </button>
            )}

            {/* Rescan Button (DISABLED while scanning active as required!) */}
            <button
              onClick={startLiveScan}
              disabled={scanStats.isScanning}
              title={scanStats.isScanning ? 'Tarama devam ederken yeniden başlatılamaz' : t.rescan}
              className={`flex items-center space-x-2 px-4 py-2.5 rounded-xl text-xs font-bold border transition-all ${
                scanStats.isScanning
                  ? 'bg-slate-800/40 border-slate-800 text-slate-600 cursor-not-allowed opacity-60'
                  : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-200 cursor-pointer shadow-sm'
              }`}
            >
              <RefreshCw className={`w-3.5 h-3.5 ${scanStats.isScanning ? 'animate-spin' : ''}`} />
              <span>{t.rescan}</span>
            </button>
          </div>
        </div>

        {/* Contract Filter Overview Banner */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-4 pt-4 border-t border-slate-800/80">
          <div className="p-2.5 rounded-xl bg-slate-950/40 border border-slate-800/70 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-slate-400 block uppercase tracking-wider font-semibold">API Toplam Sözleşme</span>
              <span className="text-xs text-slate-400">Gate.io ham futures listesi</span>
            </div>
            <span className="text-base font-bold text-slate-200 font-mono">
              {scanStats.totalApiContracts || 1040}
            </span>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-950/40 border border-amber-900/30 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-amber-400 block uppercase tracking-wider font-semibold">Filtrelenen Sözleşmeler</span>
              <span className="text-xs text-slate-400">Hisse, endeks, emtia, ön-pazar</span>
            </div>
            <span className="text-base font-bold text-amber-300 font-mono">
              -{scanStats.filteredContractsCount || 451}
            </span>
          </div>

          <div className="p-2.5 rounded-xl bg-emerald-950/30 border border-emerald-500/30 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-emerald-400 block uppercase tracking-wider font-semibold">Taranan Kripto Perpetual</span>
              <span className="text-xs text-slate-400">USDT vadeli işlem çiftleri</span>
            </div>
            <span className="text-base font-black text-emerald-300 font-mono">
              {scanStats.totalCoins || 589}
            </span>
          </div>
        </div>

        {/* Real-time Progress Bar */}
        <div className="mt-4 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <div className="flex items-center space-x-2">
              <Activity className="w-3.5 h-3.5 text-emerald-400" />
              <span>
                {scanStats.isScanning
                  ? `${scanStats.isPaused ? '[DURAKLATILDI] ' : ''}Mevcut İncelenen: ${scanStats.currentCoin}`
                  : scanStats.nextScanCountdown > 0
                  ? `Döngü beklemede: ${scanStats.nextScanCountdown} saniye sonra yeniden başlar`
                  : scanStats.currentCoin || t.idle}
              </span>
            </div>
            <span className="font-mono text-slate-300 font-bold">
              %{progressPercent} ({scanStats.scannedCoins} / {scanStats.totalCoins || '?'})
            </span>
          </div>

          <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-emerald-500 via-teal-400 to-cyan-400 transition-all duration-300 rounded-full"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* Real-time Statistics Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mt-4">
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-[11px] text-slate-400 block">Kripto Perpetual</span>
            <span className="text-lg font-bold text-slate-100 font-mono">
              {scanStats.totalCoins > 0 ? scanStats.totalCoins : '589'}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-[11px] text-emerald-400 block">{t.successful}</span>
            <span className="text-lg font-bold text-emerald-300 font-mono">
              {scanStats.successfulCoins}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-[11px] text-amber-400 block">{t.failed}</span>
            <div className="flex items-center space-x-1.5">
              <span className="text-lg font-bold text-amber-300 font-mono">
                {scanStats.failedCoins}
              </span>
              {scanStats.retryCount > 0 && (
                <span className="text-[10px] text-slate-400">
                  ({scanStats.retryCount} tekrar)
                </span>
              )}
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-[11px] text-slate-400 block">{t.speed}</span>
            <span className="text-lg font-bold text-cyan-400 font-mono">
              {scanStats.speed} <span className="text-xs font-normal text-slate-400">{t.coinsSec}</span>
            </span>
          </div>

          <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/30">
            <span className="text-[11px] text-emerald-400 block font-semibold">{t.signalsFound}</span>
            <span className="text-lg font-black text-emerald-300 font-mono">
              {scanStats.signalsFoundCount}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-[11px] text-slate-400 block">Kayıtlı Sinyaller</span>
            <span className="text-lg font-bold text-slate-200 font-mono">
              {signals.length}
            </span>
          </div>
        </div>
      </div>

      {/* Signals Section */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl overflow-hidden">
        {/* Table Header / Filter */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center space-x-2">
            <Zap className="w-5 h-5 text-emerald-400" />
            <h3 className="text-base font-bold text-slate-100">
              {t.signalsFound} ({filteredSignals.length})
            </h3>
            <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-400">
              Eşik: &ge; 0.81
            </span>
          </div>

          <div className="flex items-center space-x-2">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder={t.filterSignals}
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="pl-9 pr-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors w-48 sm:w-60"
              />
            </div>

            {signals.length > 0 && (
              <button
                onClick={clearAllSignals}
                className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 text-xs transition-colors"
              >
                Temizle
              </button>
            )}
          </div>
        </div>

        {/* Signals Table */}
        {filteredSignals.length === 0 ? (
          <div className="py-16 text-center px-4">
            <div className="w-12 h-12 rounded-full bg-slate-800/80 border border-slate-700 flex items-center justify-center mx-auto mb-3 text-slate-400">
              <Activity className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-semibold text-slate-300">
              {scanStats.isScanning ? 'Tarama devam ediyor...' : t.noSignalsYet}
            </h4>
            <p className="text-xs text-slate-500 max-w-md mx-auto mt-1">
              Gate.io üzerindeki tüm vadeli USDT coinler taranırken 61 göstergeli PUMP modelinden 0.81 ve üzeri skor alan coinler anında burada listelenir ve sesli bildirim verilir.
            </p>
            {!scanStats.isScanning && (
              <button
                onClick={startLiveScan}
                className="mt-4 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-md shadow-emerald-600/20"
              >
                {t.startScan}
              </button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800/80 bg-slate-950/40 text-slate-400">
                  <th className="py-3 px-4 font-semibold">{t.tableCoin}</th>
                  <th className="py-3 px-4 font-semibold">{t.tableEntryPrice}</th>
                  <th className="py-3 px-4 font-semibold">{t.tableTargetPrice}</th>
                  <th className="py-3 px-4 font-semibold">{t.tableScore}</th>
                  <th className="py-3 px-4 font-semibold">{t.tableTime}</th>
                  <th className="py-3 px-4 font-semibold text-right">{t.tableDetails}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/50">
                {filteredSignals.map(sig => (
                  <tr
                    key={sig.id}
                    className="hover:bg-slate-800/40 transition-colors group cursor-pointer"
                    onClick={() => setSelectedSignalForModal(sig)}
                  >
                    <td className="py-3.5 px-4">
                      <div className="flex items-center space-x-2">
                        <span className="font-bold text-slate-100 text-sm">{sig.contract}</span>
                        <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                          LONG
                        </span>
                      </div>
                    </td>

                    <td className="py-3.5 px-4 font-mono font-medium text-slate-200">
                      ${sig.entryPrice.toLocaleString()}
                    </td>

                    <td className="py-3.5 px-4 font-mono">
                      <div className="flex items-center space-x-1.5">
                        <span className="font-bold text-emerald-400">
                          ${sig.targetPrice.toLocaleString()}
                        </span>
                        <span className="text-[10px] font-bold px-1 rounded bg-emerald-500/20 text-emerald-300">
                          +20%
                        </span>
                      </div>
                    </td>

                    <td className="py-3.5 px-4 font-mono">
                      <div className="flex items-center space-x-2">
                        <div className="w-16 h-2 rounded-full bg-slate-800 overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-teal-400 to-emerald-400 rounded-full"
                            style={{ width: `${Math.min(100, sig.score * 100)}%` }}
                          />
                        </div>
                        <span className="font-black text-cyan-300">
                          {(sig.score * 100).toFixed(1)}%
                        </span>
                      </div>
                    </td>

                    <td className="py-3.5 px-4 text-slate-400">
                      {new Date(sig.timestamp).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                        second: '2-digit'
                      })}
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <button
                        onClick={e => {
                          e.stopPropagation();
                          setSelectedSignalForModal(sig);
                        }}
                        className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>{t.tableDetails}</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
