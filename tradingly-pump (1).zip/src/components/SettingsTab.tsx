import { AlertTriangle, Bell, CheckCircle2, Copy, Download, ExternalLink, Info, Shield, ShieldAlert, ShieldCheck, Smartphone, Volume2, XCircle, Zap } from 'lucide-react';
import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { getAndroidProjectConfig, requestNotificationPermission, sendSignalNotification, startForegroundService, stopForegroundService, triggerBatteryOptimizationRequest } from '../services/nativeBridge';
import { playPumpAlertSound } from '../services/soundAlert';

export const SettingsTab: React.FC = () => {
  const {
    t,
    androidStatus,
    refreshAndroidStatus,
    soundEnabled,
    setSoundEnabled,
    setActiveTab
  } = useApp();

  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);

  const handleRequestPerm = async () => {
    const res = await requestNotificationPermission();
    await refreshAndroidStatus();
    if (res === 'granted') {
      sendSignalNotification('TEST_USDT', 0.842, 125.5);
      setFeedbackMsg('Bildirim izni verildi! Test bildirimi gönderildi.');
    } else {
      setFeedbackMsg('Bildirim izni verilmedi veya reddedildi.');
    }
    setTimeout(() => setFeedbackMsg(null), 4000);
  };

  const handleTestNotification = () => {
    sendSignalNotification('BTC_USDT', 0.885, 82450.0);
    playPumpAlertSound();
    setFeedbackMsg('Örnek PUMP sinyal bildirimi ve ses çalındı.');
    setTimeout(() => setFeedbackMsg(null), 3000);
  };

  const handleBatteryOpt = () => {
    const res = triggerBatteryOptimizationRequest();
    setFeedbackMsg(res.message);
    setTimeout(() => setFeedbackMsg(null), 6000);
  };

  const handleToggleService = async () => {
    if (androidStatus.foregroundServiceRunning || androidStatus.wakeLockActive) {
      await stopForegroundService();
    } else {
      await startForegroundService();
    }
    await refreshAndroidStatus();
  };

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const androidConfig = getAndroidProjectConfig();

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {feedbackMsg && (
        <div className="p-4 rounded-xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 text-xs flex items-center space-x-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{feedbackMsg}</span>
        </div>
      )}

      {/* Android Foreground Service Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100">
                {t.androidServiceHeading}
              </h3>
              <p className="text-xs text-slate-400">
                Uygulama arka plandayken veya ekran kapalıyken taramayı sürdürme sistemi
              </p>
            </div>
          </div>

          <span
            className={`px-3 py-1 rounded-full text-xs font-bold border ${
              androidStatus.isNative && androidStatus.foregroundServiceRunning
                ? 'bg-emerald-950 text-emerald-300 border-emerald-500/40'
                : 'bg-slate-800 text-slate-400 border-slate-700'
            }`}
          >
            {androidStatus.isNative
              ? androidStatus.foregroundServiceRunning
                ? 'Native Servis Açık'
                : 'Native Servis Kapalı'
              : 'Web Tarayıcı Modu'}
          </span>
        </div>

        {/* Truthful Status Notice */}
        <div
          className={`p-4 rounded-xl border text-xs space-y-2 ${
            androidStatus.isNative
              ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-300'
              : 'bg-slate-950 border-slate-800 text-slate-300'
          }`}
        >
          <div className="flex items-center space-x-2 font-semibold">
            {androidStatus.isNative ? (
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
            ) : (
              <Info className="w-4 h-4 text-cyan-400" />
            )}
            <span>
              {t.realStatus}: {androidStatus.environmentName}
            </span>
          </div>
          <p className="text-slate-400 text-[11px] leading-relaxed">
            {androidStatus.isNative
              ? 'Gerçek Android Foreground Service ve kalıcı durum çubuğu bildirimi kullanılabilir.'
              : 'Web tarayıcısında çalışmaktasınız. Arka planda taramanın kesilmemesi için Web Worker, Web Ekran Kilidi (WakeLock) ve HTML5 Bildirim İzinleri entegre edilmiştir. Kalıcı Android Foreground Service için aşağıdaki Capacitor dosyalarıyla APK oluşturabilirsiniz.'}
          </p>
        </div>

        {/* Action Buttons for Service */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
          <button
            onClick={handleToggleService}
            className={`flex items-center justify-center space-x-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              androidStatus.foregroundServiceRunning || androidStatus.wakeLockActive
                ? 'bg-rose-600 hover:bg-rose-500 text-white'
                : 'bg-emerald-600 hover:bg-emerald-500 text-white'
            }`}
          >
            <Shield className="w-4 h-4" />
            <span>
              {androidStatus.foregroundServiceRunning || androidStatus.wakeLockActive
                ? t.stopService
                : t.startService}
            </span>
          </button>

          <button
            onClick={handleRequestPerm}
            className="flex items-center justify-center space-x-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors cursor-pointer"
          >
            <Bell className="w-4 h-4 text-amber-400" />
            <span>{t.requestPerm}</span>
          </button>

          <button
            onClick={handleBatteryOpt}
            className="flex items-center justify-center space-x-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors cursor-pointer"
          >
            <Zap className="w-4 h-4 text-cyan-400" />
            <span>{t.openBatterySettings}</span>
          </button>
        </div>

        {/* Detailed Status Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3 text-xs">
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
            <span className="text-slate-500 block text-[10px]">{t.notificationPerm}</span>
            <span
              className={`font-semibold ${
                androidStatus.notificationPermission === 'granted'
                  ? 'text-emerald-400'
                  : 'text-amber-400'
              }`}
            >
              {androidStatus.notificationPermission === 'granted'
                ? t.permGranted
                : androidStatus.notificationPermission === 'denied'
                ? t.permDenied
                : t.permDefault}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
            <span className="text-slate-500 block text-[10px]">{t.wakeLockStatus}</span>
            <span
              className={`font-semibold ${
                androidStatus.wakeLockActive ? 'text-emerald-400' : 'text-slate-400'
              }`}
            >
              {androidStatus.wakeLockActive ? t.active : t.inactive}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
            <span className="text-slate-500 block text-[10px]">{t.batteryOpt}</span>
            <span
              className={`font-semibold ${
                androidStatus.batteryOptimizationIgnored ? 'text-emerald-400' : 'text-slate-400'
              }`}
            >
              {androidStatus.batteryOptimizationIgnored ? 'Muaf' : 'Kontrol Edilmedi'}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
            <span className="text-slate-500 block text-[10px]">Test Bildirimi</span>
            <button
              onClick={handleTestNotification}
              className="text-cyan-400 hover:text-cyan-300 font-semibold underline text-[11px]"
            >
              Bildirim Gönder
            </button>
          </div>
        </div>
      </div>

      {/* Model Strategy Specifications */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
            <Zap className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-100">{t.modelParams}</h3>
            <p className="text-xs text-slate-400">
              TRADINGLY PUMP matematiksel parametreleri ve kuralları
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-4 gap-3 text-xs">
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-500 block text-[10px] uppercase font-semibold">{t.modelThreshold}</span>
            <span className="text-base font-mono font-bold text-emerald-400">&ge; 0.81</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-500 block text-[10px] uppercase font-semibold">ATR Filtresi</span>
            <span className="text-base font-mono font-bold text-emerald-400">&ge; %1.00</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-500 block text-[10px] uppercase font-semibold">Bollinger Bant Genişliği</span>
            <span className="text-base font-mono font-bold text-emerald-400">&ge; %1.92</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-500 block text-[10px] uppercase font-semibold">{t.tpTarget}</span>
            <span className="text-base font-mono font-bold text-emerald-400">+%20.00</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-500 block text-[10px] uppercase font-semibold">{t.maxHold}</span>
            <span className="text-base font-mono font-bold text-slate-200">24 Saat (288 Mum)</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-500 block text-[10px] uppercase font-semibold">İşlem Yönü</span>
            <span className="text-base font-mono font-bold text-emerald-400">YALNIZCA LONG</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-500 block text-[10px] uppercase font-semibold">Mum Periyodu</span>
            <span className="text-base font-mono font-bold text-cyan-400">5 Dakika (5m)</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-500 block text-[10px] uppercase font-semibold">Toplam Gösterge</span>
            <span className="text-base font-mono font-bold text-amber-400">61 Özellik</span>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-400 space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-1.5 text-slate-200 font-semibold">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Orijinal Strateji & Algoritma Kuralları:</span>
            </div>
            <button
              onClick={() => setActiveTab('model')}
              className="px-3 py-1.5 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 text-[11px] font-bold transition-all cursor-pointer"
            >
              61 Göstergenin Tamamını ve Formüllerini İncele &rarr;
            </button>
          </div>
          <p>
            • Sinyal kriterleri sabittir. Canlı tarama ve geçmiş testi tamamen aynı deterministik çekirdeği (<code className="text-emerald-400">evaluatePumpModel</code>) kullanır.
          </p>
          <p>
            • Sinyal koşulları: <strong>Skor &ge; 0.81</strong> AND <strong>ATR &ge; %1.0</strong> AND <strong>Bollinger Genişliği &ge; %1.92</strong>.
          </p>
          <p>
            • Gelecekteki veriler (lookahead bias) kesinlikle kullanılmaz; yalnızca o an kapanmış olan ve geçmiş mumlar hesaplamaya dahil edilir.
          </p>
          <p>
            • Fitil hedefe dokunursa (+%20 tepe fiyata ulaşılırsa) işlem anında TP kabul edilir. 24 saat içinde TP vurulamazsa işlem 24 saat sonu olarak kapatılır.
          </p>
        </div>

        {/* Audio Alert switch */}
        <div className="flex items-center justify-between p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs">
          <div className="flex items-center space-x-3">
            <Volume2 className="w-5 h-5 text-emerald-400" />
            <div>
              <span className="font-semibold text-slate-200 block">{t.audioAlerts}</span>
              <span className="text-slate-500 text-[11px]">
                Yeni sinyal bulunduğunda sentetik Web Audio bildirim sesi çalar.
              </span>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => playPumpAlertSound()}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold transition-colors"
            >
              {t.testSound}
            </button>
            <input
              type="checkbox"
              checked={soundEnabled}
              onChange={e => setSoundEnabled(e.target.checked)}
              className="w-4 h-4 accent-emerald-500 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* Android Capacitor Export & Code Reference */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
        <div>
          <h3 className="text-base font-bold text-slate-100">{t.exportCapacitorFiles}</h3>
          <p className="text-xs text-slate-400 mt-0.5">{t.exportCapacitorDesc}</p>
        </div>

        <div className="space-y-3 text-xs">
          <div>
            <div className="flex items-center justify-between mb-1.5 text-slate-400">
              <span className="font-mono">capacitor.config.json</span>
              <button
                onClick={() =>
                  copyToClipboard(JSON.stringify(androidConfig.capacitorConfig, null, 2), 'cap')
                }
                className="text-emerald-400 hover:text-emerald-300 font-semibold"
              >
                {copiedKey === 'cap' ? 'Kopyalandı!' : 'Kopyala'}
              </button>
            </div>
            <pre className="p-3 rounded-xl bg-slate-950 border border-slate-800 font-mono text-[11px] text-slate-300 overflow-x-auto max-h-40">
              {JSON.stringify(androidConfig.capacitorConfig, null, 2)}
            </pre>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5 text-slate-400">
              <span className="font-mono">AndroidManifest.xml İzinleri</span>
              <button
                onClick={() => copyToClipboard(androidConfig.androidManifestSnippet, 'manifest')}
                className="text-emerald-400 hover:text-emerald-300 font-semibold"
              >
                {copiedKey === 'manifest' ? 'Kopyalandı!' : 'Kopyala'}
              </button>
            </div>
            <pre className="p-3 rounded-xl bg-slate-950 border border-slate-800 font-mono text-[11px] text-slate-300 overflow-x-auto max-h-40">
              {androidConfig.androidManifestSnippet}
            </pre>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5 text-slate-400">
              <span className="font-mono">ForegroundScanService.java (Kalıcı Bildirim Servisi)</span>
              <button
                onClick={() => copyToClipboard(androidConfig.javaForegroundServiceSnippet, 'java')}
                className="text-emerald-400 hover:text-emerald-300 font-semibold"
              >
                {copiedKey === 'java' ? 'Kopyalandı!' : 'Kopyala'}
              </button>
            </div>
            <pre className="p-3 rounded-xl bg-slate-950 border border-slate-800 font-mono text-[11px] text-slate-300 overflow-x-auto max-h-40">
              {androidConfig.javaForegroundServiceSnippet}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
