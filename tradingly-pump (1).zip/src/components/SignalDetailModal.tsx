import { ArrowUpRight, BarChart3, CheckCircle2, ExternalLink, SlidersHorizontal, X } from 'lucide-react';
import React, { useState } from 'react';
import { useApp } from '../context/AppContext';

export const SignalDetailModal: React.FC = () => {
  const { selectedSignalForModal, setSelectedSignalForModal, t } = useApp();
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  if (!selectedSignalForModal) return null;

  const signal = selectedSignalForModal;
  const categories = ['ALL', ...Array.from(new Set(signal.indicators.map(i => i.category)))];

  const filteredIndicators = selectedCategory === 'ALL'
    ? signal.indicators
    : signal.indicators.filter(i => i.category === selectedCategory);

  const gateUrl = `https://www.gate.io/futures/USDT/${signal.contract}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden text-slate-100">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/60">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <BarChart3 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-lg font-bold text-slate-100">{signal.contract}</h3>
                <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  LONG SİNYALİ
                </span>
                <span className="text-xs px-2 py-0.5 rounded-md bg-cyan-950/60 text-cyan-400 border border-cyan-800/40">
                  5m Mum
                </span>
              </div>
              <p className="text-xs text-slate-400">
                {new Date(signal.timestamp).toLocaleString()} · ID: {signal.id}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <a
              href={gateUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition-colors"
            >
              <span>{t.openTradingView}</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
            <button
              onClick={() => setSelectedSignalForModal(null)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Quick Metrics Banner */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 bg-slate-950/60 border-b border-slate-800 text-xs">
          <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
            <span className="text-slate-400 block">{t.tableEntryPrice}</span>
            <span className="text-base font-bold text-slate-100 font-mono">
              ${signal.entryPrice.toLocaleString()}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/30">
            <span className="text-emerald-400 block font-semibold">{t.tableTargetPrice}</span>
            <div className="flex items-center space-x-1">
              <span className="text-base font-bold text-emerald-300 font-mono">
                ${signal.targetPrice.toLocaleString()}
              </span>
              <span className="text-[10px] text-emerald-400 font-bold px-1 py-0.2 rounded bg-emerald-500/20">
                +20%
              </span>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
            <span className="text-slate-400 block">{t.tableScore}</span>
            <div className="flex items-center space-x-1.5">
              <span className="text-base font-black text-cyan-400 font-mono">
                {(signal.score * 100).toFixed(1)}%
              </span>
              <span className="text-[10px] text-slate-400">(Eşik: 81%)</span>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
            <span className="text-slate-400 block">Maksimum Süre</span>
            <span className="text-base font-bold text-slate-200">
              24 Saat <span className="text-xs font-normal text-slate-400">(288 Mum)</span>
            </span>
          </div>
        </div>

        {/* Category Filters */}
        <div className="flex items-center space-x-1.5 px-6 py-2.5 overflow-x-auto border-b border-slate-800/80 bg-slate-900/40 text-xs">
          <SlidersHorizontal className="w-3.5 h-3.5 text-slate-400 mr-1 shrink-0" />
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                selectedCategory === cat
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800'
              }`}
            >
              {cat === 'ALL' ? 'Tüm 61 Gösterge' : cat}
            </button>
          ))}
        </div>

        {/* Table of 61 Indicators */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="pb-2.5 font-semibold">{t.indicatorName}</th>
                <th className="pb-2.5 font-semibold">{t.category}</th>
                <th className="pb-2.5 font-semibold text-right">{t.value}</th>
                <th className="pb-2.5 font-semibold text-right">{t.weight}</th>
                <th className="pb-2.5 font-semibold text-right">{t.contribution}</th>
                <th className="pb-2.5 font-semibold hidden md:table-cell pl-4">{t.description}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredIndicators.map((ind, idx) => (
                <tr key={idx} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-2.5 font-mono font-medium text-emerald-300">
                    {ind.name}
                  </td>
                  <td className="py-2.5">
                    <span className="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-slate-300 border border-slate-700/50">
                      {ind.category}
                    </span>
                  </td>
                  <td className="py-2.5 text-right font-mono text-slate-200">
                    {Math.abs(ind.value) > 1000
                      ? ind.value.toLocaleString(undefined, { maximumFractionDigits: 0 })
                      : ind.value.toFixed(4)}
                  </td>
                  <td className="py-2.5 text-right font-mono text-slate-400">
                    {ind.weight > 0 ? `+${ind.weight.toFixed(1)}` : ind.weight.toFixed(1)}
                  </td>
                  <td className="py-2.5 text-right font-mono">
                    <span
                      className={
                        ind.contribution > 0
                          ? 'text-emerald-400 font-semibold'
                          : ind.contribution < 0
                          ? 'text-rose-400'
                          : 'text-slate-400'
                      }
                    >
                      {ind.contribution > 0 ? `+${ind.contribution.toFixed(3)}` : ind.contribution.toFixed(3)}
                    </span>
                  </td>
                  <td className="py-2.5 hidden md:table-cell pl-4 text-slate-400">
                    {ind.description}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-3.5 border-t border-slate-800 bg-slate-900/80 text-xs text-slate-400">
          <div className="flex items-center space-x-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>Matematiksel deterministik 61 gösterge doğrulaması tamamlandı.</span>
          </div>
          <button
            onClick={() => setSelectedSignalForModal(null)}
            className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium transition-colors"
          >
            {t.close}
          </button>
        </div>
      </div>
    </div>
  );
};
