import { Activity, Bell, Clock, Cpu, Globe, Play, Settings, ShieldCheck, Smartphone, Volume2, VolumeX } from 'lucide-react';
import React from 'react';
import { useApp } from '../context/AppContext';
import { playPumpAlertSound } from '../services/soundAlert';

export const Navbar: React.FC = () => {
  const {
    t,
    language,
    setLanguage,
    activeTab,
    setActiveTab,
    scanStats,
    soundEnabled,
    setSoundEnabled,
    androidStatus,
    trades
  } = useApp();

  const activeTradesCount = trades.filter(t => t.status === 'ACTIVE').length;

  return (
    <header className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur-md border-b border-slate-800 text-slate-100">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 via-teal-500 to-cyan-400 flex items-center justify-center shadow-lg shadow-emerald-500/20 ring-1 ring-emerald-400/40">
              <span className="text-xl font-black text-slate-950 tracking-tighter">TP</span>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-lg font-black tracking-wider bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400 bg-clip-text text-transparent">
                  TRADINGLY PUMP
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-950/80 text-emerald-400 border border-emerald-500/30">
                  LONG 5M
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">
                Gate.io USDT Futures · 61 Göstergeli Model (Eşik 0.81)
              </p>
            </div>
          </div>

          {/* Center Tabs */}
          <nav className="hidden md:flex items-center space-x-1 bg-slate-900/90 p-1.5 rounded-xl border border-slate-800">
            <button
              onClick={() => setActiveTab('scanner')}
              className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'scanner'
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <Activity className="w-4 h-4" />
              <span>{t.tabScanner}</span>
              {scanStats.isScanning && (
                <span className="w-2 h-2 rounded-full bg-emerald-300 animate-ping ml-1" />
              )}
            </button>

            <button
              onClick={() => setActiveTab('forward')}
              className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'forward'
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <Play className="w-4 h-4" />
              <span>{t.tabForwardTest}</span>
              {activeTradesCount > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold">
                  {activeTradesCount}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('backtest')}
              className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'backtest'
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <Clock className="w-4 h-4" />
              <span>{t.tabBacktest}</span>
            </button>

            <button
              onClick={() => setActiveTab('model')}
              className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'model'
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <Cpu className="w-4 h-4" />
              <span>{t.tabModel}</span>
            </button>

            <button
              onClick={() => setActiveTab('settings')}
              className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'settings'
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <Smartphone className="w-4 h-4" />
              <span>{t.tabSettings}</span>
            </button>
          </nav>

          {/* Right Controls */}
          <div className="flex items-center space-x-2">
            {/* Live Scan Status Pill */}
            <div className="hidden lg:flex items-center space-x-2 px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-[11px]">
              <span
                className={`w-2 h-2 rounded-full ${
                  scanStats.isScanning
                    ? 'bg-emerald-400 animate-pulse'
                    : scanStats.nextScanCountdown > 0
                    ? 'bg-amber-400'
                    : 'bg-slate-500'
                }`}
              />
              <span className="text-slate-300 font-medium">
                {scanStats.isScanning
                  ? `${t.scanning} (${scanStats.scannedCoins}/${scanStats.totalCoins})`
                  : scanStats.nextScanCountdown > 0
                  ? `${t.autoRescanIn} ${scanStats.nextScanCountdown}s`
                  : t.idle}
              </span>
            </div>

            {/* Android / Web Environment Indicator */}
            <div
              onClick={() => setActiveTab('settings')}
              title={androidStatus.environmentName}
              className={`cursor-pointer hidden sm:flex items-center space-x-1.5 px-2.5 py-1 rounded-lg text-[11px] font-medium border transition-colors ${
                androidStatus.isNative && androidStatus.foregroundServiceRunning
                  ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-300'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
              }`}
            >
              {androidStatus.isNative ? (
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              ) : (
                <Smartphone className="w-3.5 h-3.5 text-slate-400" />
              )}
              <span className="truncate max-w-[110px]">
                {androidStatus.isNative ? 'Android Servis' : 'Web Modu'}
              </span>
            </div>

            {/* Audio Toggle */}
            <button
              onClick={() => {
                const next = !soundEnabled;
                setSoundEnabled(next);
                if (next) playPumpAlertSound();
              }}
              title={t.audioAlerts}
              className={`p-2 rounded-lg border text-xs transition-colors ${
                soundEnabled
                  ? 'bg-emerald-950/50 border-emerald-500/40 text-emerald-400'
                  : 'bg-slate-900 border-slate-800 text-slate-500 hover:text-slate-300'
              }`}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>

            {/* Language Switcher */}
            <button
              onClick={() => setLanguage(language === 'tr' ? 'en' : 'tr')}
              className="flex items-center space-x-1 px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs font-semibold text-slate-300 hover:bg-slate-800 transition-colors"
            >
              <Globe className="w-3.5 h-3.5 text-emerald-400" />
              <span>{language.toUpperCase()}</span>
            </button>
          </div>
        </div>

        {/* Mobile Subnav */}
        <div className="flex md:hidden items-center justify-around py-2 border-t border-slate-800/80 text-xs">
          <button
            onClick={() => setActiveTab('scanner')}
            className={`flex items-center space-x-1.5 py-1 px-2 rounded-md ${
              activeTab === 'scanner' ? 'text-emerald-400 font-bold' : 'text-slate-400'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span>{t.tabScanner}</span>
          </button>
          <button
            onClick={() => setActiveTab('forward')}
            className={`flex items-center space-x-1.5 py-1 px-2 rounded-md ${
              activeTab === 'forward' ? 'text-emerald-400 font-bold' : 'text-slate-400'
            }`}
          >
            <Play className="w-3.5 h-3.5" />
            <span>{t.tabForwardTest}</span>
            {activeTradesCount > 0 && (
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('backtest')}
            className={`flex items-center space-x-1.5 py-1 px-2 rounded-md ${
              activeTab === 'backtest' ? 'text-emerald-400 font-bold' : 'text-slate-400'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>{t.tabBacktest}</span>
          </button>
          <button
            onClick={() => setActiveTab('model')}
            className={`flex items-center space-x-1.5 py-1 px-2 rounded-md ${
              activeTab === 'model' ? 'text-emerald-400 font-bold' : 'text-slate-400'
            }`}
          >
            <Cpu className="w-3.5 h-3.5" />
            <span>{t.tabModel}</span>
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`flex items-center space-x-1.5 py-1 px-2 rounded-md ${
              activeTab === 'settings' ? 'text-emerald-400 font-bold' : 'text-slate-400'
            }`}
          >
            <Settings className="w-3.5 h-3.5" />
            <span>{t.tabSettings}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
