import {
  Activity,
  AlertCircle,
  Calendar,
  CheckCircle2,
  ChevronDown,
  Clock,
  Download,
  ExternalLink,
  FileArchive,
  Filter,
  Info,
  Pause,
  Play,
  RefreshCw,
  Search,
  ShieldCheck,
  Square,
  TrendingUp,
  XCircle,
  Zap
} from 'lucide-react';
import React, { useEffect, useRef, useState } from 'react';
import { useApp } from '../context/AppContext';
import { BacktestEngine } from '../services/backtestEngine';
import { fetchGateContractReport } from '../services/gateApi';
import {
  BacktestConfig,
  BacktestProgress,
  BacktestSummary,
  CoinBacktestStatus,
  TradeRecord
} from '../types';

export const BacktestTab: React.FC = () => {
  const { t } = useApp();

  // 1. Initial Dates: 01.01.2026 to today (2026-10-17)
  const [startDate, setStartDate] = useState('2026-01-01');
  const [endDate, setEndDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [coinMode, setCoinMode] = useState<'ALL' | 'TOP_VOLUME'>('ALL');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  const [contractReport, setContractReport] = useState<{ totalApi: number; filtered: number; eligible: number } | null>(null);

  useEffect(() => {
    fetchGateContractReport().then(report => {
      setContractReport({
        totalApi: report.totalApiContracts,
        filtered: report.filteredNonCryptoCount,
        eligible: report.eligibleCoinsCount
      });
    }).catch(() => {});
  }, []);

  const [isRunning, setIsRunning] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [progress, setProgress] = useState<BacktestProgress | null>(null);
  const [trades, setTrades] = useState<TradeRecord[]>([]);
  const [summary, setSummary] = useState<BacktestSummary>({
    totalSignals: 0,
    tpHitCount: 0,
    expired24hCount: 0,
    activeCount: 0,
    missingDataCount: 0,
    successfulCoinsCount: 0,
    notListedYetCount: 0,
    insufficientDataCount: 0,
    apiErrorCount: 0,
    corsErrorCount: 0,
    rateLimitCount: 0,
    invalidDataCount: 0,
    retriedCoinsCount: 0,
    winRatePct: 0,
    avgGainPct: 0,
    avgDurationMinutes: 0,
    bestTrade: null,
    worstTrade: null,
    totalPnlPct: 0
  });

  // Per-coin test tracking state for Step 1 (BTC), Step 2 (ETH), Step 3 (SOL)
  const [testingCoin, setTestingCoin] = useState<string | null>(null);
  const [coinTestResults, setCoinTestResults] = useState<Record<string, {
    downloadedCandles: number;
    processedCandles: number;
    signalsCount: number;
    durationMs: number;
    speed: number;
    status: 'SUCCESS' | 'FAILED';
    firstCandleDate?: string;
    lastCandleDate?: string;
    error?: string;
  }>>({});

  const btcVerified = Boolean(coinTestResults['BTC_USDT']?.status === 'SUCCESS');
  const ethVerified = Boolean(coinTestResults['ETH_USDT']?.status === 'SUCCESS');
  const solVerified = Boolean(coinTestResults['SOL_USDT']?.status === 'SUCCESS');
  const all3Verified = btcVerified && ethVerified && solVerified;

  const engineRef = useRef<BacktestEngine | null>(null);

  // Runs real 61-feature backtest on a single coin
  const handleRunSingleTest = async (coinName: string) => {
    setTestingCoin(coinName);
    setIsRunning(true);
    setIsPaused(false);
    setTrades([]);
    setProgress(null);

    const config: BacktestConfig = {
      startDate,
      endDate,
      coinMode: 'CUSTOM',
      customCoins: [coinName],
      modelThreshold: 0.81,
      tpTargetPct: 20.0,
      maxDurationHours: 24
    };

    const engine = new BacktestEngine(config);
    engineRef.current = engine;

    const tStart = Date.now();

    engine.setCallback((prog, currentTrades, currentSummary) => {
      setProgress(prog);
      setTrades([...currentTrades]);
      setSummary(currentSummary);
      setIsPaused(prog.isPaused);
      setIsRunning(prog.isRunning);
    });

    try {
      const res = await engine.run();
      const elapsedMs = Math.max(1, Date.now() - tStart);
      const coinStat = engine.getCoinStatuses().find(c => c.contract === coinName);

      const downloaded = coinStat?.downloadedCandles || 0;
      const processed = coinStat?.processedCandles || 0;
      const signals = res.trades.length;
      const speed = Math.round(processed / (elapsedMs / 1000));

      setCoinTestResults(prev => ({
        ...prev,
        [coinName]: {
          downloadedCandles: downloaded,
          processedCandles: processed,
          signalsCount: signals,
          durationMs: elapsedMs,
          speed,
          status: downloaded > 0 && processed > 0 ? 'SUCCESS' : 'FAILED',
          firstCandleDate: coinStat?.firstCandleDate,
          lastCandleDate: coinStat?.lastCandleDate,
          error: coinStat?.error
        }
      }));
    } catch (e: any) {
      setCoinTestResults(prev => ({
        ...prev,
        [coinName]: {
          downloadedCandles: 0,
          processedCandles: 0,
          signalsCount: 0,
          durationMs: 0,
          speed: 0,
          status: 'FAILED',
          error: e.message
        }
      }));
    } finally {
      setIsRunning(false);
      setIsPaused(false);
      setTestingCoin(null);
    }
  };

  // Runs sequential verification on all 3 base coins (BTC, ETH, SOL)
  const handleRunTripleTest = async () => {
    setTestingCoin('TRIPLE');
    setIsRunning(true);
    setIsPaused(false);
    setTrades([]);
    setProgress(null);

    const config: BacktestConfig = {
      startDate,
      endDate,
      coinMode: 'CUSTOM',
      customCoins: ['BTC_USDT', 'ETH_USDT', 'SOL_USDT'],
      modelThreshold: 0.81,
      tpTargetPct: 20.0,
      maxDurationHours: 24
    };

    const engine = new BacktestEngine(config);
    engineRef.current = engine;

    const tStart = Date.now();

    engine.setCallback((prog, currentTrades, currentSummary) => {
      setProgress(prog);
      setTrades([...currentTrades]);
      setSummary(currentSummary);
      setIsPaused(prog.isPaused);
      setIsRunning(prog.isRunning);
    });

    try {
      const res = await engine.run();
      const statuses = engine.getCoinStatuses();
      const newResults: any = {};
      for (const coin of ['BTC_USDT', 'ETH_USDT', 'SOL_USDT']) {
        const cs = statuses.find(s => s.contract === coin);
        const coinTrades = res.trades.filter(t => t.contract === coin);
        if (cs) {
          newResults[coin] = {
            downloadedCandles: cs.downloadedCandles,
            processedCandles: cs.processedCandles,
            signalsCount: coinTrades.length,
            durationMs: Math.round((Date.now() - tStart) / 3),
            speed: Math.round(cs.processedCandles / 1.0),
            status: cs.downloadedCandles > 0 && cs.processedCandles > 0 ? 'SUCCESS' : 'FAILED',
            firstCandleDate: cs.firstCandleDate,
            lastCandleDate: cs.lastCandleDate,
            error: cs.error
          };
        }
      }
      setCoinTestResults(prev => ({ ...prev, ...newResults }));
    } catch (e: any) {
      alert('3 Coin test hatası: ' + e.message);
    } finally {
      setIsRunning(false);
      setIsPaused(false);
      setTestingCoin(null);
    }
  };

  const handleStart = async () => {
    // Reset previous run counters and trades cleanly so old state does not mix
    setTrades([]);
    setProgress(null);
    setSummary({
      totalSignals: 0,
      tpHitCount: 0,
      expired24hCount: 0,
      activeCount: 0,
      missingDataCount: 0,
      successfulCoinsCount: 0,
      notListedYetCount: 0,
      insufficientDataCount: 0,
      apiErrorCount: 0,
      corsErrorCount: 0,
      rateLimitCount: 0,
      invalidDataCount: 0,
      retriedCoinsCount: 0,
      winRatePct: 0,
      avgGainPct: 0,
      avgDurationMinutes: 0,
      bestTrade: null,
      worstTrade: null,
      totalPnlPct: 0
    });

    const config: BacktestConfig = {
      startDate,
      endDate,
      coinMode,
      customCoins: [],
      modelThreshold: 0.81,
      tpTargetPct: 20.0,
      maxDurationHours: 24
    };

    const engine = new BacktestEngine(config);
    engineRef.current = engine;

    setIsRunning(true);
    setIsPaused(false);

    engine.setCallback((prog, currentTrades, currentSummary) => {
      setProgress(prog);
      setTrades([...currentTrades]);
      setSummary(currentSummary);
      setIsPaused(prog.isPaused);
      setIsRunning(prog.isRunning);
    });

    try {
      await engine.run();
    } catch (e) {
      console.error('Backtest error:', e);
    } finally {
      setIsRunning(false);
      setIsPaused(false);
    }
  };

  const handlePause = () => {
    if (engineRef.current) {
      engineRef.current.pause();
      setIsPaused(true);
    }
  };

  const handleResume = () => {
    if (engineRef.current) {
      engineRef.current.resume();
      setIsPaused(false);
    }
  };

  const handleStop = () => {
    if (engineRef.current) {
      engineRef.current.stop();
      setIsRunning(false);
      setIsPaused(false);
    }
  };

  const handleExportZip = async () => {
    if (trades.length === 0 && (!progress || progress.coinStatuses.length === 0)) return;
    try {
      const engine = engineRef.current || new BacktestEngine({
        startDate,
        endDate,
        coinMode,
        customCoins: [],
        modelThreshold: 0.81,
        tpTargetPct: 20.0,
        maxDurationHours: 24
      });

      (engine as any).trades = trades;
      if (progress?.coinStatuses) {
        (engine as any).coinStatuses = progress.coinStatuses;
      }

      const blob = await engine.exportAsZip(summary);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `TRADINGLY_PUMP_Backtest_${startDate}_${endDate}.zip`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err: any) {
      alert('ZIP indirme hatası: ' + err.message);
    }
  };

  const handleExportCsv = () => {
    if (trades.length === 0) return;
    const csvRows = [
      'ID,Tarih,Coin,Giris_Fiyati,Hedef_Fiyat_20,Durum,En_Yuksek_Fiyat,En_Yuksek_Kar_Yuzdesi,Sonuc_Fiyat,Sonuc_Kar_Yuzdesi,Sure_Dakika,Pump_Model_Skoru'
    ];

    for (const t of trades) {
      const dateStr = new Date(t.signalTime).toISOString();
      csvRows.push(
        `"${t.id}","${dateStr}","${t.contract}",${t.entryPrice},${t.targetPrice},"${t.status}",${t.highestPrice},${t.highestGainPct}%,${t.currentOrExitPrice},${t.currentOrExitGainPct}%,${t.durationMinutes},${t.score}`
      );
    }

    const blob = new Blob([csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `TRADINGLY_PUMP_Signals_${startDate}_${endDate}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const filteredTrades = trades.filter(t =>
    t.contract.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredCoins = (progress?.coinStatuses || []).filter(c => {
    const matchSearch = c.contract.toLowerCase().includes(searchTerm.toLowerCase());
    if (statusFilter === 'ALL') return matchSearch;
    return matchSearch && c.status === statusFilter;
  });

  const percentProgress = progress && progress.totalContracts > 0
    ? Math.min(100, Math.round((progress.processedContracts / progress.totalContracts) * 100))
    : 0;

  return (
    <div className="space-y-6">
      {/* 1. Step-by-Step Verification Card: BTC -> ETH -> SOL (User Directive) */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-emerald-950/40 border border-emerald-500/30 rounded-2xl p-4 sm:p-5 shadow-xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          <div className="flex items-start space-x-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0 mt-0.5">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-sm font-bold text-slate-100">
                  Aşama 1: Gerçek Motor Doğrulaması (BTC &rarr; ETH &rarr; SOL)
                </h3>
                {all3Verified ? (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center space-x-1">
                    <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                    <span>3/3 Temel Coin Doğrulandı &mdash; 1040 Coin Kilidi Açık</span>
                  </span>
                ) : btcVerified ? (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 flex items-center space-x-1">
                    <CheckCircle2 className="w-3 h-3 text-cyan-400" />
                    <span>BTC Doğrulandı</span>
                  </span>
                ) : (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40">
                    Önce BTC_USDT Testi Zorunlu
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                01.01.2026'dan bugüne kadar gerçek Gate 5m mumlarını indirir, işlenen mumları hesaplar ve 61 göstergeli algoritmayı çalıştırır.
              </p>
            </div>
          </div>

          {/* Verification Action Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => handleRunSingleTest('BTC_USDT')}
              disabled={isRunning}
              className={`flex items-center space-x-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer disabled:opacity-50 ${
                btcVerified
                  ? 'bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-emerald-500/40'
                  : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-600/30'
              }`}
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>{testingCoin === 'BTC_USDT' ? 'BTC Test Ediliyor...' : '1. BTC_USDT Testi Yap'}</span>
            </button>

            <button
              onClick={() => handleRunSingleTest('ETH_USDT')}
              disabled={isRunning}
              className={`flex items-center space-x-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer disabled:opacity-50 ${
                ethVerified
                  ? 'bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-500/40'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
              }`}
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>{testingCoin === 'ETH_USDT' ? 'ETH Test Ediliyor...' : '2. ETH_USDT Testi Yap'}</span>
            </button>

            <button
              onClick={() => handleRunSingleTest('SOL_USDT')}
              disabled={isRunning}
              className={`flex items-center space-x-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer disabled:opacity-50 ${
                solVerified
                  ? 'bg-slate-800 hover:bg-slate-700 text-purple-300 border border-purple-500/40'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
              }`}
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>{testingCoin === 'SOL_USDT' ? 'SOL Test Ediliyor...' : '3. SOL_USDT Testi Yap'}</span>
            </button>

            <button
              onClick={handleRunTripleTest}
              disabled={isRunning}
              className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-all cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${testingCoin === 'TRIPLE' ? 'animate-spin' : ''}`} />
              <span>3'lü Doğrula (BTC+ETH+SOL)</span>
            </button>
          </div>
        </div>

        {/* Verification 3-Coin Cards Display */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-4 pt-3 border-t border-slate-800 text-xs">
          {['BTC_USDT', 'ETH_USDT', 'SOL_USDT'].map((coin) => {
            const r = coinTestResults[coin];
            const isCurrentTesting = testingCoin === coin || (testingCoin === 'TRIPLE' && isRunning);
            return (
              <div
                key={coin}
                className={`p-3.5 rounded-xl border transition-all ${
                  r?.status === 'SUCCESS'
                    ? 'bg-emerald-950/20 border-emerald-500/30 text-emerald-300'
                    : isCurrentTesting
                    ? 'bg-cyan-950/20 border-cyan-500/30 text-cyan-300 animate-pulse'
                    : 'bg-slate-950/40 border-slate-800/80 text-slate-400'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-100 text-sm">{coin}</span>
                  <span
                    className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                      r?.status === 'SUCCESS'
                        ? 'bg-emerald-900/60 text-emerald-300'
                        : isCurrentTesting
                        ? 'bg-cyan-900/60 text-cyan-300'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {r?.status === 'SUCCESS' ? 'DOĞRULANDI' : isCurrentTesting ? 'TEST EDİLİYOR' : 'BEKLİYOR'}
                  </span>
                </div>
                <div className="mt-2.5 text-[11px] text-slate-300 space-y-1 font-mono">
                  <div className="flex justify-between">
                    <span className="text-slate-400">İndirilen Mum:</span>
                    <strong className="text-cyan-300">{r?.downloadedCandles?.toLocaleString() || '---'}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">İşlenen Mum:</span>
                    <strong className="text-slate-100">{r?.processedCandles?.toLocaleString() || '---'}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Üretilen Sinyal:</span>
                    <strong className="text-emerald-400">{r ? r.signalsCount : '---'}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Tamamlanma Süresi:</span>
                    <strong className="text-amber-300">
                      {r ? `${(r.durationMs / 1000).toFixed(2)} sn (${r.speed?.toLocaleString()} mum/sn)` : '---'}
                    </strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Model Doğruluğu:</span>
                    <strong className={r?.status === 'SUCCESS' ? 'text-emerald-400' : 'text-slate-500'}>
                      {r?.status === 'SUCCESS' ? '61 Gösterge Tam Uyum' : 'Test Edilmedi'}
                    </strong>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Gate API Contract Verification Breakdown Bar */}
        <div className="mt-3.5 pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between text-[11px] text-slate-400 gap-2">
          <div className="flex items-center space-x-3">
            <span>Gate API Toplam Sözleşme: <strong className="text-slate-200">{contractReport?.totalApi || progress?.totalApiContracts || 1040}</strong></span>
            <span className="text-slate-600">&bull;</span>
            <span>Filtrelenen (Hisse/Endeks/Emtia/Ön-pazar): <strong className="text-amber-300">-{contractReport?.filtered || progress?.filteredContractsCount || 451}</strong></span>
            <span className="text-slate-600">&bull;</span>
            <span>Taranacak Aktif Kripto Perpetual: <strong className="text-emerald-400">{contractReport?.eligible || progress?.totalContracts || 589}</strong></span>
          </div>
          <span className="text-emerald-400 font-mono">
            {all3Verified
              ? '✅ 3 Temel Coin Doğrulandı — Tüm Kripto Coinlerin Taraması Güvenle Yapılabilir'
              : btcVerified
              ? '✅ BTC_USDT Doğrulandı — ETH ve SOL test edilebilir'
              : '⚠️ Önce BTC_USDT Testi Yapılmalıdır'}
          </span>
        </div>
      </div>

      {/* 2. Main Backtest Configuration Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-6 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <Clock className="w-5 h-5 text-emerald-400" />
              <h2 className="text-xl font-black text-slate-100 tracking-wide">
                {t.backtestTitle}
              </h2>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-500/30 font-semibold">
                Gate USDT Vadeli 5m
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1 max-w-2xl">
              01.01.2026'dan bugüne kadar olan gerçek 5m mumlarını indirir ve analiz eder.
              <span className="text-emerald-400 font-semibold ml-1">
                Kriterler: Sadece LONG | Eşik &ge; 0.81 | ATR &ge; %1.0 | Bollinger Genişliği &ge; 1.92% | TP +%20 | 24 Saat.
              </span>
            </p>
          </div>

          {/* Export Actions */}
          {(trades.length > 0 || (progress && progress.processedContracts > 0)) && (
            <div className="flex items-center space-x-2">
              <button
                onClick={handleExportZip}
                className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold shadow-md shadow-emerald-700/20 transition-all cursor-pointer"
              >
                <FileArchive className="w-4 h-4" />
                <span>{t.exportZip}</span>
              </button>
              {trades.length > 0 && (
                <button
                  onClick={handleExportCsv}
                  className="flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold border border-slate-700 transition-colors cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{t.exportCsv}</span>
                </button>
              )}
            </div>
          )}
        </div>

        {/* Inputs & Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-6 pt-5 border-t border-slate-800 text-xs">
          {/* Start Date: Defaults to 2026-01-01 */}
          <div>
            <label className="text-slate-400 block mb-1.5 font-medium flex items-center space-x-1">
              <Calendar className="w-3.5 h-3.5 text-emerald-400" />
              <span>{t.startDate}</span>
            </label>
            <input
              type="date"
              min="2023-01-01"
              max={endDate}
              value={startDate}
              onChange={e => setStartDate(e.target.value)}
              disabled={isRunning}
              className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 focus:outline-none focus:border-emerald-500 font-mono disabled:opacity-50"
            />
          </div>

          {/* End Date: Defaults to today (2026-10-17) */}
          <div>
            <label className="text-slate-400 block mb-1.5 font-medium flex items-center space-x-1">
              <Calendar className="w-3.5 h-3.5 text-cyan-400" />
              <span>{t.endDate}</span>
            </label>
            <input
              type="date"
              min={startDate}
              max={new Date().toISOString().split('T')[0]}
              value={endDate}
              onChange={e => setEndDate(e.target.value)}
              disabled={isRunning}
              className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 focus:outline-none focus:border-emerald-500 font-mono disabled:opacity-50"
            />
          </div>

          {/* Coin Scope Selection */}
          <div>
            <label className="text-slate-400 block mb-1.5 font-medium">
              {t.coinSelection}
            </label>
            <select
              value={coinMode}
              onChange={e => setCoinMode(e.target.value as any)}
              disabled={isRunning}
              className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 focus:outline-none focus:border-emerald-500 disabled:opacity-50"
            >
              <option value="ALL">Bütün Kripto USDT Vadeli Coinler (~{contractReport?.eligible || 589} Coin)</option>
              <option value="TOP_VOLUME">Yüksek Hacimli 24 Coin (Hızlı Test)</option>
            </select>
          </div>

          {/* Run Control Buttons */}
          <div className="flex items-end space-x-2">
            {!isRunning ? (
              <button
                onClick={() => {
                  if (!btcVerified && coinMode === 'ALL') {
                    handleRunSingleTest('BTC_USDT');
                  } else {
                    handleStart();
                  }
                }}
                className={`w-full flex items-center justify-center space-x-2 px-4 py-2.5 rounded-xl text-white text-xs font-bold shadow-lg transition-all cursor-pointer ${
                  !btcVerified && coinMode === 'ALL'
                    ? 'bg-amber-600 hover:bg-amber-500 shadow-amber-600/30'
                    : 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-600/30'
                }`}
              >
                <Play className="w-4 h-4 fill-white" />
                <span>
                  {!btcVerified && coinMode === 'ALL'
                    ? 'Önce BTC_USDT Testini Başlat'
                    : all3Verified
                    ? `Tüm Coinleri Tara (${contractReport?.eligible || 589} Coin)`
                    : t.startBacktest}
                </span>
              </button>
            ) : (
              <>
                {isPaused ? (
                  <button
                    onClick={handleResume}
                    className="flex-1 flex items-center justify-center space-x-1 px-3 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold transition-all cursor-pointer"
                  >
                    <Play className="w-3.5 h-3.5 fill-white" />
                    <span>{t.resumeBacktest}</span>
                  </button>
                ) : (
                  <button
                    onClick={handlePause}
                    className="flex-1 flex items-center justify-center space-x-1 px-3 py-2.5 rounded-xl bg-amber-600/90 hover:bg-amber-500 text-white text-xs font-bold transition-all cursor-pointer"
                  >
                    <Pause className="w-3.5 h-3.5" />
                    <span>{t.pauseBacktest}</span>
                  </button>
                )}
                <button
                  onClick={handleStop}
                  className="flex-1 flex items-center justify-center space-x-1 px-3 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-all cursor-pointer"
                >
                  <Square className="w-3.5 h-3.5 fill-white" />
                  <span>{t.stopBacktest}</span>
                </button>
              </>
            )}
          </div>
        </div>

        {/* 3. Dual Progress & Speed Section (Requirement 7) */}
        {progress && (
          <div className="mt-5 pt-4 border-t border-slate-800 space-y-3 text-xs">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between text-slate-300 gap-2 font-mono">
              <div className="flex items-center space-x-2">
                <RefreshCw className={`w-3.5 h-3.5 text-emerald-400 ${isRunning && !isPaused ? 'animate-spin' : ''}`} />
                <span className="font-semibold text-slate-100">
                  {progress.isRunning
                    ? `İşlenen Coin: ${progress.currentContract}`
                    : progress.isPaused
                    ? 'Tarama Duraklatıldı'
                    : 'Tarama Tamamlandı'}
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-3 text-xs">
                <span className="p-1 px-2 rounded bg-slate-950 border border-slate-800">
                  Coin: <strong className="text-emerald-400">{progress.processedContracts}/{progress.totalContracts}</strong>
                </span>
                <span className="p-1 px-2 rounded bg-slate-950 border border-slate-800">
                  İndirilen Mum: <strong className="text-cyan-400">{progress.downloadedCandles.toLocaleString()}</strong>
                </span>
                <span className="p-1 px-2 rounded bg-slate-950 border border-slate-800">
                  İşlenen Mum: <strong className="text-slate-100">{progress.processedCandles.toLocaleString()}</strong>
                </span>
                <span className="p-1 px-2 rounded bg-slate-950 border border-slate-800">
                  Hız: <strong className="text-amber-300">{progress.speedCandlesPerSec.toLocaleString()} mum/sn</strong>
                </span>
              </div>
            </div>

            <div className="w-full h-2.5 rounded-full bg-slate-800 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-emerald-500 via-teal-400 to-cyan-400 transition-all duration-300 rounded-full"
                style={{ width: `${percentProgress}%` }}
              />
            </div>
          </div>
        )}
      </div>

      {/* 4. Granular Real Counters Summary Grid (Requirements 7 & 10) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2.5 text-xs">
        <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] text-slate-400 block font-medium">Toplam Coin</span>
          <span className="text-lg font-black text-slate-100 font-mono">
            {progress?.totalContracts || (coinMode === 'ALL' ? (contractReport?.eligible || 589) : 24)}
          </span>
        </div>

        <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] text-slate-400 block font-medium">Tamamlanan</span>
          <span className="text-lg font-bold text-slate-200 font-mono">
            {progress?.processedContracts || 0}
          </span>
        </div>

        <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] text-emerald-400 block font-medium">Başarılı Coin</span>
          <span className="text-lg font-black text-emerald-300 font-mono">
            {summary.successfulCoinsCount}
          </span>
        </div>

        <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] text-slate-400 block font-medium">Henüz Listelenmemiş</span>
          <span className="text-lg font-bold text-slate-400 font-mono">
            {summary.notListedYetCount}
          </span>
        </div>

        <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] text-amber-400 block font-medium">Eksik Mum Verisi</span>
          <span className="text-lg font-bold text-amber-300 font-mono">
            {summary.insufficientDataCount}
          </span>
        </div>

        <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] text-rose-400 block font-medium">API Hatası</span>
          <span className="text-lg font-bold text-rose-400 font-mono">
            {summary.apiErrorCount}
          </span>
        </div>

        <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] text-emerald-400 block font-semibold">TP (+%20)</span>
          <span className="text-lg font-black text-emerald-300 font-mono">
            {summary.tpHitCount}
          </span>
        </div>

        <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] text-slate-400 block font-medium">24s Kapanan</span>
          <span className="text-lg font-bold text-slate-300 font-mono">
            {summary.expired24hCount}
          </span>
        </div>
      </div>

      {/* 5. Results & Performance Highlights */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-[11px] text-slate-400 block font-medium">{t.totalSignalsCount}</span>
          <div className="flex items-baseline space-x-2 mt-1">
            <span className="text-2xl font-black text-slate-100 font-mono">
              {summary.totalSignals}
            </span>
            <span className="text-xs text-slate-500">PUMP Sinyali</span>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-[11px] text-teal-400 block font-medium">{t.avgDuration}</span>
          <div className="flex items-baseline space-x-1 mt-1">
            <span className="text-2xl font-bold text-teal-300 font-mono">
              {summary.avgDurationMinutes > 60
                ? `${Math.round(summary.avgDurationMinutes / 60)}`
                : `${summary.avgDurationMinutes}`}
            </span>
            <span className="text-xs text-slate-400">
              {summary.avgDurationMinutes > 60 ? 'saat' : 'dk'}
            </span>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-[11px] text-cyan-400 block font-medium">Toplam Kümülatif Kâr</span>
          <div className="flex items-baseline space-x-1 mt-1">
            <span
              className={`text-2xl font-black font-mono ${
                summary.totalPnlPct >= 0 ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {summary.totalPnlPct >= 0 ? `+${summary.totalPnlPct}%` : `${summary.totalPnlPct}%`}
            </span>
          </div>
        </div>

        {/* Win Rate: Calculated ONLY on completed trades */}
        <div className="p-4 rounded-xl bg-gradient-to-br from-emerald-950/60 to-slate-900 border border-emerald-500/40">
          <span className="text-[11px] text-emerald-400 block font-bold">{t.winRate}</span>
          <div className="flex items-baseline space-x-2 mt-1">
            <span className="text-2xl font-black text-emerald-300 font-mono">
              %{summary.winRatePct}
            </span>
            <span className="text-[10px] text-slate-400">
              ({summary.tpHitCount + summary.expired24hCount} tamamlanan)
            </span>
          </div>
        </div>
      </div>

      {/* 6. Per-Coin Real Status Audit Table (Requirement 2) */}
      {progress && progress.coinStatuses.length > 0 && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl overflow-hidden">
          <div className="p-4 sm:p-5 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center space-x-2">
              <Activity className="w-5 h-5 text-cyan-400" />
              <h3 className="text-base font-bold text-slate-100">
                Coin Durum & Veri Denetim Kayıtları ({filteredCoins.length})
              </h3>
            </div>

            <div className="flex items-center space-x-2">
              <select
                value={statusFilter}
                onChange={e => setStatusFilter(e.target.value)}
                className="px-2.5 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 focus:outline-none"
              >
                <option value="ALL">Tüm Durumlar</option>
                <option value="COMPLETED">Tamamlandı</option>
                <option value="ANALYZING">Analiz Ediliyor</option>
                <option value="DOWNLOADING">Veri İndiriliyor</option>
                <option value="NOT_LISTED">Henüz Listelenmemiş</option>
                <option value="MISSING_DATA">Eksik Veri</option>
                <option value="API_ERROR">API Hatası</option>
              </select>
            </div>
          </div>

          <div className="overflow-x-auto max-h-80 overflow-y-auto">
            <table className="w-full text-left text-xs">
              <thead className="sticky top-0 bg-slate-950 z-10 border-b border-slate-800 text-slate-400">
                <tr>
                  <th className="py-2.5 px-4 font-semibold">Coin</th>
                  <th className="py-2.5 px-4 font-semibold">Gerçek Durum</th>
                  <th className="py-2.5 px-4 font-semibold text-right">İndirilen Mum</th>
                  <th className="py-2.5 px-4 font-semibold text-right">İşlenen Mum</th>
                  <th className="py-2.5 px-4 font-semibold text-right">Aday Mumlar</th>
                  <th className="py-2.5 px-4 font-semibold text-right">Sinyal</th>
                  <th className="py-2.5 px-4 font-semibold">Tarih Aralığı / Açıklama</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/50 font-mono">
                {filteredCoins.slice(0, 150).map((cs, idx) => (
                  <tr key={idx} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-2.5 px-4 font-bold text-slate-100">
                      {cs.contract}
                    </td>

                    <td className="py-2.5 px-4">
                      {cs.status === 'COMPLETED' ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                          TAMAMLANDI
                        </span>
                      ) : cs.status === 'ANALYZING' ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 animate-pulse">
                          ANALİZ EDİLİYOR
                        </span>
                      ) : cs.status === 'DOWNLOADING' ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                          İNDİRİLİYOR
                        </span>
                      ) : cs.status === 'NOT_LISTED' ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-400">
                          LİSTELENMEMİŞ
                        </span>
                      ) : cs.status === 'API_ERROR' ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30">
                          API HATASI
                        </span>
                      ) : cs.status === 'MISSING_DATA' ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300">
                          EKSİK VERİ
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-slate-500">
                          BEKLİYOR
                        </span>
                      )}
                    </td>

                    <td className="py-2.5 px-4 text-right text-cyan-300">
                      {cs.downloadedCandles.toLocaleString()}
                    </td>

                    <td className="py-2.5 px-4 text-right text-slate-100 font-bold">
                      {cs.processedCandles.toLocaleString()}
                    </td>

                    <td className="py-2.5 px-4 text-right text-slate-300">
                      {cs.evaluatedCandidates.toLocaleString()}
                    </td>

                    <td className="py-2.5 px-4 text-right text-emerald-400 font-bold">
                      {cs.signalsCount}
                    </td>

                    <td className="py-2.5 px-4 font-sans text-slate-400 text-[11px] truncate max-w-xs">
                      {cs.error || (cs.firstCandleDate ? `${cs.firstCandleDate} - ${cs.lastCandleDate}` : '-')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 7. Detected Signals & Trades Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center space-x-2">
            <TrendingUp className="w-5 h-5 text-emerald-400" />
            <h3 className="text-base font-bold text-slate-100">
              PUMP Sinyal ve İşlem Kayıtları ({filteredTrades.length})
            </h3>
            <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-400">
              Tarih Sıralı
            </span>
          </div>

          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder={t.filterSignals}
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="pl-9 pr-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors w-48 sm:w-60"
            />
          </div>
        </div>

        {filteredTrades.length === 0 ? (
          <div className="py-16 text-center px-4">
            <div className="w-12 h-12 rounded-full bg-slate-800/80 border border-slate-700 flex items-center justify-center mx-auto mb-3 text-slate-400">
              <Clock className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-semibold text-slate-300">
              {isRunning ? 'Gerçek Gate 5m mumları taranıyor...' : 'Henüz sinyal kaydı bulunmuyor.'}
            </h4>
            <p className="text-xs text-slate-500 max-w-md mx-auto mt-1">
              01.01.2026 tarihinden itibaren Gate USDT vadeli 5m mum verileri indirildiğinde üretilen her sinyal ve işlem sonucu burada gösterilir.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800/80 bg-slate-950/40 text-slate-400">
                  <th className="py-3 px-4 font-semibold">{t.tableTime}</th>
                  <th className="py-3 px-4 font-semibold">{t.tableCoin}</th>
                  <th className="py-3 px-4 font-semibold">{t.status}</th>
                  <th className="py-3 px-4 font-semibold">{t.tableEntryPrice}</th>
                  <th className="py-3 px-4 font-semibold">{t.tableTargetPrice}</th>
                  <th className="py-3 px-4 font-semibold">{t.highestPrice}</th>
                  <th className="py-3 px-4 font-semibold">{t.currentGain}</th>
                  <th className="py-3 px-4 font-semibold">TP / Kapanış Süresi</th>
                  <th className="py-3 px-4 font-semibold text-right">{t.tableScore}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/50 font-mono">
                {filteredTrades.map(tr => (
                  <tr key={tr.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4 text-slate-400">
                      {new Date(tr.signalTime).toISOString().replace('T', ' ').slice(0, 16)}
                    </td>

                    <td className="py-3 px-4">
                      <div className="flex items-center space-x-1.5 font-sans">
                        <span className="font-bold text-slate-100">{tr.contract}</span>
                        <span className="text-[10px] font-bold px-1 rounded bg-emerald-500/20 text-emerald-300">
                          LONG
                        </span>
                      </div>
                    </td>

                    <td className="py-3 px-4 font-sans">
                      {tr.status === 'TP_HIT' ? (
                        <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                          <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                          <span>{t.statusTpHit}</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-slate-800 text-slate-400 border border-slate-700">
                          <XCircle className="w-3 h-3 text-slate-400" />
                          <span>{t.statusExpired}</span>
                        </span>
                      )}
                    </td>

                    <td className="py-3 px-4 text-slate-200">
                      ${tr.entryPrice.toLocaleString()}
                    </td>

                    <td className="py-3 px-4 text-emerald-400 font-semibold">
                      ${tr.targetPrice.toLocaleString()}
                    </td>

                    <td className="py-3 px-4 text-slate-200">
                      <span>${tr.highestPrice.toLocaleString()}</span>{' '}
                      <span className="text-emerald-400 text-[10px] font-semibold">
                        (+{tr.highestGainPct}%)
                      </span>
                    </td>

                    <td className="py-3 px-4 font-bold">
                      <span
                        className={
                          tr.currentOrExitGainPct >= 20
                            ? 'text-emerald-400'
                            : tr.currentOrExitGainPct > 0
                            ? 'text-teal-400'
                            : 'text-rose-400'
                        }
                      >
                        {tr.currentOrExitGainPct >= 0 ? `+${tr.currentOrExitGainPct}%` : `${tr.currentOrExitGainPct}%`}
                      </span>
                    </td>

                    <td className="py-3 px-4 text-slate-300">
                      {tr.durationMinutes} dk ({Math.round((tr.durationMinutes / 60) * 10) / 10} saat)
                    </td>

                    <td className="py-3 px-4 text-right font-black text-cyan-300">
                      {(tr.score * 100).toFixed(1)}%
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
