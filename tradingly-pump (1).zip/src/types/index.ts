export type Language = 'tr' | 'en';

export interface GateContract {
  name: string; // e.g. "BTC_USDT"
  type: string;
  trade_status: string;
  status: string;
  in_delisting: boolean;
  order_price_round?: string;
  mark_price?: string;
  last_price?: string;
}

export interface GateCandle {
  t: number; // unix timestamp in seconds
  v: number; // volume
  c: number; // close
  h: number; // high
  l: number; // low
  o: number; // open
  sum: number; // quote turnover in USDT
}

export interface IndicatorBreakdown {
  name: string;
  category: string;
  value: number;
  weight: number;
  contribution: number;
  description: string;
}

export interface PumpSignal {
  id: string;
  contract: string;
  timestamp: number; // unix timestamp in ms
  candleTime: number; // unix timestamp in seconds (start of 5m candle)
  entryPrice: number;
  targetPrice: number; // entryPrice * 1.20
  score: number; // e.g. 0.842 (>= 0.81)
  indicators: IndicatorBreakdown[];
  candle: {
    open: number;
    high: number;
    low: number;
    close: number;
    volume: number;
    turnover: number;
  };
}

export type TradeStatus = 'ACTIVE' | 'TP_HIT' | 'EXPIRED_24H';

export interface TradeRecord {
  id: string;
  contract: string;
  signalTime: number;
  entryPrice: number;
  targetPrice: number; // +20%
  status: TradeStatus;
  score: number;
  highestPrice: number;
  highestGainPct: number;
  currentOrExitPrice: number;
  currentOrExitGainPct: number;
  exitTime?: number;
  durationMinutes: number; // time elapsed or until close
  lastUpdated: number;
}

export interface GateContractFilterResult {
  totalApiContracts: number;
  filteredNonCryptoCount: number;
  eligibleCoinsCount: number;
  breakdown: {
    stocks: number;
    indices: number;
    otherNonCrypto: number;
    preMarket: number;
    delisted: number;
    nonUsdt: number;
  };
  contracts: GateContract[];
}

export interface LiveScanStats {
  isScanning: boolean;
  isPaused: boolean;
  totalCoins: number;
  totalApiContracts: number;
  filteredContractsCount: number;
  scannedCoins: number;
  successfulCoins: number;
  failedCoins: number;
  retryCount: number;
  currentCoin: string;
  speed: number; // coins scanned per second
  signalsFoundCount: number;
  startTime: number | null;
  endTime: number | null;
  nextScanCountdown: number; // seconds remaining before auto restart (15s)
  loopEnabled: boolean;
}

export interface BacktestConfig {
  startDate: string; // YYYY-MM-DD (min 2023-01-01)
  endDate: string; // YYYY-MM-DD
  coinMode: 'ALL' | 'TOP_VOLUME' | 'CUSTOM';
  customCoins: string[];
  maxCoinsLimit?: number;
  modelThreshold: number; // 0.81
  tpTargetPct: number; // 20.0
  maxDurationHours: number; // 24
}

export interface BacktestSummary {
  totalSignals: number;
  tpHitCount: number;
  expired24hCount: number;
  activeCount: number;
  missingDataCount: number;
  successfulCoinsCount: number;
  notListedYetCount: number;
  insufficientDataCount: number;
  apiErrorCount: number;
  corsErrorCount: number;
  rateLimitCount: number;
  invalidDataCount: number;
  retriedCoinsCount: number;
  winRatePct: number; // Only over completed trades
  avgGainPct: number;
  avgDurationMinutes: number;
  bestTrade: { contract: string; gainPct: number; durationMinutes: number } | null;
  worstTrade: { contract: string; gainPct: number; durationMinutes: number } | null;
  totalPnlPct: number;
}

export interface CoinBacktestStatus {
  contract: string;
  status:
    | 'WAITING'
    | 'DOWNLOADING'
    | 'VERIFYING'
    | 'ANALYZING'
    | 'COMPLETED'
    | 'NOT_LISTED'
    | 'MISSING_DATA'
    | 'API_ERROR'
    | 'RETRYING';
  downloadedCandles: number;
  processedCandles: number;
  evaluatedCandidates: number;
  signalsCount: number;
  firstCandleDate?: string;
  lastCandleDate?: string;
  error?: string;
}

export interface BacktestProgress {
  isRunning: boolean;
  isPaused: boolean;
  currentContract: string;
  processedContracts: number;
  totalContracts: number;
  totalApiContracts?: number;
  filteredContractsCount?: number;
  downloadedCandles: number;
  processedCandles: number;
  speedCandlesPerSec: number;
  successfulCoins: number;
  notListedYetCoins: number;
  insufficientDataCoins: number;
  apiErrorCoins: number;
  corsErrorCoins: number;
  rateLimitCoins: number;
  invalidDataCoins: number;
  retryingCoins: number;
  signalsFound: number;
  coinStatuses: CoinBacktestStatus[];
}

export interface AndroidBridgeStatus {
  isNative: boolean;
  hasForegroundService: boolean;
  foregroundServiceRunning: boolean;
  notificationPermission: 'granted' | 'denied' | 'default';
  batteryOptimizationIgnored: boolean;
  wakeLockActive: boolean;
  environmentName: string;
}
