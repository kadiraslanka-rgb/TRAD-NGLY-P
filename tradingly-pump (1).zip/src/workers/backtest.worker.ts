import { GateCandle, TradeRecord } from '../types';
import {
  buildPrecomputedSeries,
  createPumpSignal,
  evaluatePumpModel,
  evaluateTradeOutcome
} from '../services/pumpCore';

export interface WorkerAnalyzeCoinPayload {
  contract: string;
  candles: GateCandle[];
  startSec: number;
  endSec: number;
}

export interface WorkerProgressPayload {
  contract: string;
  processedCandles: number;
  evaluatedCandidates: number;
  signalsCount: number;
}

export interface WorkerCoinCompletePayload {
  contract: string;
  processedCandles: number;
  evaluatedCandidates: number;
  signalsCount: number;
  trades: TradeRecord[];
  durationMs: number;
}

let isPaused = false;
let shouldStop = false;

self.onmessage = async (e: MessageEvent) => {
  const { type, payload } = e.data;

  if (type === 'PAUSE') {
    isPaused = true;
    return;
  }

  if (type === 'RESUME') {
    isPaused = false;
    return;
  }

  if (type === 'STOP') {
    shouldStop = true;
    return;
  }

  if (type === 'ANALYZE_COIN') {
    const { contract, candles, startSec, endSec } = payload as WorkerAnalyzeCoinPayload;
    shouldStop = false;
    isPaused = false;

    const tStart = Date.now();
    let coinEvaluated = 0;
    let coinSignals = 0;
    const trades: TradeRecord[] = [];

    // Precompute series once (O(N) single pass for EMAs, arrays)
    const series = buildPrecomputedSeries(candles);

    // Evaluate every single candle sequentially without skipping (Rules 9 & 10)
    for (let idx = 34; idx < candles.length; idx++) {
      if (shouldStop) break;

      while (isPaused && !shouldStop) {
        await new Promise(r => setTimeout(r, 100));
      }

      const candle = candles[idx];
      if (candle.t < startSec || candle.t > endSec) continue;

      coinEvaluated++;

      // 61-feature model evaluation with exact strategy criteria:
      // Model score >= 0.81, ATR >= 1%, Bollinger bandwidth >= 1.92%, LONG ONLY
      const evalRes = evaluatePumpModel(candles, idx, series);

      if (evalRes.isSignal) {
        const signal = createPumpSignal(contract, candles, idx, evalRes.score, evalRes.indicators);
        const subsequentCandles = candles.slice(idx + 1);
        const outcome = evaluateTradeOutcome(signal, subsequentCandles);

        const trade: TradeRecord = {
          id: signal.id,
          contract: signal.contract,
          signalTime: signal.timestamp,
          entryPrice: signal.entryPrice,
          targetPrice: signal.targetPrice,
          status: outcome.status,
          score: signal.score,
          highestPrice: outcome.highestPrice,
          highestGainPct: outcome.highestGainPct,
          currentOrExitPrice: outcome.currentOrExitPrice,
          currentOrExitGainPct: outcome.currentOrExitGainPct,
          exitTime: outcome.exitTime,
          durationMinutes: outcome.durationMinutes,
          lastUpdated: Date.now()
        };

        trades.push(trade);
        coinSignals++;
      }

      // Rule 3: Send real progress notification every 1,000 candles
      if (coinEvaluated % 1000 === 0) {
        const progressMsg: WorkerProgressPayload = {
          contract,
          processedCandles: coinEvaluated,
          evaluatedCandidates: coinEvaluated,
          signalsCount: coinSignals
        };
        self.postMessage({ type: 'PROGRESS', payload: progressMsg });
      }
    }

    const durationMs = Math.max(1, Date.now() - tStart);
    const completeMsg: WorkerCoinCompletePayload = {
      contract,
      processedCandles: coinEvaluated,
      evaluatedCandidates: coinEvaluated,
      signalsCount: coinSignals,
      trades,
      durationMs
    };
    self.postMessage({ type: 'COIN_COMPLETE', payload: completeMsg });
  }
};
