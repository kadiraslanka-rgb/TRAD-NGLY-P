import React, { createContext, useContext, useEffect, useState } from 'react';
import { fetchContractCandles, fetchContractMarkPrice } from '../services/gateApi';
import { liveScanner } from '../services/liveScanner';
import { getAndroidBridgeStatus, sendSignalNotification, startForegroundService, stopForegroundService } from '../services/nativeBridge';
import { evaluateTradeOutcome } from '../services/pumpCore';
import { playPumpAlertSound } from '../services/soundAlert';
import { loadStoredLanguage, loadStoredSignals, loadStoredTrades, saveStoredLanguage, saveStoredSignals, saveStoredTrades } from '../services/storage';
import { AndroidBridgeStatus, Language, LiveScanStats, PumpSignal, TradeRecord } from '../types';
import { translations } from '../utils/translations';

interface AppContextValue {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: typeof translations.tr;
  activeTab: 'scanner' | 'forward' | 'backtest' | 'model' | 'settings';
  setActiveTab: (tab: 'scanner' | 'forward' | 'backtest' | 'model' | 'settings') => void;
  signals: PumpSignal[];
  trades: TradeRecord[];
  scanStats: LiveScanStats;
  soundEnabled: boolean;
  setSoundEnabled: (val: boolean) => void;
  androidStatus: AndroidBridgeStatus;
  refreshAndroidStatus: () => Promise<void>;
  startLiveScan: () => void;
  pauseLiveScan: () => void;
  resumeLiveScan: () => void;
  stopLiveScan: () => void;
  toggleLoop: () => void;
  selectedSignalForModal: PumpSignal | null;
  setSelectedSignalForModal: (sig: PumpSignal | null) => void;
  clearAllSignals: () => void;
  clearAllTrades: () => void;
}

const AppContext = createContext<AppContextValue | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLangState] = useState<Language>(loadStoredLanguage());
  const [activeTab, setActiveTab] = useState<'scanner' | 'forward' | 'backtest' | 'model' | 'settings'>('scanner');
  const [signals, setSignals] = useState<PumpSignal[]>(loadStoredSignals());
  const [trades, setTrades] = useState<TradeRecord[]>(loadStoredTrades());
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [scanStats, setScanStats] = useState<LiveScanStats>(liveScanner.getStats());
  const [selectedSignalForModal, setSelectedSignalForModal] = useState<PumpSignal | null>(null);
  const [androidStatus, setAndroidStatus] = useState<AndroidBridgeStatus>({
    isNative: false,
    hasForegroundService: false,
    foregroundServiceRunning: false,
    notificationPermission: 'default',
    batteryOptimizationIgnored: false,
    wakeLockActive: false,
    environmentName: 'Tespit ediliyor...'
  });

  const t = translations[language];

  const setLanguage = (lang: Language) => {
    setLangState(lang);
    saveStoredLanguage(lang);
  };

  const refreshAndroidStatus = async () => {
    const status = await getAndroidBridgeStatus();
    setAndroidStatus(status);
  };

  useEffect(() => {
    refreshAndroidStatus();
  }, []);

  // Hook liveScanner callback
  useEffect(() => {
    liveScanner.setCallback((newStats, newSignal) => {
      setScanStats(newStats);

      if (newSignal) {
        setSignals(prev => {
          const exists = prev.some(s => s.id === newSignal.id);
          if (exists) return prev;
          const updated = [newSignal, ...prev];
          saveStoredSignals(updated);
          return updated;
        });

        // Also create a Forward Trade to track for 24h
        setTrades(prev => {
          const exists = prev.some(t => t.id === newSignal.id);
          if (exists) return prev;
          const newTrade: TradeRecord = {
            id: newSignal.id,
            contract: newSignal.contract,
            signalTime: newSignal.timestamp,
            entryPrice: newSignal.entryPrice,
            targetPrice: newSignal.targetPrice,
            status: 'ACTIVE',
            score: newSignal.score,
            highestPrice: newSignal.entryPrice,
            highestGainPct: 0,
            currentOrExitPrice: newSignal.entryPrice,
            currentOrExitGainPct: 0,
            durationMinutes: 0,
            lastUpdated: Date.now()
          };
          const updated = [newTrade, ...prev];
          saveStoredTrades(updated);
          return updated;
        });
      }
    });
  }, []);

  // Periodic forward trade price monitor (checks active trades every 20s)
  useEffect(() => {
    const interval = setInterval(async () => {
      const activeTrades = trades.filter(t => t.status === 'ACTIVE');
      if (activeTrades.length === 0) return;

      let changed = false;
      const updatedList = await Promise.all(
        trades.map(async trade => {
          if (trade.status !== 'ACTIVE') return trade;

          try {
            // Get candles since signal time
            const nowSec = Math.floor(Date.now() / 1000);
            const sigSec = Math.floor(trade.signalTime / 1000);
            const candles = await fetchContractCandles(trade.contract, 300, sigSec, nowSec);
            const curMark = await fetchContractMarkPrice(trade.contract);

            const outcome = evaluateTradeOutcome(
              {
                id: trade.id,
                contract: trade.contract,
                timestamp: trade.signalTime,
                candleTime: sigSec,
                entryPrice: trade.entryPrice,
                targetPrice: trade.targetPrice,
                score: trade.score,
                indicators: [],
                candle: { open: 0, high: 0, low: 0, close: 0, volume: 0, turnover: 0 }
              },
              candles,
              curMark || undefined
            );

            if (
              outcome.status !== trade.status ||
              outcome.highestGainPct !== trade.highestGainPct ||
              Math.abs(outcome.currentOrExitGainPct - trade.currentOrExitGainPct) > 0.05
            ) {
              changed = true;
              return {
                ...trade,
                status: outcome.status,
                highestPrice: outcome.highestPrice,
                highestGainPct: outcome.highestGainPct,
                currentOrExitPrice: outcome.currentOrExitPrice,
                currentOrExitGainPct: outcome.currentOrExitGainPct,
                exitTime: outcome.exitTime,
                durationMinutes: outcome.durationMinutes,
                lastUpdated: Date.now()
              };
            }
          } catch {
            // ignore fetch errors
          }
          return trade;
        })
      );

      if (changed) {
        setTrades(updatedList);
        saveStoredTrades(updatedList);
      }
    }, 20000);

    return () => clearInterval(interval);
  }, [trades]);

  // Auto start live scan on application load as requested
  useEffect(() => {
    const timer = setTimeout(() => {
      startLiveScan();
    }, 800);
    return () => clearTimeout(timer);
  }, []);

  const startLiveScan = async () => {
    if (liveScanner.getStats().isScanning) {
      if (liveScanner.getStats().isPaused) {
        liveScanner.resumeScan();
      }
      return;
    }
    // Acquire wake lock or native foreground service if permitted
    await startForegroundService();
    await refreshAndroidStatus();
    liveScanner.startScan();
  };

  const pauseLiveScan = () => {
    liveScanner.pauseScan();
  };

  const resumeLiveScan = () => {
    liveScanner.resumeScan();
  };

  const stopLiveScan = async () => {
    liveScanner.stopScan();
    await stopForegroundService();
    await refreshAndroidStatus();
  };

  const toggleLoop = () => {
    liveScanner.setLoopEnabled(!scanStats.loopEnabled);
  };

  const clearAllSignals = () => {
    setSignals([]);
    saveStoredSignals([]);
  };

  const clearAllTrades = () => {
    setTrades([]);
    saveStoredTrades([]);
  };

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        t,
        activeTab,
        setActiveTab,
        signals,
        trades,
        scanStats,
        soundEnabled,
        setSoundEnabled,
        androidStatus,
        refreshAndroidStatus,
        startLiveScan,
        pauseLiveScan,
        resumeLiveScan,
        stopLiveScan,
        toggleLoop,
        selectedSignalForModal,
        setSelectedSignalForModal,
        clearAllSignals,
        clearAllTrades
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
