import React from 'react';
import { BacktestTab } from './components/BacktestTab';
import { ForwardTestTab } from './components/ForwardTestTab';
import { ModelInspectorTab } from './components/ModelInspectorTab';
import { Navbar } from './components/Navbar';
import { ScannerTab } from './components/ScannerTab';
import { SettingsTab } from './components/SettingsTab';
import { SignalDetailModal } from './components/SignalDetailModal';
import { AppProvider, useApp } from './context/AppContext';

const AppContent: React.FC = () => {
  const { activeTab, t } = useApp();

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-slate-950">
      <Navbar />

      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 lg:px-8 py-6">
        {activeTab === 'scanner' && <ScannerTab />}
        {activeTab === 'forward' && <ForwardTestTab />}
        {activeTab === 'backtest' && <BacktestTab />}
        {activeTab === 'model' && <ModelInspectorTab />}
        {activeTab === 'settings' && <SettingsTab />}
      </main>

      <footer className="border-t border-slate-900 bg-slate-950/80 py-4 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>TRADINGLY PUMP · 61 Göstergeli Matematiksel Vadeli Long Modeli (Eşik &ge; 0.81)</span>
          <span className="text-[11px] text-slate-600">Gate.io USDT Futures · 5m Mumlar · TP +%20 · 24 Saat</span>
        </div>
      </footer>

      <SignalDetailModal />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
