import { GateCandle, IndicatorBreakdown, PumpSignal } from '../types';

export const PUMP_MODEL_THRESHOLD = 0.81;
export const TP_TARGET_PERCENT = 20.0;
export const MAX_HOLD_HOURS = 24;
export const CANDLE_INTERVAL_MINUTES = 5;
export const MAX_HOLD_CANDLES = (MAX_HOLD_HOURS * 60) / CANDLE_INTERVAL_MINUTES; // 288 candles

// Helper mathematical functions
function sma(data: ArrayLike<number>, period: number, idx: number): number {
  if (idx < period - 1) return data[idx] || 0;
  let sum = 0;
  for (let i = 0; i < period; i++) {
    sum += data[idx - i];
  }
  return sum / period;
}

function ema(data: ArrayLike<number>, period: number, idx: number): number {
  const k = 2 / (period + 1);
  let currentEma = data[0];
  for (let i = 1; i <= idx; i++) {
    currentEma = data[i] * k + currentEma * (1 - k);
  }
  return currentEma;
}

function stdDev(data: ArrayLike<number>, period: number, idx: number): number {
  if (idx < period - 1) return 0.0001;
  const mean = sma(data, period, idx);
  let variance = 0;
  for (let i = 0; i < period; i++) {
    const diff = data[idx - i] - mean;
    variance += diff * diff;
  }
  return Math.sqrt(variance / period);
}

function rsi(closes: ArrayLike<number>, period: number, idx: number): number {
  if (idx < period) return 50;
  let gains = 0;
  let losses = 0;
  for (let i = idx - period + 1; i <= idx; i++) {
    const diff = closes[i] - closes[i - 1];
    if (diff > 0) gains += diff;
    else losses -= diff;
  }
  const avgGain = gains / period;
  const avgLoss = losses / period;
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - (100 / (1 + rs));
}

function trueRange(candles: GateCandle[], idx: number): number {
  if (idx === 0) return candles[0].h - candles[0].l;
  const high = candles[idx].h;
  const low = candles[idx].l;
  const prevClose = candles[idx - 1].c;
  return Math.max(high - low, Math.abs(high - prevClose), Math.abs(low - prevClose));
}

function atr(candles: GateCandle[], period: number, idx: number): number {
  if (idx < period - 1) return trueRange(candles, idx);
  let sum = 0;
  for (let i = 0; i < period; i++) {
    sum += trueRange(candles, idx - i);
  }
  return sum / period;
}

export interface PrecomputedSeries {
  c: Float64Array;
  o: Float64Array;
  h: Float64Array;
  l: Float64Array;
  v: Float64Array;
  qv: Float64Array;
  ema7: Float64Array;
  ema12: Float64Array;
  ema13: Float64Array;
  ema14: Float64Array;
  ema21: Float64Array;
  ema26: Float64Array;
  ema50: Float64Array;
  ema100: Float64Array;
}

export function buildPrecomputedSeries(candles: GateCandle[]): PrecomputedSeries {
  const len = candles.length;
  const c = new Float64Array(len);
  const o = new Float64Array(len);
  const h = new Float64Array(len);
  const l = new Float64Array(len);
  const v = new Float64Array(len);
  const qv = new Float64Array(len);

  for (let i = 0; i < len; i++) {
    const k = candles[i];
    c[i] = k.c;
    o[i] = k.o;
    h[i] = k.h;
    l[i] = k.l;
    v[i] = k.v;
    qv[i] = k.sum || k.v * k.c;
  }

  const computeEma = (period: number) => {
    const res = new Float64Array(len);
    if (len === 0) return res;
    const k = 2 / (period + 1);
    let cur = c[0];
    res[0] = cur;
    for (let i = 1; i < len; i++) {
      cur = c[i] * k + cur * (1 - k);
      res[i] = cur;
    }
    return res;
  };

  return {
    c, o, h, l, v, qv,
    ema7: computeEma(7),
    ema12: computeEma(12),
    ema13: computeEma(13),
    ema14: computeEma(14),
    ema21: computeEma(21),
    ema26: computeEma(26),
    ema50: computeEma(50),
    ema100: computeEma(100)
  };
}

/**
 * Calculates the 61 PUMP Model Indicators on candle array up to candle `idx`.
 * STRICT RULE: Never uses data beyond `idx` (ZERO lookahead bias).
 */
export function calculate61Indicators(
  candles: GateCandle[],
  idx: number,
  seriesCache?: PrecomputedSeries
): IndicatorBreakdown[] {
  if (candles.length < 35 || idx < 34) {
    return [];
  }

  const s = seriesCache || buildPrecomputedSeries(candles);
  const c = s.c;
  const o = s.o;
  const h = s.h;
  const l = s.l;
  const v = s.v;
  const qv = s.qv;

  const close = c[idx];
  const open = o[idx];
  const high = h[idx];
  const low = l[idx];
  const vol = v[idx];
  const quote = qv[idx];
  const range = Math.max(0.0000001, high - low);

  // 1-8: Multi-horizon returns
  const ret1 = (close - c[idx - 1]) / c[idx - 1];
  const ret2 = (close - c[idx - 2]) / c[idx - 2];
  const ret3 = (close - c[idx - 3]) / c[idx - 3];
  const ret5 = (close - c[idx - 5]) / c[idx - 5];
  const ret8 = (close - c[idx - 8]) / c[idx - 8];
  const ret13 = (close - c[idx - 13]) / c[idx - 13];
  const ret21 = (close - c[idx - 21]) / c[idx - 21];
  const ret34 = (close - c[idx - 34]) / c[idx - 34];

  // 9-12: Candle Anatomy
  const bodyRatio = (close - open) / range;
  const upperWickRatio = (high - Math.max(close, open)) / range;
  const lowerWickRatio = (Math.min(close, open) - low) / range;
  const spreadPct = range / close;

  // 13-18: Volume Surge Dynamics
  const smaV5 = sma(v, 5, idx);
  const smaV10 = sma(v, 10, idx);
  const smaV20 = sma(v, 20, idx);
  const smaV50 = idx >= 49 ? sma(v, 50, idx) : smaV20;
  const volRatio5 = smaV5 > 0 ? vol / smaV5 : 1;
  const volRatio10 = smaV10 > 0 ? vol / smaV10 : 1;
  const volRatio20 = smaV20 > 0 ? vol / smaV20 : 1;
  const volRatio50 = smaV50 > 0 ? vol / smaV50 : 1;
  const volStd20 = stdDev(v, 20, idx);
  const volSurgeZ = volStd20 > 0 ? (vol - smaV20) / volStd20 : 0;
  const smaQv20 = sma(qv, 20, idx);
  const turnoverRatio20 = smaQv20 > 0 ? quote / smaQv20 : 1;

  // 19: Volume Trend (5 SMA vs 20 SMA)
  const volTrend = smaV20 > 0 ? smaV5 / smaV20 : 1;

  // 20-24: RSI Ensembles
  const rsi6Val = rsi(c, 6, idx);
  const rsi12Val = rsi(c, 12, idx);
  const rsi14Val = rsi(c, 14, idx);
  const rsi24Val = rsi(c, 24, idx);
  const rsi14Prev = rsi(c, 14, idx - 1);
  const rsiDelta = rsi14Val - rsi14Prev;

  // 25-28: Stochastic Oscillators & Cross
  let lowest14 = Infinity;
  let highest14 = -Infinity;
  for (let i = idx - 13; i <= idx; i++) {
    if (l[i] < lowest14) lowest14 = l[i];
    if (h[i] > highest14) highest14 = h[i];
  }
  const stochRange = Math.max(0.0000001, highest14 - lowest14);
  const stochK14 = ((close - lowest14) / stochRange) * 100;
  let stochKSum = 0;
  for (let step = 0; step < 3; step++) {
    const subIdx = idx - step;
    let subLow = Infinity;
    let subHigh = -Infinity;
    for (let i = subIdx - 13; i <= subIdx; i++) {
      if (l[i] < subLow) subLow = l[i];
      if (h[i] > subHigh) subHigh = h[i];
    }
    stochKSum += ((c[subIdx] - subLow) / Math.max(0.0000001, subHigh - subLow)) * 100;
  }
  const stochD14 = stochKSum / 3;
  const stochCross = stochK14 - stochD14;
  const williamsR14 = ((highest14 - close) / stochRange) * -100;

  // 29-31: Oscillators (CCI 20, MFI 14, CMF 20)
  const tpCur = (high + low + close) / 3;
  let tpSum = 0;
  for (let i = idx - 19; i <= idx; i++) {
    tpSum += (h[i] + l[i] + c[i]) / 3;
  }
  const tpMean = tpSum / 20;
  let meanDev = 0;
  for (let i = idx - 19; i <= idx; i++) {
    meanDev += Math.abs((h[i] + l[i] + c[i]) / 3 - tpMean);
  }
  meanDev = meanDev / 20;
  const cci20 = meanDev > 0 ? (tpCur - tpMean) / (0.015 * meanDev) : 0;

  let posMf = 0;
  let negMf = 0;
  for (let i = idx - 13; i <= idx; i++) {
    const tp1 = (h[i] + l[i] + c[i]) / 3;
    const tp0 = (h[i - 1] + l[i - 1] + c[i - 1]) / 3;
    const mf = tp1 * v[i];
    if (tp1 > tp0) posMf += mf;
    else if (tp1 < tp0) negMf += mf;
  }
  const mfi14 = negMf === 0 ? 100 : 100 - (100 / (1 + (posMf / negMf)));

  let mfVolSum = 0;
  let totalVol20 = 0;
  for (let i = idx - 19; i <= idx; i++) {
    const hlRange = Math.max(0.0000001, h[i] - l[i]);
    const mfm = ((c[i] - l[i]) - (h[i] - c[i])) / hlRange;
    mfVolSum += mfm * v[i];
    totalVol20 += v[i];
  }
  const cmf20 = totalVol20 > 0 ? mfVolSum / totalVol20 : 0;

  // 32-37: Moving Averages & Trend Ensembles
  const ema7 = s.ema7[idx];
  const ema14 = s.ema14[idx];
  const ema21 = s.ema21[idx];
  const ema50 = s.ema50[idx];
  const ema100 = s.ema100[idx];
  const ema7Prev = idx > 0 ? s.ema7[idx - 1] : ema7;
  const ema21Prev = idx > 0 ? s.ema21[idx - 1] : ema21;

  const emaCross7_21 = (ema7 - ema21) / close;
  const emaDist21 = (close - ema21) / close;
  const emaDist50 = (close - ema50) / close;
  const emaDist100 = (close - ema100) / close;
  const emaSlope7 = (ema7 - ema7Prev) / close;
  const emaSlope21 = (ema21 - ema21Prev) / close;

  // 38-41: MACD Ensembles (12, 26, 9)
  const ema12 = s.ema12[idx];
  const ema26 = s.ema26[idx];
  const macdLine = (ema12 - ema26) / close;
  const ema12Prev = idx > 0 ? s.ema12[idx - 1] : ema12;
  const ema26Prev = idx > 0 ? s.ema26[idx - 1] : ema26;
  const macdLinePrev = (ema12Prev - ema26Prev) / (idx > 0 ? c[idx - 1] : close);
  const macdSignal = macdLine * 0.2 + macdLinePrev * 0.8; // smoothed 9
  const macdHist = macdLine - macdSignal;
  const macdHistSlope = macdHist - (macdLinePrev - (macdLinePrev * 0.2 + macdLinePrev * 0.8));

  // 42-44: Bollinger Bands (20, 2)
  const sma20 = sma(c, 20, idx);
  const std20 = stdDev(c, 20, idx);
  const bbUpper = sma20 + 2 * std20;
  const bbLower = sma20 - 2 * std20;
  const bbBandwidth = sma20 > 0 ? (bbUpper - bbLower) / sma20 : 0;
  const bbPercentB = (bbUpper - bbLower) > 0 ? (close - bbLower) / (bbUpper - bbLower) : 0.5;
  const bbBreakout = Math.max(0, (close - bbUpper) / close);

  // 45-47: ATR Ensembles
  const atr7 = atr(candles, 7, idx);
  const atr14 = atr(candles, 14, idx);
  const atr28 = atr(candles, Math.min(28, idx), idx);
  const atr7Pct = atr7 / close;
  const atr14Pct = atr14 / close;
  const atrExpansion = atr28 > 0 ? atr7 / atr28 : 1;

  // 48-51: High/Low Breakouts
  let highestHigh20 = -Infinity;
  let lowestLow20 = Infinity;
  for (let i = idx - 20; i < idx; i++) {
    if (h[i] > highestHigh20) highestHigh20 = h[i];
    if (l[i] < lowestLow20) lowestLow20 = l[i];
  }
  const breakout20h = (close - highestHigh20) / close;
  const posRange20 = (highestHigh20 - lowestLow20) > 0 ? (close - lowestLow20) / (highestHigh20 - lowestLow20) : 0.5;

  let highestHigh50 = -Infinity;
  let lowestLow50 = Infinity;
  const look50 = Math.min(50, idx);
  for (let i = idx - look50; i < idx; i++) {
    if (h[i] > highestHigh50) highestHigh50 = h[i];
    if (l[i] < lowestLow50) lowestLow50 = l[i];
  }
  const breakout50h = (close - highestHigh50) / close;
  const posRange50 = (highestHigh50 - lowestLow50) > 0 ? (close - lowestLow50) / (highestHigh50 - lowestLow50) : 0.5;

  // 52: VWAP Distance (24-bar window)
  let sumPv = 0;
  let sumV = 0;
  for (let i = idx - 23; i <= idx; i++) {
    const barTp = (h[i] + l[i] + c[i]) / 3;
    sumPv += barTp * v[i];
    sumV += v[i];
  }
  const vwap24 = sumV > 0 ? sumPv / sumV : close;
  const vwapDist = (close - vwap24) / vwap24;

  // 53: On-Balance Volume 5-bar Slope
  let obvCur = 0;
  let obv5Ago = 0;
  for (let i = idx - 5; i <= idx; i++) {
    const diff = c[i] - c[i - 1];
    if (diff > 0) obvCur += v[i];
    else if (diff < 0) obvCur -= v[i];
    if (i === idx - 5) obv5Ago = obvCur;
  }
  const obvSlope5 = smaV5 > 0 ? (obvCur - obv5Ago) / (smaV5 * 5) : 0;

  // 54: Consecutive Green Candles
  let consecGreen = 0;
  for (let i = idx; i >= Math.max(0, idx - 10); i--) {
    if (c[i] >= o[i]) consecGreen++;
    else break;
  }
  const consecGreenNorm = Math.min(1, consecGreen / 5);

  // 55: Volume Acceleration
  const smaV3 = sma(v, 3, idx);
  const volAccel = smaV10 > 0 ? (smaV3 - smaV10) / smaV10 : 0;

  // 56: Bull-Bear Power
  const ema13 = s.ema13[idx];
  const bullPower = (high - ema13) / close;

  // 57: Force Index (13 period normalized)
  const rawFi = (close - c[idx - 1]) * vol;
  const forceIndex13 = (rawFi / (smaV10 * close + 0.0001));

  // 58: ADX Trend Proxy (+DM / -DM 14)
  let plusDm = 0;
  let minusDm = 0;
  for (let i = idx - 13; i <= idx; i++) {
    const upMove = h[i] - h[i - 1];
    const downMove = l[i - 1] - l[i];
    if (upMove > downMove && upMove > 0) plusDm += upMove;
    if (downMove > upMove && downMove > 0) minusDm += downMove;
  }
  const adxProxy = (plusDm + minusDm) > 0 ? (plusDm - minusDm) / (plusDm + minusDm) : 0;

  // 59: Keltner Channel Breakout Position
  const keltnerUpper = ema21 + 1.5 * atr14;
  const keltnerDist = (close - keltnerUpper) / close;

  // 60: Liquidity Log Score (Turnover depth)
  const liquidityScore = Math.min(1, Math.max(0, Math.log10(Math.max(1000, smaQv20)) / 7.5));

  // 61: Short vs Medium Volatility Expansion Ratio
  const volStd5 = stdDev(c, 5, idx);
  const volStd30 = stdDev(c, 30, idx);
  const volExpansionRatio = volStd30 > 0 ? volStd5 / volStd30 : 1;

  // Construct structured list of 61 indicators
  const indicators: IndicatorBreakdown[] = [
    { name: 'ret_1', category: 'Returns', value: ret1, weight: 1.8, contribution: 0, description: '1-Bar 5m Kapanış Getirisi' },
    { name: 'ret_2', category: 'Returns', value: ret2, weight: 1.5, contribution: 0, description: '2-Bar Kümülatif Getiri' },
    { name: 'ret_3', category: 'Returns', value: ret3, weight: 1.3, contribution: 0, description: '3-Bar Kümülatif Getiri' },
    { name: 'ret_5', category: 'Returns', value: ret5, weight: 1.2, contribution: 0, description: '5-Bar (25 dk) Getiri' },
    { name: 'ret_8', category: 'Returns', value: ret8, weight: 1.1, contribution: 0, description: '8-Bar (40 dk) Getiri' },
    { name: 'ret_13', category: 'Returns', value: ret13, weight: 0.9, contribution: 0, description: '13-Bar Momentum Getirisi' },
    { name: 'ret_21', category: 'Returns', value: ret21, weight: 0.8, contribution: 0, description: '21-Bar Trend Getirisi' },
    { name: 'ret_34', category: 'Returns', value: ret34, weight: 0.7, contribution: 0, description: '34-Bar Baz Getirisi' },

    { name: 'body_ratio', category: 'Price Action', value: bodyRatio, weight: 1.6, contribution: 0, description: 'Gövde / Mum Boyu Oranı' },
    { name: 'upper_wick_ratio', category: 'Price Action', value: upperWickRatio, weight: -1.2, contribution: 0, description: 'Üst Fitil Satış Baskısı Oranı' },
    { name: 'lower_wick_ratio', category: 'Price Action', value: lowerWickRatio, weight: 0.8, contribution: 0, description: 'Alt Fitil Alış Desteği Oranı' },
    { name: 'spread_pct', category: 'Price Action', value: spreadPct, weight: 1.4, contribution: 0, description: 'Mum Fiyat Genliği Yüzdesi' },

    { name: 'vol_ratio_5', category: 'Volume Surge', value: volRatio5, weight: 2.2, contribution: 0, description: '5-SMA Hacim Patlama Çarpanı' },
    { name: 'vol_ratio_10', category: 'Volume Surge', value: volRatio10, weight: 2.0, contribution: 0, description: '10-SMA Hacim Çarpanı' },
    { name: 'vol_ratio_20', category: 'Volume Surge', value: volRatio20, weight: 2.4, contribution: 0, description: '20-SMA Hacim Patlaması' },
    { name: 'vol_ratio_50', category: 'Volume Surge', value: volRatio50, weight: 1.9, contribution: 0, description: '50-SMA Taban Hacim Oranı' },
    { name: 'vol_surge_z', category: 'Volume Surge', value: volSurgeZ, weight: 2.1, contribution: 0, description: 'Hacim Z-Skoru Standart Sapması' },
    { name: 'turnover_ratio_20', category: 'Volume Surge', value: turnoverRatio20, weight: 2.3, contribution: 0, description: 'USDT Hacim Patlaması (Turnover)' },
    { name: 'vol_trend', category: 'Volume Surge', value: volTrend, weight: 1.5, contribution: 0, description: 'Kısa/Orta Hacim Trend Gücü' },

    { name: 'rsi_6', category: 'Oscillators', value: rsi6Val, weight: 1.3, contribution: 0, description: 'RSI 6 Ultra-Hızlı Momentum' },
    { name: 'rsi_12', category: 'Oscillators', value: rsi12Val, weight: 1.2, contribution: 0, description: 'RSI 12 Dinamik Osilatör' },
    { name: 'rsi_14', category: 'Oscillators', value: rsi14Val, weight: 1.4, contribution: 0, description: 'RSI 14 Klasik Göreceli Güç' },
    { name: 'rsi_24', category: 'Oscillators', value: rsi24Val, weight: 1.0, contribution: 0, description: 'RSI 24 Orta Vade Trend Seviyesi' },
    { name: 'rsi_delta', category: 'Oscillators', value: rsiDelta, weight: 1.7, contribution: 0, description: 'RSI Ani İvme Değişimi (Delta)' },

    { name: 'stoch_k_14', category: 'Oscillators', value: stochK14, weight: 1.1, contribution: 0, description: 'Stokastik %K Hızlı Çizgi' },
    { name: 'stoch_d_14', category: 'Oscillators', value: stochD14, weight: 0.9, contribution: 0, description: 'Stokastik %D Sinyal Çizgisi' },
    { name: 'stoch_cross', category: 'Oscillators', value: stochCross, weight: 1.5, contribution: 0, description: 'Stokastik Kesişim İvmesi (%K - %D)' },
    { name: 'williams_r_14', category: 'Oscillators', value: williamsR14, weight: 1.1, contribution: 0, description: 'Williams %R Aşırı Alım Gücü' },
    { name: 'cci_20', category: 'Oscillators', value: cci20, weight: 1.3, contribution: 0, description: 'Emtia Kanal Endeksi (CCI 20)' },
    { name: 'mfi_14', category: 'Oscillators', value: mfi14, weight: 1.6, contribution: 0, description: 'Para Akışı Endeksi (MFI 14)' },
    { name: 'cmf_20', category: 'Oscillators', value: cmf20, weight: 1.8, contribution: 0, description: 'Chaikin Para Akışı (CMF 20)' },

    { name: 'ema_7_cross', category: 'Trend', value: emaCross7_21, weight: 2.0, contribution: 0, description: 'EMA 7 / 21 Altın Kesişim Farkı' },
    { name: 'ema_dist_21', category: 'Trend', value: emaDist21, weight: 1.5, contribution: 0, description: 'Fiyatın EMA 21 Uzaklığı' },
    { name: 'ema_dist_50', category: 'Trend', value: emaDist50, weight: 1.4, contribution: 0, description: 'Fiyatın EMA 50 Uzaklığı' },
    { name: 'ema_dist_100', category: 'Trend', value: emaDist100, weight: 1.2, contribution: 0, description: 'Fiyatın EMA 100 Uzaklığı' },
    { name: 'ema_slope_7', category: 'Trend', value: emaSlope7, weight: 1.7, contribution: 0, description: 'EMA 7 Yükseliş Eğimi' },
    { name: 'ema_slope_21', category: 'Trend', value: emaSlope21, weight: 1.5, contribution: 0, description: 'EMA 21 Trend Eğimi' },

    { name: 'macd_line', category: 'MACD', value: macdLine, weight: 1.5, contribution: 0, description: 'MACD Çizgisi (EMA 12 - 26)' },
    { name: 'macd_signal', category: 'MACD', value: macdSignal, weight: 1.1, contribution: 0, description: 'MACD Sinyal Çizgisi (9)' },
    { name: 'macd_hist', category: 'MACD', value: macdHist, weight: 2.1, contribution: 0, description: 'MACD Histogram Yükseliş Barı' },
    { name: 'macd_hist_slope', category: 'MACD', value: macdHistSlope, weight: 1.8, contribution: 0, description: 'MACD Histogram Hızlanma Eğimi' },

    { name: 'bb_percent_b', category: 'Bollinger', value: bbPercentB, weight: 1.7, contribution: 0, description: 'Bollinger %B Göreceli Konum' },
    { name: 'bb_bandwidth', category: 'Bollinger', value: bbBandwidth, weight: 1.4, contribution: 0, description: 'Bollinger Bant Genişliği (Volatilite)' },
    { name: 'bb_breakout', category: 'Bollinger', value: bbBreakout, weight: 2.5, contribution: 0, description: 'Bollinger Üst Bant Patlaması' },

    { name: 'atr_7_pct', category: 'Volatility', value: atr7Pct, weight: 1.3, contribution: 0, description: 'ATR 7 / Fiyat Volatilite Oranı' },
    { name: 'atr_14_pct', category: 'Volatility', value: atr14Pct, weight: 1.2, contribution: 0, description: 'ATR 14 Dinamik Fiyat Aralığı' },
    { name: 'atr_expansion', category: 'Volatility', value: atrExpansion, weight: 2.0, contribution: 0, description: 'ATR Hızlı Genişleme Katsayısı (7/28)' },

    { name: 'breakout_20h', category: 'Breakout', value: breakout20h, weight: 2.4, contribution: 0, description: '20-Mum Tepe Kırılım Seviyesi' },
    { name: 'breakout_50h', category: 'Breakout', value: breakout50h, weight: 2.6, contribution: 0, description: '50-Mum Ana Tepe Kırılımı' },
    { name: 'pos_range_20', category: 'Breakout', value: posRange20, weight: 1.5, contribution: 0, description: '20-Mum Fiyat Aralığı Zirve Konumu' },
    { name: 'pos_range_50', category: 'Breakout', value: posRange50, weight: 1.6, contribution: 0, description: '50-Mum Fiyat Aralığı Zirve Konumu' },

    { name: 'vwap_dist', category: 'OrderFlow', value: vwapDist, weight: 1.8, contribution: 0, description: 'VWAP Üzeri Alıcı Baskısı Farkı' },
    { name: 'obv_slope_5', category: 'OrderFlow', value: obvSlope5, weight: 1.7, contribution: 0, description: 'On-Balance Volume (OBV) İvmesi' },
    { name: 'consec_green', category: 'Price Action', value: consecGreenNorm, weight: 1.4, contribution: 0, description: 'Ardışık Yeşil Mum Sayısı' },
    { name: 'vol_accel', category: 'Volume Surge', value: volAccel, weight: 1.9, contribution: 0, description: 'Hacim İvmelenmesi (3 SMA vs 10 SMA)' },
    { name: 'bull_power', category: 'Momentum', value: bullPower, weight: 1.5, contribution: 0, description: 'Boğa Gücü Endeksi (High - EMA13)' },
    { name: 'force_index_13', category: 'Momentum', value: forceIndex13, weight: 1.7, contribution: 0, description: 'Force Index 13 Hacim Gücü' },
    { name: 'adx_proxy', category: 'Trend', value: adxProxy, weight: 1.4, contribution: 0, description: 'Pozitif Yönsel Trend İvmesi (+DM)' },
    { name: 'keltner_dist', category: 'Breakout', value: keltnerDist, weight: 1.8, contribution: 0, description: 'Keltner Kanalı Üst Kırılım Mesafesi' },
    { name: 'liquidity_score', category: 'Liquidity', value: liquidityScore, weight: 1.1, contribution: 0, description: 'USDT İşlem Hacim Derinliği Skoru' },
    { name: 'vol_expansion', category: 'Volatility', value: volExpansionRatio, weight: 1.6, contribution: 0, description: 'Kısa/Uzun Volatilite Patlama Oranı' }
  ];

  return indicators;
}

/**
 * Normalizes an indicator value to standard z-score/sigmoid domain
 */
function normalizeIndicatorValue(name: string, val: number): number {
  if (Number.isNaN(val) || !Number.isFinite(val)) return 0;

  switch (name) {
    case 'ret_1':
    case 'ret_2':
    case 'ret_3':
    case 'ret_5':
    case 'ret_8':
    case 'ret_13':
    case 'ret_21':
    case 'ret_34':
      return Math.tanh(val * 40); // 2.5% return ~ 0.76

    case 'body_ratio':
    case 'upper_wick_ratio':
    case 'lower_wick_ratio':
      return Math.max(-1, Math.min(1, val));

    case 'spread_pct':
      return Math.tanh(val * 30);

    case 'vol_ratio_5':
    case 'vol_ratio_10':
    case 'vol_ratio_20':
    case 'vol_ratio_50':
    case 'turnover_ratio_20':
      return Math.tanh((val - 1.0) / 2.5);

    case 'vol_surge_z':
      return Math.tanh(val / 3.0);

    case 'vol_trend':
      return Math.tanh((val - 1.0) / 1.5);

    case 'rsi_6':
    case 'rsi_12':
    case 'rsi_14':
    case 'rsi_24':
    case 'mfi_14':
      return (val - 50) / 30; // 70 -> +0.67, 80 -> +1.0

    case 'rsi_delta':
      return Math.tanh(val / 10.0);

    case 'stoch_k_14':
    case 'stoch_d_14':
      return (val - 50) / 35;

    case 'stoch_cross':
      return Math.tanh(val / 15.0);

    case 'williams_r_14':
      return (val + 50) / 35;

    case 'cci_20':
      return Math.tanh(val / 150.0);

    case 'cmf_20':
      return Math.tanh(val * 3.0);

    case 'ema_7_cross':
    case 'ema_dist_21':
    case 'ema_dist_50':
    case 'ema_dist_100':
    case 'ema_slope_7':
    case 'ema_slope_21':
    case 'macd_line':
    case 'macd_signal':
    case 'macd_hist':
    case 'macd_hist_slope':
      return Math.tanh(val * 60);

    case 'bb_percent_b':
      return (val - 0.5) * 2; // > 1.0 means upper breakout

    case 'bb_bandwidth':
      return Math.tanh(val * 25);

    case 'bb_breakout':
      return Math.tanh(val * 80);

    case 'atr_7_pct':
    case 'atr_14_pct':
      return Math.tanh(val * 40);

    case 'atr_expansion':
      return Math.tanh((val - 1.0) / 0.8);

    case 'breakout_20h':
    case 'breakout_50h':
      return Math.tanh(val * 50);

    case 'pos_range_20':
    case 'pos_range_50':
      return (val - 0.5) * 2;

    case 'vwap_dist':
      return Math.tanh(val * 50);

    case 'obv_slope_5':
      return Math.tanh(val / 2.0);

    case 'consec_green':
      return val;

    case 'vol_accel':
      return Math.tanh(val / 1.5);

    case 'bull_power':
    case 'keltner_dist':
      return Math.tanh(val * 50);

    case 'force_index_13':
    case 'adx_proxy':
      return Math.tanh(val);

    case 'liquidity_score':
      return (val - 0.5) * 2;

    case 'vol_expansion':
      return Math.tanh((val - 1.0) / 1.2);

    default:
      return Math.tanh(val);
  }
}

/**
 * Calculates the exact deterministic PUMP score (0.0 to 1.0) for a given candle index.
 * STRICTLY LONG-ONLY.
 * Identical inputs always produce identical score.
 */
export function evaluatePumpModel(
  candles: GateCandle[],
  idx: number,
  seriesCache?: PrecomputedSeries
): {
  score: number;
  isSignal: boolean;
  indicators: IndicatorBreakdown[];
  atrValue?: number;
  bbWidthValue?: number;
  meetsScore?: boolean;
  meetsAtr?: boolean;
  meetsBb?: boolean;
} {
  const indicators = calculate61Indicators(candles, idx, seriesCache);
  if (indicators.length < 61) {
    return { score: 0, isSignal: false, indicators: [] };
  }

  // Model calibration bias calibrated for pump breakout detection
  // Base intercept chosen so quiet periods produce scores ~ 0.1 - 0.4
  // explosive breakout + volume surge pushes score > 0.81
  const BIAS = -3.25;

  let weightedSum = 0;
  let totalWeight = 0;

  for (let i = 0; i < indicators.length; i++) {
    const item = indicators[i];
    const norm = normalizeIndicatorValue(item.name, item.value);
    const component = norm * item.weight;
    item.contribution = component;
    weightedSum += component;
    totalWeight += Math.abs(item.weight);
  }

  // Logistic model logit
  const logit = BIAS + (weightedSum / (totalWeight * 0.08));
  // Sigmoid probability
  const score = 1 / (1 + Math.exp(-logit));
  const roundedScore = Math.round(score * 10000) / 10000;

  // Strict Strategy Filters:
  // 1. Model score >= 0.81
  // 2. ATR >= 1.0% (0.01)
  // 3. Bollinger Bandwidth ratio >= 1.92% (0.0192)
  // 4. LONG ONLY (Strictly no short)
  const atr7 = indicators.find(i => i.name === 'atr_7_pct');
  const atr14 = indicators.find(i => i.name === 'atr_14_pct');
  const bbBandwidth = indicators.find(i => i.name === 'bb_bandwidth');

  const atrValue = Math.max(atr7?.value || 0, atr14?.value || 0);
  const bbWidthValue = bbBandwidth?.value || 0;

  const meetsScore = roundedScore >= PUMP_MODEL_THRESHOLD;
  const meetsAtr = atrValue >= 0.01; // ATR >= 1%
  const meetsBb = bbWidthValue >= 0.0192; // Bollinger bandwidth >= 1.92%

  const isSignal = meetsScore && meetsAtr && meetsBb;

  return {
    score: roundedScore,
    isSignal,
    indicators,
    atrValue,
    bbWidthValue,
    meetsScore,
    meetsAtr,
    meetsBb
  };
}

/**
 * Creates a Signal object from a triggered candle
 */
export function createPumpSignal(
  contract: string,
  candles: GateCandle[],
  idx: number,
  score: number,
  indicators: IndicatorBreakdown[]
): PumpSignal {
  const candle = candles[idx];
  const entryPrice = candle.c;
  const targetPrice = Math.round((entryPrice * 1.20) * 10000000) / 10000000;

  return {
    id: `${contract}_${candle.t}_${Math.floor(score * 1000)}`,
    contract,
    timestamp: candle.t * 1000,
    candleTime: candle.t,
    entryPrice,
    targetPrice,
    score,
    indicators,
    candle: {
      open: candle.o,
      high: candle.h,
      low: candle.l,
      close: candle.c,
      volume: candle.v,
      turnover: candle.sum || candle.v * candle.c
    }
  };
}

/**
 * Evaluates trade outcome over subsequent candles within 24 hours (288 candles).
 * - If High >= Target (+20%): TP_HIT (Wick touches target)
 * - If 288 candles pass without TP: EXPIRED_24H
 * - If still within 24h: ACTIVE
 */
export function evaluateTradeOutcome(
  signal: PumpSignal,
  subsequentCandles: GateCandle[],
  currentMarkPrice?: number
): {
  status: 'ACTIVE' | 'TP_HIT' | 'EXPIRED_24H';
  highestPrice: number;
  highestGainPct: number;
  currentOrExitPrice: number;
  currentOrExitGainPct: number;
  exitTime?: number;
  durationMinutes: number;
} {
  const entry = signal.entryPrice;
  const target = signal.targetPrice;

  let highestPrice = entry;
  let exitCandleIdx = -1;
  let isTpHit = false;

  const maxCandles = Math.min(MAX_HOLD_CANDLES, subsequentCandles.length);

  for (let i = 0; i < maxCandles; i++) {
    const c = subsequentCandles[i];
    if (c.h > highestPrice) {
      highestPrice = c.h;
    }

    // Wick touches target: TP hit!
    if (c.h >= target) {
      isTpHit = true;
      exitCandleIdx = i;
      break;
    }
  }

  const highestGainPct = Math.round(((highestPrice - entry) / entry) * 10000) / 100;

  if (isTpHit && exitCandleIdx >= 0) {
    const exitCandle = subsequentCandles[exitCandleIdx];
    return {
      status: 'TP_HIT',
      highestPrice,
      highestGainPct,
      currentOrExitPrice: target,
      currentOrExitGainPct: 20.0,
      exitTime: exitCandle.t * 1000,
      durationMinutes: (exitCandleIdx + 1) * CANDLE_INTERVAL_MINUTES
    };
  }

  // If 24 hours have elapsed (288 candles reached)
  if (subsequentCandles.length >= MAX_HOLD_CANDLES) {
    const exitCandle = subsequentCandles[MAX_HOLD_CANDLES - 1];
    const exitPrice = exitCandle.c;
    const exitGainPct = Math.round(((exitPrice - entry) / entry) * 10000) / 100;

    return {
      status: 'EXPIRED_24H',
      highestPrice,
      highestGainPct,
      currentOrExitPrice: exitPrice,
      currentOrExitGainPct: exitGainPct,
      exitTime: exitCandle.t * 1000,
      durationMinutes: MAX_HOLD_HOURS * 60
    };
  }

  // Still active
  const lastCandle = subsequentCandles[subsequentCandles.length - 1];
  const curPrice = currentMarkPrice || (lastCandle ? lastCandle.c : entry);
  const curGainPct = Math.round(((curPrice - entry) / entry) * 10000) / 100;
  const elapsedMinutes = subsequentCandles.length * CANDLE_INTERVAL_MINUTES;

  return {
    status: 'ACTIVE',
    highestPrice,
    highestGainPct,
    currentOrExitPrice: curPrice,
    currentOrExitGainPct: curGainPct,
    durationMinutes: elapsedMinutes
  };
}
