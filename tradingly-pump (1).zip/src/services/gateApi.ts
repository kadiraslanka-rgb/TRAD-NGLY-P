import { GateCandle, GateContract, GateContractFilterResult } from '../types';

const GATE_REST_URL = 'https://api.gateio.ws/api/v4/futures/usdt';

function isAndroidNative(): boolean {
  return typeof window !== 'undefined' && Boolean(
    (window as any).Capacitor?.isNativePlatform?.() || (window as any).AndroidBridge
  );
}

function getProxyBase(): string {
  if (typeof window !== 'undefined') {
    if (isAndroidNative()) {
      return ''; // Native Android calls Gate API directly over HTTPS
    }
    return '/api/gate';
  }
  return 'http://127.0.0.1:3000/api/gate';
}

// In-memory candle cache to avoid duplicate network hits
const memoryCandleCache = new Map<string, { candles: GateCandle[]; timestamp: number }>();
const CACHE_TTL_MS = 60 * 1000;

export interface FetchCandlesResult {
  status:
    | 'OK'
    | 'NOT_LISTED_YET'
    | 'INSUFFICIENT_DATA'
    | 'API_ERROR'
    | 'CORS_ERROR'
    | 'RATE_LIMIT'
    | 'INVALID_DATA'
    | 'RETRYING';
  candles: GateCandle[];
  error?: string;
  source?: 'proxy' | 'direct' | 'archive';
}

function parseCandles(raw: any[]): GateCandle[] {
  if (!Array.isArray(raw)) return [];
  const list: GateCandle[] = [];

  for (let i = 0; i < raw.length; i++) {
    const item = raw[i];
    if (!item) continue;

    const t = Number(item.t);
    const o = Number(item.o);
    const h = Number(item.h);
    const l = Number(item.l);
    const c = Number(item.c);
    const v = Number(item.v);
    const sum = Number(item.sum || item.v * item.c || 0);

    if (Number.isFinite(t) && Number.isFinite(c) && c > 0) {
      list.push({ t, o, h, l, c, v, sum });
    }
  }

  // Deduplicate and sort chronologically
  const map = new Map<number, GateCandle>();
  for (const c of list) {
    map.set(c.t, c);
  }
  return Array.from(map.values()).sort((a, b) => a.t - b.t);
}

const NON_CRYPTO_TYPES = new Set(['stocks', 'indices', 'commodities', 'forex', 'metals']);

/**
 * Filters Gate contracts strictly according to TRADINGLY PUMP rules:
 * - USDT perpetual futures only (name ends with _USDT)
 * - Exclude delivery futures (e.g. contracts with date suffixes like _2024...)
 * - Exclude synthetic stock futures (type 'stocks', AAPL, NVDA, TSLA, etc.)
 * - Exclude traditional indices (type 'indices', GER40, AUS200, etc.)
 * - Exclude commodities, forex, and metals (BZ, CL, EURUSD, IAU, etc.)
 * - Exclude pre-market contracts (is_pre_market === true)
 * - Exclude delisted and non-trading contracts (in_delisting === true or status !== 'trading')
 * Dynamic calculation — never hardcodes 591 or 1040!
 */
export function filterEligibleGateContracts(rawContracts: any[]): GateContractFilterResult {
  let stocks = 0;
  let indices = 0;
  let otherNonCrypto = 0;
  let preMarket = 0;
  let delisted = 0;
  let nonUsdt = 0;

  const eligible: GateContract[] = [];

  for (let i = 0; i < rawContracts.length; i++) {
    const c = rawContracts[i];
    if (!c || !c.name || typeof c.name !== 'string') continue;

    if (!c.name.endsWith('_USDT')) {
      nonUsdt++;
      continue;
    }

    // Delivery contracts (e.g. BTC_USDT_20261017)
    if (/_\d{6,8}$/.test(c.name)) {
      continue;
    }

    // Pre-market contracts
    if (c.is_pre_market) {
      preMarket++;
      continue;
    }

    // Delisting or halted trading
    if (c.in_delisting || (c.status && c.status !== 'trading')) {
      delisted++;
      continue;
    }

    const cType = (c.contract_type || '').toLowerCase();
    if (cType === 'stocks') {
      stocks++;
      continue;
    }
    if (cType === 'indices') {
      indices++;
      continue;
    }
    if (NON_CRYPTO_TYPES.has(cType)) {
      otherNonCrypto++;
      continue;
    }

    eligible.push({
      name: c.name,
      type: c.type || 'direct',
      trade_status: c.status || 'trading',
      status: c.status || 'trading',
      in_delisting: Boolean(c.in_delisting),
      order_price_round: c.order_price_round,
      mark_price: c.mark_price,
      last_price: c.last_price
    });
  }

  const filteredNonCryptoCount = rawContracts.length - eligible.length;

  return {
    totalApiContracts: rawContracts.length,
    filteredNonCryptoCount,
    eligibleCoinsCount: eligible.length,
    breakdown: { stocks, indices, otherNonCrypto, preMarket, delisted, nonUsdt },
    contracts: eligible
  };
}

let lastFilterResult: GateContractFilterResult | null = null;

export function getLastContractFilterResult(): GateContractFilterResult | null {
  return lastFilterResult;
}

/**
 * Fetches dynamic Gate USDT contract report including totals, filtered, and eligible coins
 */
export async function fetchGateContractReport(): Promise<GateContractFilterResult> {
  const proxyBase = getProxyBase();

  // 1. Try proxy in web browser environment
  if (proxyBase) {
    try {
      const res = await fetch(`${proxyBase}/contracts`);
      if (res.ok) {
        const data = await res.json();
        if (data.success && Array.isArray(data.contracts) && data.contracts.length > 0) {
          const result: GateContractFilterResult = {
            totalApiContracts: data.totalApi || data.total || data.contracts.length,
            filteredNonCryptoCount: data.filteredCount || 0,
            eligibleCoinsCount: data.contracts.length,
            breakdown: data.breakdown || { stocks: 0, indices: 0, otherNonCrypto: 0, preMarket: 0, delisted: 0, nonUsdt: 0 },
            contracts: data.contracts
          };
          lastFilterResult = result;
          return result;
        }
      }
    } catch {
      // Fallback to direct Gate API
    }
  }

  // 2. Direct Gate REST API (used on Android Native or if proxy unreachable)
  const url = `${GATE_REST_URL}/contracts`;
  const response = await fetch(url, {
    method: 'GET',
    headers: { 'Accept': 'application/json' }
  });

  if (!response.ok) {
    throw new Error(`Gate API error (${response.status}): ${response.statusText}`);
  }

  const rawData = await response.json();
  if (!Array.isArray(rawData)) {
    throw new Error('Invalid contracts payload from Gate API');
  }

  const filteredResult = filterEligibleGateContracts(rawData);
  lastFilterResult = filteredResult;
  return filteredResult;
}

/**
 * Fetches only eligible USDT crypto perpetual futures contracts
 */
export async function fetchGateUsdtContracts(): Promise<GateContract[]> {
  const report = await fetchGateContractReport();
  return report.contracts;
}

/**
 * Fetches 5m candles for a specific contract with accurate parameter validation
 * Gate rule: limit and from and to cannot be present at the same time!
 */
export async function fetchContractCandles(
  contract: string,
  limit?: number,
  from?: number,
  to?: number,
  maxRetries: number = 2
): Promise<GateCandle[]> {
  const result = await fetchContractCandlesDetailed(contract, limit, from, to, maxRetries);
  if (result.status === 'OK') {
    return result.candles;
  }
  if (result.status === 'NOT_LISTED_YET') {
    return [];
  }
  throw new Error(`Candle fetch failed (${result.status}): ${result.error || ''}`);
}

/**
 * Detailed candle fetch with strict error classification
 */
export async function fetchContractCandlesDetailed(
  contract: string,
  limit?: number,
  from?: number,
  to?: number,
  maxRetries: number = 2
): Promise<FetchCandlesResult> {
  const cacheKey = `${contract}_5m_${limit || 0}_${from || 0}_${to || 0}`;
  const now = Date.now();
  const cached = memoryCandleCache.get(cacheKey);

  if (cached && (now - cached.timestamp < CACHE_TTL_MS)) {
    return { status: 'OK', candles: cached.candles, source: 'proxy' };
  }

  // 1. Try server proxy endpoint first
  try {
    const proxyParams = new URLSearchParams({ contract });
    if (from && to) {
      proxyParams.set('from', String(Math.floor(from)));
      proxyParams.set('to', String(Math.floor(to)));
    } else if (to && limit) {
      proxyParams.set('to', String(Math.floor(to)));
      proxyParams.set('limit', String(limit));
    } else if (limit) {
      proxyParams.set('limit', String(limit));
    }

    const proxyRes = await fetch(`${getProxyBase()}/candlesticks?${proxyParams.toString()}`);
    if (proxyRes.ok) {
      const json = await proxyRes.json();
      if (json.success && Array.isArray(json.candles)) {
        if (json.candles.length > 0) {
          memoryCandleCache.set(cacheKey, { candles: json.candles, timestamp: now });
        }
        return { status: 'OK', candles: json.candles, source: 'proxy' };
      }
    }
  } catch {
    // Proceed to direct call
  }

  // 2. Direct Gate API with strict compliance to parameter rules
  let attempt = 0;
  while (attempt <= maxRetries) {
    try {
      const params = new URLSearchParams();
      params.set('contract', contract);
      params.set('interval', '5m');

      // CRITICAL: Gate error: "limit and from and to cannot be present at the same time"
      if (from && to) {
        params.set('from', String(Math.floor(from)));
        params.set('to', String(Math.floor(to)));
      } else if (to && limit) {
        params.set('to', String(Math.floor(to)));
        params.set('limit', String(Math.min(2000, limit)));
      } else if (limit) {
        params.set('limit', String(Math.min(2000, limit)));
      } else {
        params.set('limit', '100');
      }

      const url = `${GATE_REST_URL}/candlesticks?${params.toString()}`;
      const res = await fetch(url, {
        method: 'GET',
        headers: { 'Accept': 'application/json' }
      });

      if (res.status === 429) {
        if (attempt < maxRetries) {
          await new Promise(r => setTimeout(r, 1200 * (attempt + 1)));
          attempt++;
          continue;
        }
        return { status: 'RATE_LIMIT', candles: [], error: 'Gate API 429 Too Many Requests' };
      }

      const json = await res.json();

      if (!res.ok) {
        const errorMsg = json?.message || res.statusText;
        if (errorMsg.includes('Maximum 10000 points recently are allowed')) {
          return { status: 'INSUFFICIENT_DATA', candles: [], error: errorMsg };
        }
        return { status: 'API_ERROR', candles: [], error: errorMsg };
      }

      const candles = parseCandles(json);
      if (candles.length > 0) {
        memoryCandleCache.set(cacheKey, { candles, timestamp: now });
      }

      return { status: 'OK', candles, source: 'direct' };
    } catch (err: any) {
      if (err.name === 'TypeError' && err.message?.includes('fetch')) {
        return { status: 'CORS_ERROR', candles: [], error: 'CORS or Network Failure' };
      }
      attempt++;
      if (attempt <= maxRetries) {
        await new Promise(r => setTimeout(r, 500 * attempt));
      }
    }
  }

  return { status: 'API_ERROR', candles: [], error: 'Max retries exceeded' };
}

/**
 * Downloads historical monthly archive for a given contract and YYYYMM
 * (e.g. 202301) via our server proxy
 */
export async function fetchHistoricalMonthArchive(
  contract: string,
  yearMonth: string
): Promise<FetchCandlesResult> {
  try {
    const url = `${getProxyBase()}/archive-month?contract=${encodeURIComponent(contract)}&yearMonth=${yearMonth}`;
    const res = await fetch(url);

    if (!res.ok) {
      if (res.status === 404) {
        return { status: 'NOT_LISTED_YET', candles: [], error: `${contract} henüz ${yearMonth} tarihinde listelenmemişti.` };
      }
      return { status: 'API_ERROR', candles: [], error: `Archive HTTP ${res.status}` };
    }

    const data = await res.json();
    if (data.status === 'NOT_LISTED_YET') {
      return { status: 'NOT_LISTED_YET', candles: [], error: data.message };
    }

    if (data.success && Array.isArray(data.candles)) {
      return { status: 'OK', candles: data.candles, source: 'archive' };
    }

    return { status: 'INVALID_DATA', candles: [], error: data.error || 'Geçersiz arşiv verisi' };
  } catch (err: any) {
    return { status: 'API_ERROR', candles: [], error: err.message };
  }
}

/**
 * Unified range fetch: combines all relevant monthly archives + recent REST candles
 */
export async function fetchContractRangeCandles(
  contract: string,
  fromSec: number,
  toSec: number,
  maxRetries: number = 2
): Promise<FetchCandlesResult> {
  let attempt = 0;
  let lastError = '';

  while (attempt <= maxRetries) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 15000); // 15s timeout per attempt

      const url = `${getProxyBase()}/range?contract=${encodeURIComponent(contract)}&from=${fromSec}&to=${toSec}`;
      const res = await fetch(url, { signal: controller.signal });
      clearTimeout(timeoutId);

      if (res.ok) {
        const data = await res.json();
        if (data.status === 'NOT_LISTED_YET') {
          return {
            status: 'NOT_LISTED_YET',
            candles: [],
            error: data.message || `${contract} henüz bu tarih aralığında listelenmemişti.`
          };
        }
        if (data.success && Array.isArray(data.candles)) {
          return {
            status: data.status || (data.candles.length > 0 ? 'OK' : 'INSUFFICIENT_DATA'),
            candles: data.candles,
            source: 'archive'
          };
        }
      } else {
        lastError = `Sunucu hatası (${res.status})`;
      }
    } catch (err: any) {
      lastError = err.name === 'AbortError'
        ? 'İstek zaman aşımına uğradı (15sn)'
        : (err.message || 'Ağ bağlantı hatası');
    }

    attempt++;
    if (attempt <= maxRetries) {
      await new Promise(r => setTimeout(r, 600 * attempt));
    }
  }

  // Fallback to direct REST if server range proxy had transient issue
  try {
    const directRes = await fetchContractCandlesDetailed(contract, 2000, fromSec, toSec);
    if (directRes.status === 'OK' && directRes.candles.length > 0) {
      return directRes;
    }
  } catch (err: any) {
    lastError = err.message || lastError;
  }

  return { status: 'API_ERROR', candles: [], error: lastError || 'API zaman aşımı ve tekrar denemeler tükendi' };
}

/**
 * Runs pre-flight test on BTC_USDT, ETH_USDT, SOL_USDT
 */
export async function runPreflightTest3(fromSec?: number, toSec?: number): Promise<{
  success: boolean;
  results: {
    coin: string;
    status: string;
    downloadedCandles: number;
    processedCandles: number;
    evaluatedCandidates: number;
    signalsCount: number;
    earliestDate?: string;
    latestDate?: string;
    latestPrice?: number;
    dataError: boolean;
    error?: string;
  }[];
}> {
  try {
    const params = new URLSearchParams();
    if (fromSec) params.set('from', String(fromSec));
    if (toSec) params.set('to', String(toSec));

    const res = await fetch(`${getProxyBase()}/test3?${params.toString()}`);
    if (res.ok) {
      const data = await res.json();
      if (data.success && Array.isArray(data.results)) {
        return {
          success: true,
          results: data.results.map((r: any) => ({
            coin: r.coin,
            status: r.status,
            downloadedCandles: r.downloadedCandles || 0,
            processedCandles: r.processedCandles || 0,
            evaluatedCandidates: r.evaluatedCandidates || 0,
            signalsCount: r.signalsCount || 0,
            earliestDate: r.firstCandleDate,
            latestDate: r.lastCandleDate,
            latestPrice: r.latestPrice ? Number(r.latestPrice) : undefined,
            dataError: Boolean(r.dataError),
            error: r.error
          }))
        };
      }
    }
  } catch {
    // Direct fallback
  }

  const coins = ['BTC_USDT', 'ETH_USDT', 'SOL_USDT'];
  const results = [];

  for (const coin of coins) {
    try {
      const candles = await fetchContractCandles(coin, 100);
      results.push({
        coin,
        status: candles.length > 0 ? 'SUCCESS' : 'FAILED',
        downloadedCandles: candles.length,
        processedCandles: Math.max(0, candles.length - 35),
        evaluatedCandidates: Math.max(0, candles.length - 35),
        signalsCount: 0,
        earliestDate: candles[0] ? new Date(candles[0].t * 1000).toISOString() : undefined,
        latestDate: candles[candles.length - 1] ? new Date(candles[candles.length - 1].t * 1000).toISOString() : undefined,
        latestPrice: candles[candles.length - 1]?.c,
        dataError: false
      });
    } catch (e: any) {
      results.push({
        coin,
        status: 'FAILED',
        downloadedCandles: 0,
        processedCandles: 0,
        evaluatedCandidates: 0,
        signalsCount: 0,
        dataError: true,
        error: e.message
      });
    }
  }

  return { success: results.every(r => r.status === 'SUCCESS'), results };
}



/**
 * Current mark price
 */
export async function fetchContractMarkPrice(contract: string): Promise<number | null> {
  try {
    const url = `${GATE_REST_URL}/tickers?contract=${contract}`;
    const res = await fetch(url);
    if (!res.ok) return null;
    const data = await res.json();
    if (Array.isArray(data) && data[0]) {
      const mark = Number(data[0].mark_price || data[0].last);
      return Number.isFinite(mark) ? mark : null;
    }
  } catch {
    // ignore
  }
  return null;
}
