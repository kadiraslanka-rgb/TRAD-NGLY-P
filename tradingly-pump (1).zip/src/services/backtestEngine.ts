import JSZip from 'jszip';
import {
  BacktestConfig,
  BacktestProgress,
  BacktestSummary,
  CoinBacktestStatus,
  GateCandle,
  GateContract,
  TradeRecord
} from '../types';
import { fetchContractRangeCandles, fetchGateContractReport, fetchGateUsdtContracts } from './gateApi';
import { buildPrecomputedSeries, createPumpSignal, evaluatePumpModel, evaluateTradeOutcome, MAX_HOLD_CANDLES } from './pumpCore';

export type BacktestCallback = (
  progress: BacktestProgress,
  trades: TradeRecord[],
  summary: BacktestSummary
) => void;

export class BacktestEngine {
  private config: BacktestConfig;
  private isRunning: boolean = false;
  private isPaused: boolean = false;
  private shouldStop: boolean = false;
  private trades: TradeRecord[] = [];
  private worker: Worker | null = null;

  // Status & counters
  private coinStatuses: CoinBacktestStatus[] = [];
  private successfulCoins: number = 0;
  private notListedYetCoins: number = 0;
  private insufficientDataCoins: number = 0;
  private apiErrorCoins: number = 0;
  private corsErrorCoins: number = 0;
  private rateLimitCoins: number = 0;
  private invalidDataCoins: number = 0;
  private retryingCoins: number = 0;

  private totalApiContracts: number = 0;
  private filteredContractsCount: number = 0;
  private totalDownloadedCandles: number = 0;
  private totalProcessedCandles: number = 0;

  private onUpdate: BacktestCallback | null = null;

  constructor(config: BacktestConfig) {
    this.config = config;
  }

  public setCallback(cb: BacktestCallback) {
    this.onUpdate = cb;
  }

  public pause() {
    this.isPaused = true;
    if (this.worker) {
      try {
        this.worker.postMessage({ type: 'PAUSE' });
      } catch {
        // ignore
      }
    }
  }

  public resume() {
    this.isPaused = false;
    if (this.worker) {
      try {
        this.worker.postMessage({ type: 'RESUME' });
      } catch {
        // ignore
      }
    }
  }

  public stop() {
    this.shouldStop = true;
    this.isRunning = false;
    if (this.worker) {
      try {
        this.worker.postMessage({ type: 'STOP' });
        this.worker.terminate();
      } catch {
        // ignore
      }
      this.worker = null;
    }
  }

  public getTrades(): TradeRecord[] {
    return this.trades;
  }

  public getCoinStatuses(): CoinBacktestStatus[] {
    return this.coinStatuses;
  }

  public computeSummary(): BacktestSummary {
    const totalSignals = this.trades.length;
    const tpHitCount = this.trades.filter(t => t.status === 'TP_HIT').length;
    const expired24hCount = this.trades.filter(t => t.status === 'EXPIRED_24H').length;
    const activeCount = this.trades.filter(t => t.status === 'ACTIVE').length;
    const completedCount = tpHitCount + expired24hCount;

    // RULE: Calculate win rate ONLY over completed trades
    const winRatePct = completedCount > 0
      ? Math.round((tpHitCount / completedCount) * 10000) / 100
      : 0;

    const completedTrades = this.trades.filter(t => t.status !== 'ACTIVE');
    const totalGain = completedTrades.reduce((acc, t) => acc + t.currentOrExitGainPct, 0);
    const avgGainPct = completedTrades.length > 0
      ? Math.round((totalGain / completedTrades.length) * 100) / 100
      : 0;

    const totalDuration = completedTrades.reduce((acc, t) => acc + t.durationMinutes, 0);
    const avgDurationMinutes = completedTrades.length > 0
      ? Math.round(totalDuration / completedTrades.length)
      : 0;

    let bestTrade: any = null;
    let worstTrade: any = null;

    if (completedTrades.length > 0) {
      const sorted = [...completedTrades].sort((a, b) => b.currentOrExitGainPct - a.currentOrExitGainPct);
      bestTrade = {
        contract: sorted[0].contract,
        gainPct: sorted[0].currentOrExitGainPct,
        durationMinutes: sorted[0].durationMinutes
      };
      worstTrade = {
        contract: sorted[sorted.length - 1].contract,
        gainPct: sorted[sorted.length - 1].currentOrExitGainPct,
        durationMinutes: sorted[sorted.length - 1].durationMinutes
      };
    }

    return {
      totalSignals,
      tpHitCount,
      expired24hCount,
      activeCount,
      missingDataCount: this.insufficientDataCoins + this.apiErrorCoins,
      successfulCoinsCount: this.successfulCoins,
      notListedYetCount: this.notListedYetCoins,
      insufficientDataCount: this.insufficientDataCoins,
      apiErrorCount: this.apiErrorCoins,
      corsErrorCount: this.corsErrorCoins,
      rateLimitCount: this.rateLimitCoins,
      invalidDataCount: this.invalidDataCoins,
      retriedCoinsCount: this.retryingCoins,
      winRatePct,
      avgGainPct,
      avgDurationMinutes,
      bestTrade,
      worstTrade,
      totalPnlPct: Math.round(totalGain * 100) / 100
    };
  }

  /**
   * Runs the historical backtest across contracts
   */
  public async run(): Promise<{ trades: TradeRecord[]; summary: BacktestSummary }> {
    this.isRunning = true;
    this.isPaused = false;
    this.shouldStop = false;
    this.trades = [];

    this.successfulCoins = 0;
    this.notListedYetCoins = 0;
    this.insufficientDataCoins = 0;
    this.apiErrorCoins = 0;
    this.corsErrorCoins = 0;
    this.rateLimitCoins = 0;
    this.invalidDataCoins = 0;
    this.retryingCoins = 0;
    this.totalDownloadedCandles = 0;
    this.totalProcessedCandles = 0;

    // Initialize Web Worker if running in browser
    try {
      if (typeof Worker !== 'undefined' && typeof window !== 'undefined') {
        this.worker = new Worker(new URL('../workers/backtest.worker.ts', import.meta.url), { type: 'module' });
      }
    } catch {
      this.worker = null;
    }

    // 1. Fetch active USDT futures contracts with dynamic filter report
    let contracts: GateContract[] = [];
    try {
      const report = await fetchGateContractReport();
      this.totalApiContracts = report.totalApiContracts;
      this.filteredContractsCount = report.filteredNonCryptoCount;
      contracts = report.contracts;
    } catch {
      this.totalApiContracts = 3;
      this.filteredContractsCount = 0;
      contracts = [
        { name: 'BTC_USDT', type: 'direct', trade_status: 'trading', status: 'trading', in_delisting: false },
        { name: 'ETH_USDT', type: 'direct', trade_status: 'trading', status: 'trading', in_delisting: false },
        { name: 'SOL_USDT', type: 'direct', trade_status: 'trading', status: 'trading', in_delisting: false }
      ];
    }

    let targetNames: string[] = contracts.map(c => c.name);

    if (this.config.coinMode === 'CUSTOM' && this.config.customCoins.length > 0) {
      targetNames = this.config.customCoins;
    } else if (this.config.coinMode === 'TOP_VOLUME') {
      const popular = [
        'BTC_USDT', 'ETH_USDT', 'SOL_USDT', 'DOGE_USDT', 'XRP_USDT', 'PEPE_USDT',
        'SUI_USDT', 'AVAX_USDT', 'NEAR_USDT', 'LINK_USDT', 'BNB_USDT', 'APT_USDT',
        'SHIB_USDT', 'WIF_USDT', 'TIA_USDT', 'RENDER_USDT', 'INJ_USDT', 'FET_USDT',
        'SEI_USDT', 'JUP_USDT', 'BONK_USDT', 'FLOKI_USDT', 'GALA_USDT', 'ORDI_USDT'
      ];
      const valid = popular.filter(p => targetNames.includes(p));
      targetNames = valid.length > 0 ? valid : targetNames.slice(0, 24);
    }

    if (this.config.maxCoinsLimit && this.config.maxCoinsLimit > 0) {
      targetNames = targetNames.slice(0, this.config.maxCoinsLimit);
    }

    // Initialize per-coin real tracking records
    this.coinStatuses = targetNames.map(contract => ({
      contract,
      status: 'WAITING',
      downloadedCandles: 0,
      processedCandles: 0,
      evaluatedCandidates: 0,
      signalsCount: 0
    }));

    const startSec = Math.floor(new Date(this.config.startDate).getTime() / 1000);
    const endSec = Math.floor(new Date(this.config.endDate).getTime() / 1000) + 86399;

    const startTimeMs = Date.now();
    let processedCount = 0;

    // Process each coin sequentially to guarantee accurate reporting and maintain network stability
    for (let i = 0; i < targetNames.length; i++) {
      if (this.shouldStop) break;

      while (this.isPaused && !this.shouldStop) {
        await new Promise(r => setTimeout(r, 200));
      }

      const contract = targetNames[i];
      const coinStatus = this.coinStatuses[i];

      // Step: DOWNLOADING
      coinStatus.status = 'DOWNLOADING';
      this.notifyProgress(contract, processedCount, targetNames.length, startTimeMs);

      try {
        const rangeResult = await fetchContractRangeCandles(contract, startSec, endSec);
        const candles = rangeResult.candles || [];

        // Kept strictly separate: downloadedCandles vs processedCandles
        coinStatus.downloadedCandles = candles.length;
        this.totalDownloadedCandles += candles.length;

        if (candles.length > 0) {
          coinStatus.firstCandleDate = new Date(candles[0].t * 1000).toISOString().slice(0, 10);
          coinStatus.lastCandleDate = new Date(candles[candles.length - 1].t * 1000).toISOString().slice(0, 10);
        }

        // Step: VERIFYING
        coinStatus.status = 'VERIFYING';
        this.notifyProgress(contract, processedCount, targetNames.length, startTimeMs);

        if (candles.length < 35) {
          if (rangeResult.status === 'NOT_LISTED_YET') {
            coinStatus.status = 'NOT_LISTED';
            coinStatus.error = rangeResult.error || 'Seçilen tarih aralığında henüz listelenmemişti.';
            this.notListedYetCoins++;
          } else {
            coinStatus.status = 'MISSING_DATA';
            coinStatus.error = rangeResult.error || 'Yetersiz mum verisi (<35 mum).';
            this.insufficientDataCoins++;
          }
          processedCount++;
          this.notifyProgress(contract, processedCount, targetNames.length, startTimeMs);
          continue;
        }

        // Step: ANALYZING
        coinStatus.status = 'ANALYZING';
        this.notifyProgress(contract, processedCount, targetNames.length, startTimeMs);

        const baseProcessedBeforeCoin = this.totalProcessedCandles;

        if (this.worker) {
          // Offload evaluation to Web Worker (keeps main UI thread 100% fluid)
          await new Promise<void>((resolve, reject) => {
            const handleMessage = (e: MessageEvent) => {
              const { type, payload } = e.data;
              if (type === 'PROGRESS') {
                if (payload.contract === contract) {
                  coinStatus.processedCandles = payload.processedCandles;
                  coinStatus.evaluatedCandidates = payload.evaluatedCandidates;
                  coinStatus.signalsCount = payload.signalsCount;
                  this.totalProcessedCandles = baseProcessedBeforeCoin + payload.processedCandles;
                  this.notifyProgress(contract, processedCount, targetNames.length, startTimeMs);
                }
              } else if (type === 'COIN_COMPLETE') {
                if (payload.contract === contract) {
                  this.worker?.removeEventListener('message', handleMessage);
                  this.trades.push(...payload.trades);
                  coinStatus.processedCandles = payload.processedCandles;
                  coinStatus.evaluatedCandidates = payload.evaluatedCandidates;
                  coinStatus.signalsCount = payload.signalsCount;
                  this.totalProcessedCandles = baseProcessedBeforeCoin + payload.processedCandles;
                  coinStatus.status = 'COMPLETED';
                  this.successfulCoins++;
                  resolve();
                }
              }
            };

            this.worker?.addEventListener('message', handleMessage);
            this.worker?.postMessage({
              type: 'ANALYZE_COIN',
              payload: { contract, candles, startSec, endSec }
            });
          });
        } else {
          // Fallback runner (e.g. Node tests / environments without Web Worker)
          let coinSignals = 0;
          let coinEvaluated = 0;
          const series = buildPrecomputedSeries(candles);

          for (let idx = 34; idx < candles.length; idx++) {
            if (this.shouldStop) break;

            while (this.isPaused && !this.shouldStop) {
              await new Promise(r => setTimeout(r, 100));
            }

            const candle = candles[idx];
            if (candle.t < startSec || candle.t > endSec) continue;

            coinEvaluated++;
            this.totalProcessedCandles++;

            // Original 61-feature model evaluation (Rules 9 & 10: every candle, zero skipping)
            const evalRes = evaluatePumpModel(candles, idx, series);

            if (evalRes.isSignal) {
              const signal = createPumpSignal(contract, candles, idx, evalRes.score, evalRes.indicators);
              const subsequentCandles = candles.slice(idx + 1);
              const outcome = evaluateTradeOutcome(signal, subsequentCandles);

              const trade: TradeRecord = {
                id: signal.id,
                contract: signal.contract,
                signalTime: signal.timestamp,
                entryPrice: signal.entryPrice,
                targetPrice: signal.targetPrice,
                status: outcome.status,
                score: signal.score,
                highestPrice: outcome.highestPrice,
                highestGainPct: outcome.highestGainPct,
                currentOrExitPrice: outcome.currentOrExitPrice,
                currentOrExitGainPct: outcome.currentOrExitGainPct,
                exitTime: outcome.exitTime,
                durationMinutes: outcome.durationMinutes,
                lastUpdated: Date.now()
              };

              this.trades.push(trade);
              coinSignals++;
            }

            // Real progress notification every 1,000 candles (Rule 3)
            if (coinEvaluated % 1000 === 0) {
              coinStatus.processedCandles = coinEvaluated;
              coinStatus.evaluatedCandidates = coinEvaluated;
              coinStatus.signalsCount = coinSignals;
              this.notifyProgress(contract, processedCount, targetNames.length, startTimeMs);
              await new Promise(r => setTimeout(r, 0));
            }
          }

          coinStatus.processedCandles = coinEvaluated;
          coinStatus.evaluatedCandidates = coinEvaluated;
          coinStatus.signalsCount = coinSignals;
          coinStatus.status = 'COMPLETED';
          this.successfulCoins++;
        }
      } catch (err: any) {
        // Rule 7: Failed coin does not stop the other coins
        coinStatus.status = 'API_ERROR';
        coinStatus.error = err.message || 'Veri çekme / analiz hatası';
        this.apiErrorCoins++;
      }

      // Rule 5: Immediately commit and notify as soon as coin completes
      processedCount++;
      this.notifyProgress(contract, processedCount, targetNames.length, startTimeMs);

      // Brief sleep between coins to keep network rate limits healthy
      await new Promise(r => setTimeout(r, 15));
    }

    if (this.worker) {
      try {
        this.worker.terminate();
      } catch {
        // ignore
      }
      this.worker = null;
    }

    this.isRunning = false;
    this.trades.sort((a, b) => b.signalTime - a.signalTime);
    const summary = this.computeSummary();

    if (this.onUpdate) {
      const elapsedSec = Math.max(0.1, (Date.now() - startTimeMs) / 1000);
      this.onUpdate(
        {
          isRunning: false,
          isPaused: false,
          currentContract: this.shouldStop ? 'Durduruldu' : 'Tamamlandı',
          processedContracts: processedCount,
          totalContracts: targetNames.length,
          downloadedCandles: this.totalDownloadedCandles,
          processedCandles: this.totalProcessedCandles,
          speedCandlesPerSec: Math.round(this.totalProcessedCandles / elapsedSec),
          successfulCoins: this.successfulCoins,
          notListedYetCoins: this.notListedYetCoins,
          insufficientDataCoins: this.insufficientDataCoins,
          apiErrorCoins: this.apiErrorCoins,
          corsErrorCoins: this.corsErrorCoins,
          rateLimitCoins: this.rateLimitCoins,
          invalidDataCoins: this.invalidDataCoins,
          retryingCoins: this.retryingCoins,
          signalsFound: this.trades.length,
          coinStatuses: [...this.coinStatuses]
        },
        this.trades,
        summary
      );
    }

    return { trades: this.trades, summary };
  }

  private notifyProgress(
    currentContract: string,
    processedContracts: number,
    totalContracts: number,
    startTimeMs: number
  ) {
    if (this.onUpdate) {
      const elapsedSec = Math.max(0.1, (Date.now() - startTimeMs) / 1000);
      const speed = Math.round(this.totalProcessedCandles / elapsedSec);
      const progress: BacktestProgress = {
        isRunning: this.isRunning && !this.shouldStop,
        isPaused: this.isPaused,
        currentContract,
        processedContracts,
        totalContracts,
        totalApiContracts: this.totalApiContracts,
        filteredContractsCount: this.filteredContractsCount,
        downloadedCandles: this.totalDownloadedCandles,
        processedCandles: this.totalProcessedCandles,
        speedCandlesPerSec: speed,
        successfulCoins: this.successfulCoins,
        notListedYetCoins: this.notListedYetCoins,
        insufficientDataCoins: this.insufficientDataCoins,
        apiErrorCoins: this.apiErrorCoins,
        corsErrorCoins: this.corsErrorCoins,
        rateLimitCoins: this.rateLimitCoins,
        invalidDataCoins: this.invalidDataCoins,
        retryingCoins: this.retryingCoins,
        signalsFound: this.trades.length,
        coinStatuses: [...this.coinStatuses]
      };

      this.onUpdate(progress, this.trades, this.computeSummary());
    }
  }

  /**
   * Exports backtest results and model specs as a ZIP archive
   */
  public async exportAsZip(summary: BacktestSummary): Promise<Blob> {
    const zip = new JSZip();

    const csvRows = [
      'ID,Tarih,Coin,Giris_Fiyati,Hedef_Fiyat_20,Durum,En_Yuksek_Fiyat,En_Yuksek_Kar_Yuzdesi,Sonuc_Fiyat,Sonuc_Kar_Yuzdesi,Sure_Dakika,Pump_Model_Skoru'
    ];

    for (const t of this.trades) {
      const dateStr = new Date(t.signalTime).toISOString();
      csvRows.push(
        `"${t.id}","${dateStr}","${t.contract}",${t.entryPrice},${t.targetPrice},"${t.status}",${t.highestPrice},${t.highestGainPct}%,${t.currentOrExitPrice},${t.currentOrExitGainPct}%,${t.durationMinutes},${t.score}`
      );
    }

    zip.file('tradingly_pump_signals.csv', csvRows.join('\n'));

    // Export per-coin status audit
    const coinAuditRows = ['Coin,Durum,Indirilen_Mum,Islenen_Mum,Degerlendirilen_Adaylar,Sinyal_Sayisi,Ilk_Mum,Son_Mum,Hata'];
    for (const cs of this.coinStatuses) {
      coinAuditRows.push(
        `"${cs.contract}","${cs.status}",${cs.downloadedCandles},${cs.processedCandles},${cs.evaluatedCandidates},${cs.signalsCount},"${cs.firstCandleDate || ''}","${cs.lastCandleDate || ''}","${cs.error || ''}"`
      );
    }
    zip.file('coin_audit_report.csv', coinAuditRows.join('\n'));

    const summaryData = {
      app: 'TRADINGLY PUMP',
      generatedAt: new Date().toISOString(),
      config: this.config,
      summary,
      totalTradesLogged: this.trades.length
    };
    zip.file('tradingly_pump_summary.json', JSON.stringify(summaryData, null, 2));

    const modelSpec = {
      modelName: 'TRADINGLY PUMP 61-Feature Quantitative Breakout Model',
      threshold: 0.81,
      targetPercent: 20.0,
      timeframe: '5m',
      atrFilter: '>= 1.0%',
      bollingerBandwidthFilter: '>= 1.92%',
      maxHoldHours: 24,
      totalIndicators: 61,
      direction: 'LONG_ONLY',
      exchange: 'Gate.io USDT Futures'
    };
    zip.file('model_spec.json', JSON.stringify(modelSpec, null, 2));

    return await zip.generateAsync({ type: 'blob' });
  }
}
