import { PumpSignal, TradeRecord } from '../types';

const STORAGE_KEYS = {
  SIGNALS: 'tradingly_pump_signals',
  FORWARD_TRADES: 'tradingly_pump_forward_trades',
  SETTINGS: 'tradingly_pump_settings',
  BACKTEST_TRADES: 'tradingly_pump_backtest_trades',
  LANGUAGE: 'tradingly_pump_language'
};

export function loadStoredSignals(): PumpSignal[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SIGNALS);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveStoredSignals(signals: PumpSignal[]): void {
  try {
    // Keep last 500 signals
    const trimmed = signals.slice(0, 500);
    localStorage.setItem(STORAGE_KEYS.SIGNALS, JSON.stringify(trimmed));
  } catch (e) {
    console.warn('Storage save failed:', e);
  }
}

export function loadStoredTrades(): TradeRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.FORWARD_TRADES);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveStoredTrades(trades: TradeRecord[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.FORWARD_TRADES, JSON.stringify(trades.slice(0, 500)));
  } catch (e) {
    console.warn('Trades save failed:', e);
  }
}

export function loadStoredLanguage(): 'tr' | 'en' {
  try {
    const lang = localStorage.getItem(STORAGE_KEYS.LANGUAGE);
    return lang === 'en' ? 'en' : 'tr';
  } catch {
    return 'tr';
  }
}

export function saveStoredLanguage(lang: 'tr' | 'en'): void {
  try {
    localStorage.setItem(STORAGE_KEYS.LANGUAGE, lang);
  } catch {
    // ignore
  }
}
