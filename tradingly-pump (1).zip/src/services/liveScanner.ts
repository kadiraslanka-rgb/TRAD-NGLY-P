import { GateCandle, GateContract, LiveScanStats, PumpSignal } from '../types';
import { fetchContractCandles, fetchGateContractReport } from './gateApi';
import { sendSignalNotification } from './nativeBridge';
import { createPumpSignal, evaluatePumpModel } from './pumpCore';
import { playPumpAlertSound } from './soundAlert';

export type LiveScanCallback = (stats: LiveScanStats, newSignal?: PumpSignal) => void;

export class LiveScannerManager {
  private stats: LiveScanStats = {
    isScanning: false,
    isPaused: false,
    totalCoins: 0,
    totalApiContracts: 0,
    filteredContractsCount: 0,
    scannedCoins: 0,
    successfulCoins: 0,
    failedCoins: 0,
    retryCount: 0,
    currentCoin: '',
    speed: 0,
    signalsFoundCount: 0,
    startTime: null,
    endTime: null,
    nextScanCountdown: 0,
    loopEnabled: true
  };

  private shouldStop: boolean = false;
  private onUpdate: LiveScanCallback | null = null;
  private countdownTimer: any = null;
  private activeContracts: GateContract[] = [];
  private knownSignalIds = new Set<string>();

  public setCallback(cb: LiveScanCallback) {
    this.onUpdate = cb;
  }

  public getStats(): LiveScanStats {
    return { ...this.stats };
  }

  public setLoopEnabled(enabled: boolean) {
    this.stats.loopEnabled = enabled;
    if (!enabled && this.countdownTimer) {
      clearInterval(this.countdownTimer);
      this.countdownTimer = null;
      this.stats.nextScanCountdown = 0;
      this.notify();
    }
  }

  private notify(newSignal?: PumpSignal) {
    if (this.onUpdate) {
      this.onUpdate({ ...this.stats }, newSignal);
    }
  }

  public stopScan() {
    this.shouldStop = true;
    this.stats.isScanning = false;
    this.stats.isPaused = false;
    if (this.countdownTimer) {
      clearInterval(this.countdownTimer);
      this.countdownTimer = null;
    }
    this.stats.nextScanCountdown = 0;
    this.stats.currentCoin = 'Tarama durduruldu';
    this.notify();
  }

  public pauseScan() {
    if (this.stats.isScanning) {
      this.stats.isPaused = true;
      this.stats.currentCoin = 'Tarama duraklatıldı';
      this.notify();
    }
  }

  public resumeScan() {
    if (this.stats.isScanning && this.stats.isPaused) {
      this.stats.isPaused = false;
      this.stats.currentCoin = 'Tarama sürdürülüyor...';
      this.notify();
    }
  }

  /**
   * Starts a full live scanning pass across all eligible Gate USDT perpetual contracts.
   * STRICT GUARD: Prevents multiple concurrent scans!
   */
  public async startScan(): Promise<void> {
    if (this.stats.isScanning) {
      console.warn('Scan already in progress. Ignoring duplicate start request.');
      return;
    }

    if (this.countdownTimer) {
      clearInterval(this.countdownTimer);
      this.countdownTimer = null;
      this.stats.nextScanCountdown = 0;
    }

    this.shouldStop = false;
    this.stats.isScanning = true;
    this.stats.isPaused = false;
    this.stats.startTime = Date.now();
    this.stats.scannedCoins = 0;
    this.stats.successfulCoins = 0;
    this.stats.failedCoins = 0;
    this.stats.retryCount = 0;
    this.stats.speed = 0;
    this.stats.currentCoin = 'Gate API sözleşmeleri taranıyor ve filtreleniyor...';
    this.notify();

    try {
      // 1. Fetch dynamic report of contracts (strictly filters out synthetic stocks, indices, etc.)
      const report = await fetchGateContractReport();
      this.activeContracts = report.contracts;
      this.stats.totalApiContracts = report.totalApiContracts;
      this.stats.filteredContractsCount = report.filteredNonCryptoCount;
      this.stats.totalCoins = report.eligibleCoinsCount;
      this.notify();

      if (this.stats.totalCoins === 0) {
        throw new Error('Uygun Gate USDT vadeli coin bulunamadı');
      }

      // 2. Scan through coins using concurrency pool with controlled retry queue
      const queue = [...this.activeContracts];
      const retryQueue: GateContract[] = [];
      const CONCURRENCY = 6;
      let inFlight = 0;
      let currentIndex = 0;

      const processContract = async (contract: GateContract, isRetry: boolean = false): Promise<void> => {
        if (this.shouldStop) return;

        // Wait while paused
        while (this.stats.isPaused && !this.shouldStop) {
          await new Promise(r => setTimeout(r, 200));
        }

        if (this.shouldStop) return;

        this.stats.currentCoin = contract.name;

        try {
          // Fetch last 80 5-minute candles
          const candles: GateCandle[] = await fetchContractCandles(contract.name, 80, undefined, undefined, 2);

          if (!candles || candles.length < 35) {
            throw new Error('Yetersiz 5m mum verisi');
          }

          // Evaluate the latest closed candle (index length - 2)
          // Index length - 1 is the currently forming candle, index length - 2 is the closed candle
          const targetIdx = candles.length - 2;
          const { isSignal, score, indicators } = evaluatePumpModel(candles, targetIdx);

          if (isSignal && score >= 0.81) {
            const signal = createPumpSignal(contract.name, candles, targetIdx, score, indicators);

            if (!this.knownSignalIds.has(signal.id)) {
              this.knownSignalIds.add(signal.id);
              this.stats.signalsFoundCount++;

              // Sound and Notification
              playPumpAlertSound();
              sendSignalNotification(contract.name, score, signal.entryPrice);

              this.notify(signal);
            }
          }

          this.stats.successfulCoins++;
        } catch (err: any) {
          if (!isRetry) {
            this.stats.retryCount++;
            retryQueue.push(contract);
          } else {
            // Re-tried and still failed: count as failed, NEVER count as successful
            this.stats.failedCoins++;
          }
        } finally {
          this.stats.scannedCoins++;
          const elapsedSec = Math.max(0.2, (Date.now() - (this.stats.startTime || Date.now())) / 1000);
          this.stats.speed = Math.round((this.stats.scannedCoins / elapsedSec) * 10) / 10;
          this.notify();
        }
      };

      // Primary scan loop
      while ((currentIndex < queue.length || inFlight > 0) && !this.shouldStop) {
        while (inFlight < CONCURRENCY && currentIndex < queue.length && !this.shouldStop) {
          const item = queue[currentIndex++];
          inFlight++;
          processContract(item, false).finally(() => {
            inFlight--;
          });
        }
        await new Promise(r => setTimeout(r, 50));
      }

      // Retry loop for failed coins
      if (retryQueue.length > 0 && !this.shouldStop) {
        this.stats.currentCoin = `Hatalı ${retryQueue.length} coin yeniden deneniyor...`;
        this.notify();

        for (const item of retryQueue) {
          if (this.shouldStop) break;
          while (this.stats.isPaused && !this.shouldStop) {
            await new Promise(r => setTimeout(r, 200));
          }
          await processContract(item, true);
          await new Promise(r => setTimeout(r, 80));
        }
      }
    } catch (err: any) {
      console.error('Scan execution error:', err);
      this.stats.currentCoin = `Hata: ${err.message || 'Bilinmeyen hata'}`;
    } finally {
      this.stats.isScanning = false;
      this.stats.isPaused = false;
      this.stats.endTime = Date.now();
      if (!this.stats.currentCoin.startsWith('Hata:')) {
        this.stats.currentCoin = this.shouldStop ? 'Tarama Durduruldu' : 'Tarama Tamamlandı';
      }
      this.notify();

      // Auto loop countdown (15 seconds) if enabled
      if (this.stats.loopEnabled && !this.shouldStop) {
        this.startNextScanCountdown();
      }
    }
  }

  private startNextScanCountdown() {
    this.stats.nextScanCountdown = 15;
    this.notify();

    this.countdownTimer = setInterval(() => {
      this.stats.nextScanCountdown--;
      this.notify();

      if (this.stats.nextScanCountdown <= 0) {
        clearInterval(this.countdownTimer);
        this.countdownTimer = null;
        this.startScan();
      }
    }, 1000);
  }
}

export const liveScanner = new LiveScannerManager();
