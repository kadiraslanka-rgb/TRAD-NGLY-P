import { AndroidBridgeStatus } from '../types';

declare global {
  interface Window {
    Capacitor?: any;
    AndroidBridge?: {
      startForegroundService?: (title: string, text: string) => boolean;
      stopForegroundService?: () => boolean;
      isForegroundServiceRunning?: () => boolean;
      requestIgnoreBatteryOptimizations?: () => void;
      isBatteryOptimizationIgnored?: () => boolean;
      sendSignalNotification?: (title: string, body: string, contract: string) => void;
    };
  }
}

let wakeLockSentinel: any = null;

/**
 * Checks the real status of the Android Native Bridge and Browser APIs.
 * TRUTHFUL IMPLEMENTATION: Never fakes native status when in a web browser!
 */
export async function getAndroidBridgeStatus(): Promise<AndroidBridgeStatus> {
  const isCapacitorNative = Boolean(
    typeof window !== 'undefined' &&
    window.Capacitor &&
    typeof window.Capacitor.isNativePlatform === 'function' &&
    window.Capacitor.isNativePlatform()
  );

  const hasAndroidBridge = Boolean(
    typeof window !== 'undefined' &&
    window.AndroidBridge &&
    typeof window.AndroidBridge.startForegroundService === 'function'
  );

  const isNative = isCapacitorNative || hasAndroidBridge;

  let foregroundServiceRunning = false;
  let batteryOptimizationIgnored = false;

  if (hasAndroidBridge && window.AndroidBridge?.isForegroundServiceRunning) {
    try {
      foregroundServiceRunning = window.AndroidBridge.isForegroundServiceRunning();
    } catch {
      foregroundServiceRunning = false;
    }
  }

  if (hasAndroidBridge && window.AndroidBridge?.isBatteryOptimizationIgnored) {
    try {
      batteryOptimizationIgnored = window.AndroidBridge.isBatteryOptimizationIgnored();
    } catch {
      batteryOptimizationIgnored = false;
    }
  }

  // Web Notification Permission
  let notificationPermission: 'granted' | 'denied' | 'default' = 'default';
  if (typeof window !== 'undefined' && 'Notification' in window) {
    notificationPermission = Notification.permission;
  }

  const wakeLockActive = Boolean(wakeLockSentinel && !wakeLockSentinel.released);

  return {
    isNative,
    hasForegroundService: isNative,
    foregroundServiceRunning,
    notificationPermission,
    batteryOptimizationIgnored,
    wakeLockActive,
    environmentName: isNative
      ? (isCapacitorNative ? 'Android Native (Capacitor)' : 'Android Native (WebView Bridge)')
      : 'Web Tarayıcı Modu (Android APK Değil)'
  };
}

/**
 * Requests Notification permission (Web API or Native)
 */
export async function requestNotificationPermission(): Promise<'granted' | 'denied' | 'default'> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'denied';
  }

  try {
    const permission = await Notification.requestPermission();
    return permission;
  } catch {
    return 'denied';
  }
}

/**
 * Sends a real system notification for a newly detected PUMP signal
 */
export function sendSignalNotification(contract: string, score: number, entryPrice: number): void {
  const title = `🚨 TRADINGLY PUMP: ${contract}`;
  const body = `Skor: ${(score * 100).toFixed(1)}% | Giriş: $${entryPrice.toLocaleString()} | Hedef: +%20`;

  // 1. Try Native Android Bridge if present
  if (typeof window !== 'undefined' && window.AndroidBridge?.sendSignalNotification) {
    try {
      window.AndroidBridge.sendSignalNotification(title, body, contract);
      return;
    } catch (e) {
      console.warn('Native notification error:', e);
    }
  }

  // 2. Try HTML5 Notification API if granted
  if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
    try {
      const n = new Notification(title, {
        body,
        icon: '/favicon.ico',
        tag: `pump_${contract}_${Date.now()}`,
        requireInteraction: true
      });
      n.onclick = () => {
        window.focus();
        n.close();
      };
    } catch (e) {
      console.warn('Web notification error:', e);
    }
  }
}

/**
 * Starts Android Foreground Service (if native) or requests Web WakeLock (if web)
 */
export async function startForegroundService(
  title: string = 'TRADINGLY PUMP Canlı Tarama',
  text: string = '5m mumlar taranıyor, arka plan aktif...'
): Promise<{ success: boolean; message: string }> {
  // If native Android Bridge is available:
  if (typeof window !== 'undefined' && window.AndroidBridge?.startForegroundService) {
    try {
      const started = window.AndroidBridge.startForegroundService(title, text);
      return {
        success: Boolean(started),
        message: started
          ? 'Android Foreground Service ve kalıcı bildirim başlatıldı.'
          : 'Android Foreground Service başlatılamadı.'
      };
    } catch (err: any) {
      return { success: false, message: `Hata: ${err.message}` };
    }
  }

  // Web Browser environment fallback: Request Screen WakeLock
  if (typeof navigator !== 'undefined' && 'wakeLock' in navigator) {
    try {
      wakeLockSentinel = await (navigator as any).wakeLock.request('screen');
      wakeLockSentinel.addEventListener('release', () => {
        wakeLockSentinel = null;
      });
      return {
        success: true,
        message: 'Web Ekran Kilidi Önleme (WakeLock) aktif. Ekranın kapanması engelleniyor.'
      };
    } catch {
      return {
        success: false,
        message: 'Web WakeLock tarayıcı tarafından kısıtlandı. Ekran açık tutulmalı.'
      };
    }
  }

  return {
    success: false,
    message: 'Web tarayıcısında çalışıyor. Gerçek Android Foreground Service için APK gereklidir.'
  };
}

/**
 * Stops Android Foreground Service or releases Web WakeLock
 */
export async function stopForegroundService(): Promise<{ success: boolean; message: string }> {
  if (typeof window !== 'undefined' && window.AndroidBridge?.stopForegroundService) {
    try {
      const stopped = window.AndroidBridge.stopForegroundService();
      return { success: Boolean(stopped), message: 'Android Foreground Service durduruldu.' };
    } catch (err: any) {
      return { success: false, message: `Hata: ${err.message}` };
    }
  }

  if (wakeLockSentinel) {
    try {
      await wakeLockSentinel.release();
      wakeLockSentinel = null;
      return { success: true, message: 'Web Ekran Kilidi serbest bırakıldı.' };
    } catch (err: any) {
      return { success: false, message: err.message };
    }
  }

  return { success: true, message: 'Servis durduruldu.' };
}

/**
 * Triggers request for ignoring battery optimizations
 */
export function triggerBatteryOptimizationRequest(): { handled: boolean; message: string } {
  if (typeof window !== 'undefined' && window.AndroidBridge?.requestIgnoreBatteryOptimizations) {
    try {
      window.AndroidBridge.requestIgnoreBatteryOptimizations();
      return {
        handled: true,
        message: 'Android Pil Optimizasyonu ayarı açıldı. Lütfen "Kısıtlama Yok" seçeneğini işaretleyin.'
      };
    } catch (err: any) {
      return { handled: false, message: `Hata: ${err.message}` };
    }
  }

  return {
    handled: false,
    message: 'Tarayıcıda pil optimizasyonu doğrudan kontrol edilemez. Android Ayarları > Uygulamalar > Tarayıcı > Pil > "Kısıtlama Yok" adımlarını izleyin.'
  };
}

/**
 * Returns configuration strings for exporting the native Capacitor / Android project
 */
export function getAndroidProjectConfig() {
  const capacitorConfig = {
    appId: 'com.tradingly.pump',
    appName: 'TRADINGLY PUMP',
    webDir: 'dist',
    bundledWebRuntime: false,
    plugins: {
      LocalNotifications: {
        smallIcon: 'ic_stat_icon_config_sample',
        iconColor: '#10B981',
        sound: 'beep.wav'
      },
      ForegroundService: {
        notificationTitle: 'TRADINGLY PUMP Aktif',
        notificationText: 'Vadeli 5m PUMP taraması arka planda çalışıyor',
        icon: 'ic_stat_icon_config_sample'
      }
    }
  };

  const androidManifestSnippet = `
<!-- AndroidManifest.xml İçin Gerekli İzinler -->
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.WAKE_LOCK" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE_DATA_SYNC" />
<uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" />
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />

<!-- Foreground Service Tanımı -->
<service
    android:name="com.tradingly.pump.ForegroundScanService"
    android:foregroundServiceType="dataSync"
    android:exported="false" />
  `.trim();

  const javaForegroundServiceSnippet = `
package com.tradingly.pump;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import androidx.core.app.NotificationCompat;

public class ForegroundScanService extends Service {
    private static final String CHANNEL_ID = "tradingly_pump_scan_channel";
    private static final int NOTIFICATION_ID = 1001;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String title = intent.getStringExtra("title");
        String text = intent.getStringExtra("text");
        if (title == null) title = "TRADINGLY PUMP Tarama Servisi";
        if (text == null) text = "Arka planda Gate USDT vadeli coinler taranıyor";

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle(title)
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_popup_sync)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .build();

        startForeground(NOTIFICATION_ID, notification);
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "TRADINGLY PUMP Arka Plan Servisi",
                    NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }
}
  `.trim();

  return {
    capacitorConfig,
    androidManifestSnippet,
    javaForegroundServiceSnippet
  };
}
