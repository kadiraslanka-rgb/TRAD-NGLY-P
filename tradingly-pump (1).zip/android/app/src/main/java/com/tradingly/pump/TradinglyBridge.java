package com.tradingly.pump;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import android.webkit.JavascriptInterface;

public class TradinglyBridge {
    private final Context context;

    public TradinglyBridge(Context context) {
        this.context = context;
    }

    @JavascriptInterface
    public boolean startForegroundService(String title, String text) {
        try {
            Intent serviceIntent = new Intent(context, TradinglyForegroundService.class);
            serviceIntent.putExtra("title", title);
            serviceIntent.putExtra("text", text);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent);
            } else {
                context.startService(serviceIntent);
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @JavascriptInterface
    public boolean stopForegroundService() {
        try {
            Intent serviceIntent = new Intent(context, TradinglyForegroundService.class);
            context.stopService(serviceIntent);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @JavascriptInterface
    public boolean isForegroundServiceRunning() {
        return TradinglyForegroundService.isServiceRunning();
    }

    @JavascriptInterface
    public boolean isBatteryOptimizationIgnored() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                return pm.isIgnoringBatteryOptimizations(context.getPackageName());
            }
        }
        return true;
    }

    @JavascriptInterface
    public void requestIgnoreBatteryOptimizations() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + context.getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @JavascriptInterface
    public void sendSignalNotification(String title, String body, String contract) {
        TradinglyForegroundService.sendSignalAlertNotification(context, title, body, contract);
    }

    @JavascriptInterface
    public String getAppVersion() {
        return "1.0.1";
    }
}
