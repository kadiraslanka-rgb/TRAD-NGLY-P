package com.tradingly.pump;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import androidx.core.app.NotificationCompat;

public class TradinglyForegroundService extends Service {
    public static final String CHANNEL_ID_SERVICE = "tradingly_pump_foreground_service";
    public static final String CHANNEL_ID_SIGNALS = "tradingly_pump_signals";
    public static final int SERVICE_NOTIFICATION_ID = 7701;
    private static volatile boolean isRunning = false;

    private PowerManager.WakeLock wakeLock;

    public static boolean isServiceRunning() {
        return isRunning;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannels();

        // Acquire WakeLock so CPU doesn't sleep when screen turns off
        PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (powerManager != null) {
            wakeLock = powerManager.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "TRADINGLY_PUMP::ForegroundScannerWakeLock"
            );
            wakeLock.setReferenceCounted(false);
            try {
                wakeLock.acquire(12 * 60 * 60 * 1000L); // Max 12 hours safeguard
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        isRunning = true;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String title = "TRADINGLY PUMP Canlı Tarama";
        String content = "5 dakikalık Gate USDT mumları taranıyor...";

        if (intent != null) {
            String customTitle = intent.getStringExtra("title");
            String customContent = intent.getStringExtra("text");
            if (customTitle != null && !customTitle.isEmpty()) title = customTitle;
            if (customContent != null && !customContent.isEmpty()) content = customContent;
        }

        Intent openAppIntent = new Intent(this, MainActivity.class);
        openAppIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0)
        );

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID_SERVICE)
            .setContentTitle(title)
            .setContentText(content)
            .setSmallIcon(android.R.drawable.ic_popup_sync)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build();

        startForeground(SERVICE_NOTIFICATION_ID, notification);
        isRunning = true;

        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        isRunning = false;
        if (wakeLock != null && wakeLock.isHeld()) {
            try {
                wakeLock.release();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        stopForeground(true);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager == null) return;

            // 1. Foreground Service Silent Notification Channel
            NotificationChannel serviceChannel = new NotificationChannel(
                CHANNEL_ID_SERVICE,
                "TRADINGLY PUMP Tarama Servisi",
                NotificationManager.IMPORTANCE_LOW
            );
            serviceChannel.setDescription("Arka planda kesintisiz Gate.io 5m mum taraması bildirimi");
            manager.createNotificationChannel(serviceChannel);

            // 2. High-Priority Signal Alert Notification Channel
            NotificationChannel signalChannel = new NotificationChannel(
                CHANNEL_ID_SIGNALS,
                "TRADINGLY PUMP Sinyal Uyarıları",
                NotificationManager.IMPORTANCE_HIGH
            );
            signalChannel.setDescription("Yeni %20 PUMP sinyali tespit edildiğinde sesli ve titreşimli anlık uyarı");
            signalChannel.enableVibration(true);
            signalChannel.setVibrationPattern(new long[]{0, 250, 100, 250});
            manager.createNotificationChannel(signalChannel);
        }
    }

    public static void sendSignalAlertNotification(Context context, String title, String body, String contract) {
        try {
            NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager == null) return;

            Intent openIntent = new Intent(context, MainActivity.class);
            openIntent.putExtra("targetContract", contract);
            openIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);

            int reqCode = (int) (System.currentTimeMillis() % 100000);
            PendingIntent pendingIntent = PendingIntent.getActivity(
                context,
                reqCode,
                openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0)
            );

            Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

            Notification notification = new NotificationCompat.Builder(context, CHANNEL_ID_SIGNALS)
                .setContentTitle(title)
                .setContentText(body)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setSound(defaultSoundUri)
                .setVibrate(new long[]{0, 250, 100, 250})
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .build();

            int notificationId = (int) System.currentTimeMillis();
            manager.notify(notificationId, notification);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
